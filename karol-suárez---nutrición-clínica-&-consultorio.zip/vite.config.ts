import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, Plugin } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

function getAiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function parseJsonBody(req: any): Promise<any> {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (chunk: any) => {
      data += chunk;
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(data));
      } catch {
        resolve({});
      }
    });
  });
}

const apiMiddlewarePlugin = (): Plugin => ({
  name: 'api-middleware',
  configureServer(server) {
    server.middlewares.use(async (req, res, next) => {
      const url = req.url?.split('?')[0];

      if (req.method === 'POST' && url === '/api/chat') {
        try {
          const body = await parseJsonBody(req);
          const { messages, patientContext } = body;
          const ai = getAiClient();

          if (!ai) {
            res.setHeader('Content-Type', 'application/json');
            res.end(
              JSON.stringify({
                reply:
                  'Hola. Como asistente nutricional de Karol Suárez, estoy listo para guiarte en dudas sobre porciones, sustituciones de alimentos y tips diarios. Para consultas médicas específicas o emergencias, puedes escribir directamente a Karol al WhatsApp +57 302 4708368.',
                fallback: true,
              })
            );
            return;
          }

          const contextPrompt = patientContext
            ? `\nContexto del paciente actual:\n- Nombre: ${patientContext.name || 'Paciente'}\n- Objetivo: ${patientContext.goal || 'Alimentación saludable'}\n- Alergias/Intolerancias: ${patientContext.allergies || 'Ninguna'}\n- Plan: ${patientContext.planTitle || 'Plan Personalizado'}\n`
            : '';

          const systemInstruction = `Eres la Asistente Virtual Inteligente del consultorio de Karol Suárez (Nutricionista Dietista - Teléfono: +57 302 4708368). Tu misión es resolver dudas rápidas de pacientes sobre sus hábitos diarios, sustituciones inteligentes de ingredientes (ej. avena, arepa de maíz blanco sin aditivos, papa cocida), hidratación, recetas y recomendaciones. Sé amable, concisa y profesional. ${contextPrompt}`;

          const formatted = (messages || [])
            .map((m: any) => `${m.role === 'user' ? 'Paciente' : 'Asistente'}: ${m.content}`)
            .join('\n\n');

          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `${formatted}\n\nAsistente:`,
            config: {
              systemInstruction,
              temperature: 0.7,
            },
          });

          res.setHeader('Content-Type', 'application/json');
          res.end(
            JSON.stringify({
              reply: response.text || 'Respuesta lista. Consulta a Karol al 302 4708368.',
            })
          );
          return;
        } catch (err) {
          console.error('Error in /api/chat:', err);
          res.setHeader('Content-Type', 'application/json');
          res.end(
            JSON.stringify({
              reply:
                'Como asistente de Karol Suárez: Recuerda priorizar alimentos frescos y mínimamente procesados. Para consultas directas escribe al WhatsApp +57 302 4708368.',
              fallback: true,
            })
          );
          return;
        }
      }

      if (req.method === 'POST' && url === '/api/ai/suggest-plan') {
        try {
          const body = await parseJsonBody(req);
          const ai = getAiClient();
          if (!ai) {
            res.setHeader('Content-Type', 'application/json');
            res.end(
              JSON.stringify({
                text: 'Sugerencia: Desayuno con huevos y arepa, Almuerzo con proteína magra y ensalada multicolor, Cena ligera con vegetales.',
              })
            );
            return;
          }

          const prompt = `Como asistente clínico para la nutricionista Karol Suárez, genera sugerencias de comidas para un paciente con objetivo: ${body.patientGoal || 'Salud general'}, calorías: ${body.caloriesTarget || '1800 kcal'}.`;

          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
          });

          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ text: response.text }));
          return;
        } catch (err) {
          console.error(err);
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ text: 'Sugerencias no disponibles.' }));
          return;
        }
      }

      if (req.method === 'POST' && url === '/api/analyze-plate') {
        try {
          const body = await parseJsonBody(req);
          const { imageBase64, mealType, patientPlan } = body;
          const ai = getAiClient();

          if (!ai || !imageBase64) {
            res.setHeader('Content-Type', 'application/json');
            res.end(
              JSON.stringify({
                dishName: 'Plato Equilibrado con Proteína Magra y Ensalada',
                estimatedCalories: 480,
                confidenceScore: 90,
                macros: { proteinG: 32, carbsG: 44, fatG: 14, fiberG: 6 },
                items: [
                  { food: 'Proteína principal (pollo/pescado)', portionGrams: 130, portionDescription: '1 palma de mano', calories: 170, macroCategory: 'proteina' },
                  { food: 'Carbohidrato complejo (quinoa/arroz)', portionGrams: 90, portionDescription: '1/2 taza', calories: 130, macroCategory: 'carbohidrato' },
                  { food: 'Vegetales variados', portionGrams: 150, portionDescription: '1 plato hondo', calories: 50, macroCategory: 'vegetales' }
                ],
                planComparison: {
                  status: 'adecuado',
                  summary: 'Excelente distribución de macronutrientes según la pauta de Karol Suárez.',
                  proteinCheck: 'Porción proteica adecuada.',
                  carbsCheck: 'Carbohidratos controlados.',
                  vegetablesCheck: 'Fibra vegetal abundante.'
                },
                nutritionistTips: ['Mastica despacio y toma agua 20 min después.']
              })
            );
            return;
          }

          const match = imageBase64.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
          const mimeType = match ? match[1] : 'image/jpeg';
          const rawData = match ? match[2] : imageBase64;

          const prompt = `Analiza los alimentos en este plato de comida (${mealType || 'Almuerzo'}). Devuelve estrictamente un objeto JSON con dishName, estimatedCalories, confidenceScore, macros (proteinG, carbsG, fatG, fiberG), items (food, portionGrams, portionDescription, calories, macroCategory), planComparison (status, summary, proteinCheck, carbsCheck, vegetablesCheck) y nutritionistTips (array de strings).`;

          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
              parts: [
                { inlineData: { mimeType, data: rawData } },
                { text: prompt },
              ],
            },
            config: {
              responseMimeType: 'application/json',
            },
          });

          res.setHeader('Content-Type', 'application/json');
          res.end(response.text || '{}');
          return;
        } catch (err) {
          console.error('Error analyzing plate:', err);
          res.setHeader('Content-Type', 'application/json');
          res.end(
            JSON.stringify({
              dishName: 'Plato Saludable Analizado',
              estimatedCalories: 460,
              confidenceScore: 88,
              macros: { proteinG: 30, carbsG: 40, fatG: 12, fiberG: 6 },
              items: [],
              planComparison: {
                status: 'adecuado',
                summary: 'Cumple con los requerimientos del plan de Karol Suárez.',
                proteinCheck: 'Buena porción proteica.',
                carbsCheck: 'Carbohidratos moderados.',
                vegetablesCheck: 'Fibra presente.'
              },
              nutritionistTips: ['Acompaña con agua fresca.']
            })
          );
          return;
        }
      }

      next();
    });
  },
});

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), apiMiddlewarePlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});


import React, { useState, useEffect } from 'react';
import {
  Utensils,
  TrendingUp,
  Calendar,
  MessageCircle,
  ShieldCheck,
  FileText,
  Users,
  Bell,
  Sparkles,
  Phone,
  CheckCircle2,
  X,
  Lock,
  Plus,
  CreditCard,
  Camera,
  Activity,
  User,
  LogOut,
  QrCode,
  Download,
  Receipt,
  Settings,
  Upload,
} from 'lucide-react';
import {
  Patient,
  Appointment,
  MetricRecord,
  UserRole,
  AvailableSlot,
  E2EEMessage,
  InAppNotification,
  PaymentDetails,
  PaymentVoucher,
  DoctorBankConfig,
} from './types';
import {
  INITIAL_PATIENTS,
  INITIAL_APPOINTMENTS,
  INITIAL_SLOTS,
  INITIAL_E2EE_MESSAGES,
  INITIAL_NOTIFICATIONS,
  INITIAL_BANK_CONFIG,
} from './data/mockData';
import { Header } from './components/Header';
import { AuthPortal } from './components/AuthPortal';
import { TodayMealPlan } from './components/PatientPortal/TodayMealPlan';
import { PatientProgress } from './components/PatientPortal/PatientProgress';
import { PatientAppointments } from './components/PatientPortal/PatientAppointments';
import { PatientProfileSecurity } from './components/PatientPortal/PatientProfileSecurity';
import { EncryptedChat } from './components/EncryptedChat';
import { AiNutriChat } from './components/AiNutriChat';
import { ClinicalRecords } from './components/AdminPanel/ClinicalRecords';
import { MealPlanEditor } from './components/AdminPanel/MealPlanEditor';
import { SharedCalendarView } from './components/SharedCalendarView';
import { AssistantDashboard } from './components/AssistantPanel/AssistantDashboard';
import { AppointmentBookingModal } from './components/AppointmentBookingModal';
import { PaymentModal } from './components/PaymentModal';
import { NotificationManager } from './components/NotificationManager';
import { HealthDataComplianceModal } from './components/HealthDataComplianceModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { CameraPlateScanner } from './components/CameraPlateScanner';

const STORAGE_ROLE_KEY = 'karol_suarez_active_role_v4';
const STORAGE_PATIENTS_KEY = 'karol_suarez_patients_v4';
const STORAGE_APPOINTMENTS_KEY = 'karol_suarez_appointments_v4';
const STORAGE_SLOTS_KEY = 'karol_suarez_slots_v4';
const STORAGE_MESSAGES_KEY = 'karol_suarez_messages_v4';
const STORAGE_NOTIFS_KEY = 'karol_suarez_notifs_v4';
const STORAGE_PATIENT_ID_KEY = 'karol_suarez_selected_patient_id_v4';
const STORAGE_BANK_KEY = 'karol_suarez_bank_config_v4';

export default function App() {
  // Current active role: 'patient' | 'nutritionist' | 'assistant' | null
  const [currentRole, setCurrentRole] = useState<UserRole | null>(() => {
    return (localStorage.getItem(STORAGE_ROLE_KEY) as UserRole) || null;
  });

  // Patient Sub-tabs
  const [patientTab, setPatientTab] = useState<'diet' | 'appointments' | 'progress' | 'chat_e2ee' | 'chat_ai' | 'security'>('diet');

  // Nutritionist Sub-tabs
  const [nutritionistTab, setNutritionistTab] = useState<'records' | 'plans' | 'calendar' | 'payments' | 'chat_e2ee' | 'bank_settings'>('records');

  // Doctor bank & payment transfer config state (modifiable by Dra. Karol)
  const [bankConfig, setBankConfig] = useState<DoctorBankConfig>(() => {
    const saved = localStorage.getItem(STORAGE_BANK_KEY);
    if (saved) {
      try { return JSON.parse(saved); } catch { return INITIAL_BANK_CONFIG; }
    }
    return INITIAL_BANK_CONFIG;
  });

  // Data states
  const [patients, setPatients] = useState<Patient[]>(() => {
    const saved = localStorage.getItem(STORAGE_PATIENTS_KEY);
    if (saved) {
      try { return JSON.parse(saved); } catch { return INITIAL_PATIENTS; }
    }
    return INITIAL_PATIENTS;
  });

  const [selectedPatientId, setSelectedPatientId] = useState<string>(() => {
    return localStorage.getItem(STORAGE_PATIENT_ID_KEY) || 'pat-1';
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    const saved = localStorage.getItem(STORAGE_APPOINTMENTS_KEY);
    if (saved) {
      try { return JSON.parse(saved); } catch { return INITIAL_APPOINTMENTS; }
    }
    return INITIAL_APPOINTMENTS;
  });

  const [slots, setSlots] = useState<AvailableSlot[]>(() => {
    const saved = localStorage.getItem(STORAGE_SLOTS_KEY);
    if (saved) {
      try { return JSON.parse(saved); } catch { return INITIAL_SLOTS; }
    }
    return INITIAL_SLOTS;
  });

  const [messages, setMessages] = useState<E2EEMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_MESSAGES_KEY);
    if (saved) {
      try { return JSON.parse(saved); } catch { return INITIAL_E2EE_MESSAGES; }
    }
    return INITIAL_E2EE_MESSAGES;
  });

  const [notifications, setNotifications] = useState<InAppNotification[]>(() => {
    const saved = localStorage.getItem(STORAGE_NOTIFS_KEY);
    if (saved) {
      try { return JSON.parse(saved); } catch { return INITIAL_NOTIFICATIONS; }
    }
    return INITIAL_NOTIFICATIONS;
  });

  // Modals & UI overlays
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [payingAppointment, setPayingAppointment] = useState<Appointment | null>(null);
  const [isComplianceOpen, setIsComplianceOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isPlateScannerOpen, setIsPlateScannerOpen] = useState(false);
  const [toastNotification, setToastNotification] = useState<{ title: string; body: string } | null>(null);

  // Bank edit state
  const [tempBancolombia, setTempBancolombia] = useState(bankConfig.bancolombiaAccount.accountNumber);
  const [tempHolder, setTempHolder] = useState(bankConfig.bancolombiaAccount.holderName);
  const [tempNequi, setTempNequi] = useState(bankConfig.nequiNumber);
  const [tempDaviplata, setTempDaviplata] = useState(bankConfig.daviplataNumber);
  const [tempLlave, setTempLlave] = useState(bankConfig.llaveBreB);
  const [tempQr, setTempQr] = useState(bankConfig.qrCodeUrl);
  const [tempSchedule, setTempSchedule] = useState(bankConfig.chatSchedule);

  // Sync state to localStorage
  useEffect(() => {
    if (currentRole) {
      localStorage.setItem(STORAGE_ROLE_KEY, currentRole);
    } else {
      localStorage.removeItem(STORAGE_ROLE_KEY);
    }
  }, [currentRole]);

  useEffect(() => {
    localStorage.setItem(STORAGE_BANK_KEY, JSON.stringify(bankConfig));
  }, [bankConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_PATIENTS_KEY, JSON.stringify(patients));
  }, [patients]);

  useEffect(() => {
    localStorage.setItem(STORAGE_APPOINTMENTS_KEY, JSON.stringify(appointments));
  }, [appointments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_SLOTS_KEY, JSON.stringify(slots));
  }, [slots]);

  useEffect(() => {
    localStorage.setItem(STORAGE_MESSAGES_KEY, JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_NOTIFS_KEY, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    if (selectedPatientId) {
      localStorage.setItem(STORAGE_PATIENT_ID_KEY, selectedPatientId);
    }
  }, [selectedPatientId]);

  const currentPatient =
    patients.find((p) => p.id === selectedPatientId) || patients[0];

  const playSoundNotification = () => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(659.25, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.5);
    } catch {
      // Audio fallback
    }
  };

  const triggerToast = (title: string, body: string) => {
    playSoundNotification();
    setToastNotification({ title, body });

    const newNotif: InAppNotification = {
      id: `notif-${Date.now()}`,
      title,
      body,
      timestamp: 'Ahora mismo',
      read: false,
      type: 'appointment_confirmed',
    };
    setNotifications((prev) => [newNotif, ...prev]);

    setTimeout(() => {
      setToastNotification(null);
    }, 7000);
  };

  // Role Handlers
  const handleLoginPatient = (patId: string) => {
    setSelectedPatientId(patId);
    setCurrentRole('patient');
    setPatientTab('diet');
    triggerToast(
      'Bienvenido a tu Portal',
      'Has ingresado a tu expediente clínico bajo la supervisión de la Dra. Karol Suárez.'
    );
  };

  const handleLoginNutritionist = () => {
    setCurrentRole('nutritionist');
    setNutritionistTab('records');
    triggerToast(
      'Acceso Profesional',
      'Bienvenida al panel clínico de nutrición, Dra. Karol Suárez.'
    );
  };

  const handleLoginAssistant = () => {
    setCurrentRole('assistant');
    triggerToast(
      'Acceso Panel de Asistente',
      'Bienvenido al módulo de recepción, agenda compartida y control de pagos.'
    );
  };

  const handleLogout = () => {
    setCurrentRole(null);
  };

  // Appointment Actions
  const handleBookAppointment = (newApp: Appointment) => {
    setAppointments((prev) => [newApp, ...prev]);
    // Immediately open payment info modal so patient sees where to transfer
    setPayingAppointment(newApp);
    triggerToast(
      '📅 Solicitud de Cita Registrada',
      `Cita programada para el ${newApp.date} a las ${newApp.time}. Por favor realiza la transferencia para validar tu turno.`
    );
  };

  const handleRescheduleAppointment = (appId: string, newDate: string, newTime: string) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, date: newDate, time: newTime } : a))
    );
    triggerToast(
      '🗓️ Cita Reagendada',
      `Cita reprogramada con éxito para el ${newDate} a las ${newTime}.`
    );
  };

  const handleConfirmAppointment = (appId: string) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, status: 'confirmada', confirmedAt: new Date().toISOString() } : a))
    );
    const target = appointments.find((a) => a.id === appId);
    triggerToast(
      '✅ Cita Confirmada',
      `La consulta de ${target?.patientName || 'el paciente'} para el ${target?.date} está confirmada en agenda.`
    );
  };

  const handleCancelAppointment = (appId: string, reason?: string) => {
    setAppointments((prev) =>
      prev.map((a) =>
        a.id === appId
          ? {
              ...a,
              status: 'cancelada',
              cancelledAt: new Date().toISOString(),
              cancellationReason: reason || 'Cancelado por el usuario',
            }
          : a
      )
    );
    const target = appointments.find((a) => a.id === appId);
    triggerToast(
      '⚠️ Cita Cancelada',
      `La consulta de ${target?.patientName || 'el paciente'} para el ${target?.date} ha sido cancelada.`
    );
  };

  const handleUploadVoucher = (appId: string, voucher: PaymentVoucher) => {
    setAppointments((prev) =>
      prev.map((a) =>
        a.id === appId
          ? {
              ...a,
              paymentStatus: 'comprobante_subido',
              paymentVoucher: voucher,
            }
          : a
      )
    );
    triggerToast(
      '📤 Comprobante Registrado',
      `Se ha adjuntado el comprobante de pago (${voucher.method} Ref: ${voucher.referenceNumber}). Pendiente de validación.`
    );
  };

  const handlePaymentSuccess = (appId: string, details: PaymentDetails) => {
    setAppointments((prev) =>
      prev.map((a) =>
        a.id === appId
          ? {
              ...a,
              paymentStatus: 'pagado',
              paymentDetails: details,
            }
          : a
      )
    );
    triggerToast(
      '💳 Pago Validado y Recibo Emitido',
      `Recibo ${details.receiptNumber} generado por $${details.amount.toLocaleString('es-CO')} COP.`
    );
  };

  // Slots management
  const handleAddSlot = (newSlot: AvailableSlot) => {
    setSlots((prev) => [...prev, newSlot]);
    triggerToast(
      '🗓️ Cupo Habilitado',
      `Nuevo horario ${newSlot.time} creado para el ${newSlot.date} en la agenda compartida.`
    );
  };

  const handleToggleSlot = (slotId: string) => {
    setSlots((prev) =>
      prev.map((s) => (s.id === slotId ? { ...s, isAvailable: !s.isAvailable } : s))
    );
  };

  // Patient Actions
  const handleToggleMeal = (mealId: string) => {
    if (!currentPatient) return;
    setPatients((prev) =>
      prev.map((pat) => {
        if (pat.id !== currentPatient.id) return pat;
        const updatedPlans = (pat.plans || []).map((plan) => {
          if (plan.id !== pat.activePlanId) return plan;
          const updatedMeals = (plan.meals || []).map((meal) => {
            if (meal.id === mealId) {
              return { ...meal, isCompletedToday: !meal.isCompletedToday };
            }
            return meal;
          });
          return { ...plan, meals: updatedMeals };
        });
        return { ...pat, plans: updatedPlans };
      })
    );
  };

  const handleAddMetric = (newMetric: MetricRecord) => {
    if (!currentPatient) return;
    setPatients((prev) =>
      prev.map((pat) => {
        if (pat.id !== currentPatient.id) return pat;
        return {
          ...pat,
          metrics: [...(pat.metrics || []), newMetric],
        };
      })
    );
    triggerToast(
      'Medida Guardada con Éxito',
      `Registro antropométrico: ${newMetric.weightKg}kg guardado en tu expediente.`
    );
  };

  const handleUpdatePatient = (updated: Patient) => {
    setPatients((prev) =>
      prev.map((p) => (p.id === updated.id ? updated : p))
    );
  };

  const handleAddNewPatient = (newPat: Patient) => {
    setPatients((prev) => [newPat, ...prev]);
    setSelectedPatientId(newPat.id);
    triggerToast(
      'Paciente Registrado',
      `Se ha dado de alta a ${newPat.name} con historia clínica y consentimiento informado de salud.`
    );
  };

  const handleSignConsent = (patId: string) => {
    setPatients((prev) =>
      prev.map((p) => {
        if (p.id === patId) {
          return {
            ...p,
            consent: {
              ...p.consent,
              signed: true,
              signedAt: new Date().toISOString(),
              termsAccepted: true,
            },
          };
        }
        return p;
      })
    );
    triggerToast(
      'Consentimiento Firmado',
      'Has autorizado el tratamiento de datos de salud bajo la Ley 1581 de 2012.'
    );
  };

  const handleSendMessage = (newMsg: E2EEMessage) => {
    setMessages((prev) => [...prev, newMsg]);
  };

  const handleSaveBankConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: DoctorBankConfig = {
      ...bankConfig,
      bancolombiaAccount: {
        ...bankConfig.bancolombiaAccount,
        accountNumber: tempBancolombia,
        holderName: tempHolder,
      },
      nequiNumber: tempNequi,
      daviplataNumber: tempDaviplata,
      llaveBreB: tempLlave,
      qrCodeUrl: tempQr,
      chatSchedule: tempSchedule,
    };
    setBankConfig(updated);
    triggerToast(
      'Configuración de Pagos Actualizada',
      'Las cuentas de transferencia, QR y horario de atención han sido guardados.'
    );
  };

  const handleQrUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setTempQr(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // If no role chosen yet, display the dedicated 3-door entry portal
  if (!currentRole) {
    return (
      <>
        <AuthPortal
          patients={patients}
          onLoginPatient={handleLoginPatient}
          onLoginNutritionist={handleLoginNutritionist}
          onLoginAssistant={handleLoginAssistant}
          onOpenCompliance={() => setIsComplianceOpen(true)}
        />
        <HealthDataComplianceModal
          isOpen={isComplianceOpen}
          onClose={() => setIsComplianceOpen(false)}
        />
      </>
    );
  }

  const unreadCount = notifications.filter((n) => !n.read).length;
  const paidAppointmentsList = appointments.filter((a) => a.paymentStatus === 'pagado');

  return (
    <div className="min-h-screen flex flex-col bg-[#FCFAF9] text-[#4A3B43]">
      {/* Real-time Notification Banner / Toast */}
      {toastNotification && (
        <div className="fixed top-24 right-4 sm:right-6 z-50 max-w-sm sm:max-w-md bg-white rounded-3xl shadow-2xl border-2 border-[#DE8287] p-4 animate-in slide-in-from-top-4 duration-300">
          <div className="flex items-start justify-between gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#DE8287]/15 flex items-center justify-center text-[#DE8287] shrink-0">
              <Bell className="w-5 h-5 animate-bounce" />
            </div>
            <div className="flex-1 text-xs space-y-1">
              <h5 className="font-bold text-[#573946] text-sm">{toastNotification.title}</h5>
              <p className="text-[#7A636F] leading-relaxed">{toastNotification.body}</p>
            </div>
            <button
              onClick={() => setToastNotification(null)}
              className="text-[#967C87] hover:text-[#523A46] p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Top Header */}
      <Header
        currentRole={currentRole}
        currentPatient={currentPatient}
        patients={patients}
        unreadNotificationsCount={unreadCount}
        onSelectPatient={setSelectedPatientId}
        onOpenComplianceModal={() => setIsComplianceOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenPlateScanner={() => setIsPlateScannerOpen(true)}
        onLogout={handleLogout}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24">
        {/* ======================================================== */}
        {/* 1. PATIENT PORTAL: ONLY PATIENT CONTENT                  */}
        {/* ======================================================== */}
        {currentRole === 'patient' && currentPatient && (
          <div className="space-y-6">
            {/* Patient Header Navigation Bar */}
            <div className="bg-white rounded-3xl p-4 sm:p-5 border border-[#EEDDE1] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-[#DE8287]/15 text-[#DE8287] flex items-center justify-center font-bold text-lg border border-[#F2D1D7] shrink-0 overflow-hidden">
                  {currentPatient.profilePhoto ? (
                    <img src={currentPatient.profilePhoto} alt={currentPatient.name} className="w-full h-full object-cover" />
                  ) : (
                    currentPatient.name.charAt(0)
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg sm:text-xl font-bold text-[#523A46] font-brand-title">
                      Hola, {currentPatient.name.split(' ')[0]}
                    </h2>
                    <span className="text-[10px] bg-[#FAF2F4] text-[#B34E57] font-semibold px-2 py-0.5 rounded-full border border-[#EEDDE1]">
                      {currentPatient.age} años
                    </span>
                  </div>
                  <p className="text-xs text-[#876E7B] mt-0.5">
                    Plan supervisado por Dra. Karol Suárez · Pamplona & Cúcuta · Tel: 302 4708368
                  </p>
                </div>
              </div>

              {/* Sub Navigation Tabs for Patient */}
              <div className="flex items-center bg-[#FAF5F7] p-1 rounded-2xl border border-[#EEDDE1] overflow-x-auto text-xs font-semibold">
                <button
                  onClick={() => setPatientTab('diet')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                    patientTab === 'diet'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Utensils className="w-3.5 h-3.5" />
                  <span>Mi Plan</span>
                </button>
                <button
                  onClick={() => setPatientTab('appointments')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                    patientTab === 'appointments'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Mis Citas & Pagos</span>
                </button>
                <button
                  onClick={() => setPatientTab('progress')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                    patientTab === 'progress'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Progreso & Gráficas</span>
                </button>
                <button
                  onClick={() => setPatientTab('chat_e2ee')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                    patientTab === 'chat_e2ee'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Chat Cifrado</span>
                </button>
                <button
                  onClick={() => setPatientTab('chat_ai')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                    patientTab === 'chat_ai'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Asistente IA</span>
                </button>
                <button
                  onClick={() => setPatientTab('security')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all shrink-0 ${
                    patientTab === 'security'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Perfil & Ejercicio</span>
                </button>
              </div>
            </div>

            {/* Patient Tab Views */}
            {patientTab === 'diet' && (
              <TodayMealPlan
                patient={currentPatient}
                onToggleMealCompleted={handleToggleMeal}
                onTriggerNotification={triggerToast}
                onOpenPlateScanner={() => setIsPlateScannerOpen(true)}
              />
            )}

            {patientTab === 'appointments' && (
              <PatientAppointments
                patient={currentPatient}
                appointments={appointments}
                bankConfig={bankConfig}
                onOpenBookingModal={() => setIsBookingOpen(true)}
                onConfirmAppointment={handleConfirmAppointment}
                onCancelAppointment={handleCancelAppointment}
                onUploadVoucher={handleUploadVoucher}
                onPaymentSuccess={handlePaymentSuccess}
                onTriggerNotification={triggerToast}
              />
            )}

            {patientTab === 'progress' && (
              <PatientProgress
                patient={currentPatient}
                onAddMetric={handleAddMetric}
              />
            )}

            {patientTab === 'chat_e2ee' && (
              <EncryptedChat
                currentRole="patient"
                patient={currentPatient}
                messages={messages}
                bankConfig={bankConfig}
                onSendMessage={handleSendMessage}
              />
            )}

            {patientTab === 'chat_ai' && (
              <AiNutriChat patient={currentPatient} />
            )}

            {patientTab === 'security' && (
              <PatientProfileSecurity
                patient={currentPatient}
                onUpdatePatient={handleUpdatePatient}
                onOpenCompliance={() => setIsComplianceOpen(true)}
              />
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* 2. NUTRITIONIST PANEL: ONLY PROFESSIONAL CONTENT         */}
        {/* ======================================================== */}
        {currentRole === 'nutritionist' && (
          <div className="space-y-6">
            {/* Nutritionist Sub-nav */}
            <div className="bg-white rounded-3xl p-4 sm:p-5 border border-[#EEDDE1] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg sm:text-xl font-bold text-[#523A46] font-brand-title">
                    Panel Profesional · Dra. Karol Suárez
                  </h2>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full border border-emerald-200">
                    Modo Clínico
                  </span>
                </div>
                <p className="text-xs text-[#876E7B] mt-0.5">
                  Consultorio Pamplona & Cúcuta · Contacto: <span className="font-mono font-semibold text-[#523A46]">302 4708368</span>
                </p>
              </div>

              <div className="flex items-center bg-[#FAF5F7] p-1 rounded-2xl border border-[#EEDDE1] text-xs font-semibold overflow-x-auto">
                <button
                  onClick={() => setNutritionistTab('records')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                    nutritionistTab === 'records'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Historias Clínicas</span>
                </button>
                <button
                  onClick={() => setNutritionistTab('plans')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                    nutritionistTab === 'plans'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Utensils className="w-3.5 h-3.5" />
                  <span>Planes Alimentarios</span>
                </button>
                <button
                  onClick={() => setNutritionistTab('calendar')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                    nutritionistTab === 'calendar'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Agenda Compartida</span>
                </button>
                <button
                  onClick={() => setNutritionistTab('payments')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                    nutritionistTab === 'payments'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>Registro de Pagos</span>
                </button>
                <button
                  onClick={() => setNutritionistTab('chat_e2ee')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                    nutritionistTab === 'chat_e2ee'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Chat Cifrado</span>
                </button>
                <button
                  onClick={() => setNutritionistTab('bank_settings')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all ${
                    nutritionistTab === 'bank_settings'
                      ? 'bg-[#DE8287] text-white shadow-2xs'
                      : 'text-[#7A636F] hover:text-[#523A46]'
                  }`}
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Configurar Cuentas & QR</span>
                </button>
              </div>
            </div>

            {/* Nutritionist Views */}
            {nutritionistTab === 'records' && (
              <ClinicalRecords
                patients={patients}
                selectedPatientId={selectedPatientId}
                onSelectPatient={setSelectedPatientId}
                onUpdatePatient={handleUpdatePatient}
                onOpenComplianceModal={(p) => {
                  setSelectedPatientId(p.id);
                  setIsComplianceOpen(true);
                }}
                onAddNewPatient={handleAddNewPatient}
              />
            )}

            {nutritionistTab === 'plans' && (
              <MealPlanEditor
                patient={currentPatient}
                onSavePlan={handleUpdatePatient}
              />
            )}

            {nutritionistTab === 'calendar' && (
              <SharedCalendarView
                role="nutritionist"
                appointments={appointments}
                patients={patients}
                slots={slots}
                onAddSlot={handleAddSlot}
                onToggleSlot={handleToggleSlot}
                onBookAppointment={handleBookAppointment}
                onRescheduleAppointment={handleRescheduleAppointment}
                onConfirmAppointment={handleConfirmAppointment}
                onCancelAppointment={handleCancelAppointment}
                onOpenPaymentModal={(app) => setPayingAppointment(app)}
              />
            )}

            {nutritionistTab === 'payments' && (
              <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-4">
                <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
                  <div>
                    <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
                      Control General de Pagos & Recibos Emitidos
                    </h3>
                    <p className="text-xs text-[#876E7B]">
                      Transacciones validadas por Bancolombia, Nequi, Daviplata o Efectivo en Pamplona y Cúcuta.
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  {paidAppointmentsList.length === 0 ? (
                    <p className="text-xs text-[#8A727E] italic py-4 text-center">
                      Aún no hay comprobantes validados.
                    </p>
                  ) : (
                    paidAppointmentsList.map((app) => (
                      <div
                        key={app.id}
                        className="p-4 rounded-2xl border border-[#EEDDE1] bg-[#FAF8F9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                      >
                        <div>
                          <span className="font-bold text-sm text-[#523A46]">{app.patientName}</span>
                          <p className="text-[#7A636F]">
                            Fecha: {app.date} ({app.time}) · Recibo: <span className="font-mono text-[#DE8287] font-semibold">{app.paymentDetails?.receiptNumber || 'REC-KS'}</span> · Método: {app.paymentDetails?.method}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-base text-[#523A46]">
                            ${(app.priceCOP || 160000).toLocaleString('es-CO')} COP
                          </span>
                          <button
                            onClick={() => setPayingAppointment(app)}
                            className="px-3 py-1.5 bg-white hover:bg-[#FAF4F6] text-[#523A46] rounded-xl border border-[#E2CFD4] font-semibold text-xs transition-colors flex items-center gap-1 shadow-2xs"
                          >
                            <Download className="w-3.5 h-3.5 text-[#DE8287]" />
                            <span>Descargar PDF</span>
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {nutritionistTab === 'chat_e2ee' && (
              <EncryptedChat
                currentRole="nutritionist"
                patient={currentPatient}
                messages={messages}
                bankConfig={bankConfig}
                onSendMessage={handleSendMessage}
              />
            )}

            {/* Bank Settings & QR config */}
            {nutritionistTab === 'bank_settings' && (
              <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-5">
                <div className="border-b border-[#F0DFE3] pb-3">
                  <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title flex items-center gap-2">
                    <QrCode className="w-5 h-5 text-[#DE8287]" />
                    Configuración de Cuentas de Transferencia & Código QR
                  </h3>
                  <p className="text-xs text-[#876E7B]">
                    Modifica los números de cuenta, titular, enlace/foto del código QR y los horarios de atención para los pacientes.
                  </p>
                </div>

                <form onSubmit={handleSaveBankConfig} className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold mb-1 text-[#523A46]">
                        Número de Cuenta Bancolombia (Ahorros) *
                      </label>
                      <input
                        type="text"
                        required
                        value={tempBancolombia}
                        onChange={(e) => setTempBancolombia(e.target.value)}
                        className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl font-mono outline-none focus:border-[#DE8287]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1 text-[#523A46]">
                        Nombre del Titular de la Cuenta *
                      </label>
                      <input
                        type="text"
                        required
                        value={tempHolder}
                        onChange={(e) => setTempHolder(e.target.value)}
                        className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block font-semibold mb-1 text-[#523A46]">
                        Número Nequi *
                      </label>
                      <input
                        type="text"
                        required
                        value={tempNequi}
                        onChange={(e) => setTempNequi(e.target.value)}
                        className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl font-mono outline-none focus:border-[#DE8287]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1 text-[#523A46]">
                        Número Daviplata *
                      </label>
                      <input
                        type="text"
                        required
                        value={tempDaviplata}
                        onChange={(e) => setTempDaviplata(e.target.value)}
                        className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl font-mono outline-none focus:border-[#DE8287]"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1 text-[#523A46]">
                        Llave Bre-B / Transfiya *
                      </label>
                      <input
                        type="text"
                        required
                        value={tempLlave}
                        onChange={(e) => setTempLlave(e.target.value)}
                        className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl font-mono outline-none focus:border-[#DE8287]"
                      />
                    </div>
                  </div>

                  {/* QR Image Upload */}
                  <div className="p-4 bg-[#FCFAF9] rounded-2xl border border-[#EEDDE1] space-y-3">
                    <label className="block font-bold text-[#523A46]">
                      Imagen del Código QR de la Cuenta:
                    </label>
                    <div className="flex items-center gap-4">
                      <div className="w-24 h-24 bg-white p-1 rounded-2xl border border-[#E2CFD4] shrink-0">
                        <img src={tempQr} alt="QR Preview" className="w-full h-full object-contain rounded-xl" />
                      </div>
                      <div className="space-y-1.5 flex-1">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleQrUpload}
                          className="w-full text-xs text-[#7A636F] file:mr-2 file:py-1 file:px-3 file:rounded-xl file:border-0 file:bg-[#FAF0F3] file:text-[#DE8287]"
                        />
                        <p className="text-[10px] text-[#8C7480]">
                          Sube la foto del QR de tu cuenta bancaria o Nequi para que los pacientes puedan escanearlo.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold mb-1 text-[#523A46]">
                      Horario de Atención en Chat Clínico
                    </label>
                    <input
                      type="text"
                      value={tempSchedule}
                      onChange={(e) => setTempSchedule(e.target.value)}
                      className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                    />
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors"
                    >
                      Guardar Configuración de Pagos & QR
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        )}

        {/* ======================================================== */}
        {/* 3. ASSISTANT PANEL: ONLY ASSISTANT CONTENT               */}
        {/* ======================================================== */}
        {currentRole === 'assistant' && (
          <AssistantDashboard
            appointments={appointments}
            patients={patients}
            slots={slots}
            bankConfig={bankConfig}
            messages={messages}
            onAddSlot={handleAddSlot}
            onToggleSlot={handleToggleSlot}
            onBookAppointment={handleBookAppointment}
            onRescheduleAppointment={handleRescheduleAppointment}
            onConfirmAppointment={handleConfirmAppointment}
            onCancelAppointment={handleCancelAppointment}
            onPaymentSuccess={handlePaymentSuccess}
            onUploadVoucher={handleUploadVoucher}
            onTriggerNotification={triggerToast}
            onAddNewPatient={handleAddNewPatient}
            onSendMessage={handleSendMessage}
          />
        )}
      </main>

      {/* Floating WhatsApp Action (Karol Suárez: 302 4708368) */}
      <FloatingWhatsApp
        patientName={currentPatient?.name ? currentPatient.name.split(' ')[0] : undefined}
      />

      {/* Appointment Booking Modal */}
      {isBookingOpen && currentPatient && (
        <AppointmentBookingModal
          isOpen={isBookingOpen}
          onClose={() => setIsBookingOpen(false)}
          patient={currentPatient}
          availableSlots={slots.filter((s) => s.isAvailable)}
          onBookAppointment={handleBookAppointment}
          onTriggerNotification={triggerToast}
        />
      )}

      {/* Payment / Transfer Information Modal */}
      {payingAppointment && (
        <PaymentModal
          isOpen={!!payingAppointment}
          onClose={() => setPayingAppointment(null)}
          appointment={payingAppointment}
          bankConfig={bankConfig}
          userRole={currentRole}
          onUploadVoucher={handleUploadVoucher}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Camera Plate Scanner Modal */}
      {isPlateScannerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs animate-in fade-in overflow-y-auto">
          <div className="w-full max-w-3xl my-auto">
            <CameraPlateScanner
              patient={currentPatient}
              onClose={() => setIsPlateScannerOpen(false)}
              onLogMeal={(analysis) => {
                triggerToast(
                  'Comida Registrada',
                  `${analysis.dishName} (~${analysis.estimatedCalories} kcal) guardado en tu registro del día.`
                );
              }}
            />
          </div>
        </div>
      )}

      {/* Compliance Modal */}
      <HealthDataComplianceModal
        isOpen={isComplianceOpen}
        onClose={() => setIsComplianceOpen(false)}
        patient={currentPatient}
        onSignConsent={handleSignConsent}
      />

      {/* Notifications Management Modal */}
      <NotificationManager
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onClearNotifications={() => setNotifications([])}
        onTriggerBanner={triggerToast}
      />

      {/* Footer */}
      <footer className="bg-white border-t border-[#F0DFE3] py-6 text-center text-xs text-[#8A727E]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[#573946]">Dra. Karol Suárez · Nutricionista Dietista</span>
            <span className="text-[10px] bg-[#FAF0F3] text-[#DE8287] px-2 py-0.5 rounded-full font-mono">
              +57 302 4708368
            </span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <button
              onClick={() => setIsComplianceOpen(true)}
              className="text-[#DE8287] hover:underline"
            >
              Protección de Datos de Salud (Ley 1581)
            </button>
            <span>·</span>
            <button
              onClick={handleLogout}
              className="hover:underline text-[#7A636F]"
            >
              Cambiar de Portal
            </button>
            <span>·</span>
            <a
              href="https://wa.me/573024708368"
              target="_blank"
              rel="noreferrer"
              className="hover:underline font-mono"
            >
              Atención: 302 4708368
            </a>
          </div>
          <p className="text-[10px] text-[#A58F9B]">
            © {new Date().getFullYear()} Consultorio Nutricional Dra. Karol Suárez. Todos los derechos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}

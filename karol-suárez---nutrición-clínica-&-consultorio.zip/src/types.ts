export type UserRole = 'patient' | 'nutritionist' | 'assistant';

export interface MetricRecord {
  id: string;
  date: string;
  weightKg: number;
  heightCm: number;
  bmi: number;
  bodyFatPercent: number;
  muscleMassKg: number;
  visceralFatLevel: number;
  waistCm: number;
  hipCm: number;
  notes?: string;
}

export interface FoodItem {
  id: string;
  name: string;
  portion: string;
  calories?: number;
  proteinG?: number;
  carbsG?: number;
  fatG?: number;
  fiberG?: number;
  notes?: string;
}

export interface MealItem {
  id: string;
  type: 'desayuno' | 'media_manana' | 'almuerzo' | 'merienda' | 'cena' | 'colacion';
  title: string;
  timeSchedule: string;
  description: string;
  foods: FoodItem[];
  substitutions: string[];
  isCompletedToday?: boolean;
}

export interface MealPlan {
  id: string;
  patientId: string;
  title: string;
  goal: string;
  caloriesTarget: number;
  macros: {
    proteinG: number;
    carbsG: number;
    fatG: number;
    fiberG: number;
  };
  waterLiters: number;
  meals: MealItem[];
  keyRecommendations: string[];
  supplementation?: string[];
  active: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ConsultationNote {
  id: string;
  date: string;
  reason: string;
  subjective: string;
  objective: string;
  assessment: string;
  plan: string;
  nutritionist: string; // Dra. Karol Suárez
}

export interface HealthDataConsent {
  signed: boolean;
  signedAt?: string;
  signerDocument?: string;
  ipMock?: string;
  lawReference: string;
  termsAccepted: boolean;
}

export interface SecurityProfile {
  encryptionAlgorithm: string;
  keyFingerprint: string;
  lastLoginAt: string;
  verifiedEmail: boolean;
  dataAccessAudited: boolean;
  medicalVaultStatus: 'active' | 'pending';
}

export interface PhysicalActivityDetails {
  type: string;
  frequency: string;
  durationMinutesPerSession: number;
  weeklyMinutesTotal: number;
  intensity: 'Baja' | 'Moderada' | 'Alta';
}

export interface Patient {
  id: string;
  name: string;
  profilePhoto?: string;
  documentType: string;
  documentId: string;
  email: string;
  phone: string;
  age: number;
  gender: 'Femenino' | 'Masculino' | 'Otro';
  birthDate: string;
  occupation: string;
  physicalActivityDetails?: PhysicalActivityDetails;
  emergencyContact: {
    name: string;
    phone: string;
    relation: string;
  };
  clinicalHistory: {
    pathologies: string[];
    familyHistory: string[];
    medications: string[];
    allergies: string[];
    intolerances: string[];
    digestiveSymptoms: string[];
    sleepHours: number;
    physicalActivity: string;
    waterHabits: string;
  };
  security: SecurityProfile;
  consent: HealthDataConsent;
  metrics: MetricRecord[];
  activePlanId: string;
  plans: MealPlan[];
  consultationNotes: ConsultationNote[];
  adherenceRate: number; // 0 - 100
  registeredDate: string;
  treatmentStartDate: string;
}

export type AppointmentModality =
  | 'presencial_pamplona'
  | 'presencial_cucuta'
  | 'virtual_meet'
  | 'llamada_telefonica';

export type AppointmentStatus = 'pendiente' | 'confirmada' | 'cancelada' | 'completada';
export type PaymentStatus = 'pendiente' | 'comprobante_subido' | 'pagado' | 'reembolsado';

export interface PaymentVoucher {
  id: string;
  appointmentId: string;
  patientId: string;
  patientName: string;
  amount: number;
  method: 'Bancolombia' | 'Nequi' | 'Daviplata' | 'Llave / Bre-B' | 'Efectivo en Consultorio';
  referenceNumber: string;
  voucherImageOrDoc?: string;
  uploadedAt: string;
  status: 'pendiente_validacion' | 'aprobado' | 'rechazado';
  reviewedByRole?: UserRole;
  reviewedAt?: string;
}

export interface PaymentDetails {
  transactionId: string;
  referenceNumber: string;
  amount: number;
  currency: string;
  method: 'Bancolombia' | 'Nequi' | 'Daviplata' | 'Llave / Bre-B' | 'Efectivo en Consultorio';
  paidAt: string;
  payerName: string;
  payerEmail: string;
  receiptNumber: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  date: string; // YYYY-MM-DD
  time: string; // e.g. 10:00 AM
  type: AppointmentModality;
  status: AppointmentStatus;
  paymentStatus: PaymentStatus;
  paymentDetails?: PaymentDetails;
  paymentVoucher?: PaymentVoucher;
  priceCOP: number;
  reason: string;
  notes?: string;
  emailVerified: boolean;
  createdByRole: UserRole;
  createdAt: string;
  confirmedAt?: string;
  cancelledAt?: string;
  cancellationReason?: string;
}

export interface AvailableSlot {
  id: string;
  date: string;
  time: string;
  isAvailable: boolean;
  isBlocked?: boolean;
  notes?: string;
}

export interface DoctorBankConfig {
  bancolombiaAccount: {
    accountNumber: string;
    accountType: string;
    holderName: string;
    idNumber: string;
  };
  nequiNumber: string;
  nequiHolder: string;
  daviplataNumber: string;
  llaveBreB: string;
  qrCodeUrl: string;
  chatSchedule: string;
  chatRegulations: string[];
}

export interface E2EEMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  senderTitle?: string; // Dra. Karol Suárez or Asistente Consultorio or Paciente
  recipientId: string;
  recipientName: string;
  content: string;
  encryptedPayload: string;
  timestamp: string;
  read: boolean;
}

export interface InAppNotification {
  id: string;
  title: string;
  body: string;
  timestamp: string;
  read: boolean;
  type:
    | 'appointment_created'
    | 'appointment_confirmed'
    | 'appointment_cancelled'
    | 'payment_completed'
    | 'voucher_uploaded'
    | 'chat_message'
    | 'diet_reminder';
  appointmentId?: string;
  forRole?: UserRole | 'all';
  forPatientId?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  quickReplies?: string[];
  escalateToWhatsApp?: boolean;
}

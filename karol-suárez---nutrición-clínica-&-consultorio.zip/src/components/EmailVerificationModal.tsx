import React, { useState, useEffect } from 'react';
import {
  Mail,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  X,
  ArrowRight,
  AlertCircle,
  Copy,
  Check,
  Send,
  Edit2,
} from 'lucide-react';

interface EmailVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  email: string;
  onVerified: (verifiedEmail?: string) => void;
  title?: string;
  description?: string;
}

export const EmailVerificationModal: React.FC<EmailVerificationModalProps> = ({
  isOpen,
  onClose,
  email,
  onVerified,
  title = 'Verificación de Correo Electrónico',
  description = 'Ingresa tu correo electrónico para solicitar el código de seguridad de 6 dígitos y validar tu cita o expediente.',
}) => {
  const [targetEmail, setTargetEmail] = useState(email || '');
  const [code, setCode] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [countdown, setCountdown] = useState(60);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isRequesting, setIsRequesting] = useState(false);
  const [codeRequested, setCodeRequested] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);

  // Sync initial email
  useEffect(() => {
    if (isOpen) {
      const initial = email || '';
      setTargetEmail(initial);
      setCode('');
      setErrorMsg('');
      // If an email was already provided, auto-generate initial code
      if (initial && initial.includes('@')) {
        const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
        setGeneratedCode(randomCode);
        setCodeRequested(true);
        setCountdown(60);
      } else {
        setCodeRequested(false);
        setGeneratedCode('');
      }
    }
  }, [isOpen, email]);

  useEffect(() => {
    if (!isOpen || countdown <= 0 || !codeRequested) return;
    const timer = setInterval(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isOpen, countdown, codeRequested]);

  if (!isOpen) return null;

  const handleRequestCode = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanEmail = targetEmail.trim();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setErrorMsg('Por favor ingresa un correo electrónico válido (ej. tu_nombre@correo.com).');
      return;
    }

    setIsRequesting(true);
    setErrorMsg('');

    setTimeout(() => {
      const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedCode(randomCode);
      setCodeRequested(true);
      setCountdown(60);
      setCode('');
      setIsRequesting(false);
    }, 500);
  };

  const handleCopyCode = () => {
    navigator.clipboard?.writeText(generatedCode);
    setCopied(true);
    setCode(generatedCode);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!codeRequested) {
      handleRequestCode();
      return;
    }

    if (code.trim() !== generatedCode) {
      setErrorMsg('El código de 6 dígitos no coincide con el enviado a tu correo.');
      return;
    }

    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      onVerified(targetEmail.trim());
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] p-6 sm:p-7 space-y-5 overflow-hidden my-auto">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#DE8287]/15 flex items-center justify-center text-[#DE8287]">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
                {title}
              </h3>
              <p className="text-xs text-[#876E7B] mt-0.5">
                Seguridad & Autenticidad Clínica · Dra. Karol Suárez
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-[#9A818E] hover:text-[#523A46] hover:bg-[#FAF4F6] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-[#6B5360] leading-relaxed">
          {description}
        </p>

        {/* 1. INPUT DE CORREO ELECTRÓNICO PARA SOLICITAR VERIFICACIÓN */}
        <div className="p-4 bg-[#FAF5F7] rounded-2xl border border-[#F0E0E4] space-y-2.5">
          <label className="block text-xs font-semibold text-[#523A46]">
            Correo Electrónico Destino para Verificación *
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Mail className="w-4 h-4 text-[#8C7480] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={targetEmail}
                onChange={(e) => {
                  setTargetEmail(e.target.value);
                  setErrorMsg('');
                }}
                placeholder="ejemplo@correo.com"
                className="w-full pl-9 pr-3 py-2.5 text-xs bg-white border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287] font-mono text-[#523A46]"
              />
            </div>
            <button
              type="button"
              onClick={() => handleRequestCode()}
              disabled={isRequesting || !targetEmail.trim()}
              className="px-4 py-2.5 bg-[#DE8287] hover:bg-[#C4676D] disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0 flex items-center justify-center gap-1.5"
            >
              {isRequesting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Solicitando...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>{codeRequested ? 'Reenviar Código' : 'Solicitar Código'}</span>
                </>
              )}
            </button>
          </div>
          {codeRequested && (
            <p className="text-[11px] text-emerald-800 font-medium flex items-center gap-1 mt-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Código de verificación solicitado para: <strong>{targetEmail}</strong></span>
            </p>
          )}
        </div>

        {/* 2. SIMULADOR EN VIVO DE BANDEJA DE ENTRADA (CÓDIGO DE 6 DÍGITOS GENERADO) */}
        {codeRequested && generatedCode && (
          <div className="p-3.5 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-2 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <span className="font-semibold flex items-center gap-1.5 text-[11px] text-emerald-800 uppercase tracking-wider">
                <Mail className="w-3.5 h-3.5 text-emerald-600" />
                Bandeja de Entrada (Simulador en Vivo)
              </span>
              <button
                type="button"
                onClick={handleCopyCode}
                className="text-[11px] text-emerald-700 hover:text-emerald-900 font-semibold underline flex items-center gap-1"
              >
                {copied ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-700" />
                    <span>Copiado</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-emerald-700" />
                    <span>Auto-completar</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-[11px] text-emerald-900 leading-snug">
              De: <strong>seguridad@karolsuarez.com</strong><br />
              Tu código de verificación de 6 dígitos es:
            </p>
            <div className="bg-white py-1.5 px-3 rounded-xl border border-emerald-300 font-mono text-center text-xl font-bold tracking-widest text-emerald-900">
              {generatedCode}
            </div>
          </div>
        )}

        {/* 3. FORMULARIO PARA DIGITAR EL CÓDIGO */}
        {codeRequested ? (
          <form onSubmit={handleSubmit} className="space-y-4 animate-in fade-in duration-200">
            <div>
              <label className="block text-xs font-semibold text-[#523A46] mb-1.5 text-center">
                Digita el código de 6 dígitos recibido:
              </label>
              <input
                type="text"
                maxLength={6}
                required
                value={code}
                onChange={(e) => {
                  setCode(e.target.value.replace(/\D/g, ''));
                  setErrorMsg('');
                }}
                placeholder="••••••"
                className="w-full py-3 px-4 text-center tracking-[0.4em] font-mono text-xl bg-[#FCFAF9] border border-[#E2CFD4] rounded-2xl outline-none focus:border-[#DE8287] focus:ring-2 focus:ring-[#DE8287]/20 transition-all text-[#523A46]"
              />
            </div>

            {errorMsg && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <p>{errorMsg}</p>
              </div>
            )}

            <div className="flex items-center justify-between text-xs text-[#876E7B]">
              {countdown > 0 ? (
                <span>Reenviar código en {countdown}s</span>
              ) : (
                <button
                  type="button"
                  onClick={() => handleRequestCode()}
                  className="text-[#DE8287] hover:underline font-semibold"
                >
                  Solicitar nuevo código
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="text-[#876E7B] hover:text-[#523A46]"
              >
                Cancelar
              </button>
            </div>

            <button
              type="submit"
              disabled={code.length !== 6 || isVerifying}
              className="w-full py-3 bg-[#DE8287] hover:bg-[#C4676D] disabled:opacity-50 text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              {isVerifying ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Validando código...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirmar & Validar Correo</span>
                </>
              )}
            </button>
          </form>
        ) : (
          <div>
            {errorMsg && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 flex items-start gap-2 mb-3">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <p>{errorMsg}</p>
              </div>
            )}
            <button
              type="button"
              onClick={() => handleRequestCode()}
              disabled={isRequesting || !targetEmail.trim()}
              className="w-full py-3 bg-[#DE8287] hover:bg-[#C4676D] disabled:opacity-50 text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Solicitar Código de Verificación al Correo</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

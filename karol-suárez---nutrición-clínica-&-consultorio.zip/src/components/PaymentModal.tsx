import React, { useState } from 'react';
import {
  CreditCard,
  ShieldCheck,
  CheckCircle2,
  Lock,
  X,
  FileText,
  Printer,
  Download,
  Building,
  Smartphone,
  Banknote,
  QrCode,
  Copy,
  Check,
  Upload,
  AlertCircle,
  Receipt,
  Sparkles,
} from 'lucide-react';
import { Appointment, DoctorBankConfig, PaymentDetails, PaymentVoucher, UserRole } from '../types';
import { BrandLogo } from './BrandLogo';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment;
  bankConfig: DoctorBankConfig;
  userRole?: UserRole;
  onUploadVoucher?: (appointmentId: string, voucher: PaymentVoucher) => void;
  onPaymentSuccess?: (appointmentId: string, details: PaymentDetails) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  appointment,
  bankConfig,
  userRole = 'patient',
  onUploadVoucher,
  onPaymentSuccess,
}) => {
  const [selectedMethod, setSelectedMethod] = useState<'Bancolombia' | 'Nequi' | 'Daviplata' | 'Llave / Bre-B' | 'Efectivo en Consultorio'>('Bancolombia');
  const [voucherReference, setVoucherReference] = useState('');
  const [voucherFileNote, setVoucherFileNote] = useState('');
  const [voucherPreview, setVoucherPreview] = useState<string | null>(null);
  const [copiedItem, setCopiedItem] = useState<string | null>(null);
  const [isSubmittingVoucher, setIsSubmittingVoucher] = useState(false);
  const [voucherSent, setVoucherSent] = useState(false);

  if (!isOpen) return null;

  const handleCopy = (text: string, identifier: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedItem(identifier);
    setTimeout(() => setCopiedItem(null), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setVoucherPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!voucherReference.trim()) return;

    setIsSubmittingVoucher(true);

    setTimeout(() => {
      const newVoucher: PaymentVoucher = {
        id: `vouch-${Date.now()}`,
        appointmentId: appointment.id,
        patientId: appointment.patientId,
        patientName: appointment.patientName,
        amount: appointment.priceCOP || 160000,
        method: selectedMethod,
        referenceNumber: voucherReference.trim(),
        voucherImageOrDoc: voucherPreview || `Comprobante ${selectedMethod} Ref: ${voucherReference.trim()}`,
        uploadedAt: new Date().toISOString(),
        status: 'pendiente_validacion',
      };

      if (onUploadVoucher) {
        onUploadVoucher(appointment.id, newVoucher);
      }
      setIsSubmittingVoucher(false);
      setVoucherSent(true);
    }, 1000);
  };

  // Staff action: Doctor or Assistant confirms payment immediately
  const handleStaffApprovePayment = () => {
    const generatedReceipt = `REC-KS-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
    const details: PaymentDetails = {
      transactionId: `TXN-${Math.floor(1000000 + Math.random() * 9000000)}`,
      referenceNumber: appointment.paymentVoucher?.referenceNumber || voucherReference || `CONF-${Date.now().toString().slice(-6)}`,
      amount: appointment.priceCOP || 160000,
      currency: 'COP',
      method: appointment.paymentVoucher?.method || selectedMethod,
      paidAt: new Date().toISOString(),
      payerName: appointment.patientName,
      payerEmail: appointment.patientEmail,
      receiptNumber: generatedReceipt,
    };

    if (onPaymentSuccess) {
      onPaymentSuccess(appointment.id, details);
    }
  };

  const handlePrintOrPdf = () => {
    window.print();
  };

  const isAlreadyPaid = appointment.paymentStatus === 'pagado';
  const hasVoucher = appointment.paymentStatus === 'comprobante_subido' || !!appointment.paymentVoucher || voucherSent;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#FAF3F5] via-[#FFF8F9] to-[#F5EFF9] p-5 border-b border-[#F0DFE3] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#DE8287]/15 flex items-center justify-center text-[#DE8287]">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
                {isAlreadyPaid ? 'Comprobante Oficial de Pago' : 'Información para Transferencia Bancaria'}
              </h3>
              <p className="text-xs text-[#876E7B]">
                Consultorio Dra. Karol Suárez · Cuentas Oficiales
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-[#9A818E] hover:text-[#523A46] hover:bg-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-xs text-[#523A46]">
          {/* Appointment Cost Summary */}
          <div className="p-4 rounded-2xl bg-[#FAF5F7] border border-[#F0E0E4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="font-semibold text-sm text-[#523A46]">
                {appointment.reason || 'Consulta Nutricional Especializada'}
              </p>
              <p className="text-[11px] text-[#876E7B] mt-0.5">
                Paciente: <strong className="text-[#523A46]">{appointment.patientName}</strong> · Fecha: {appointment.date} ({appointment.time})
              </p>
              <p className="text-[10px] text-[#DE8287] font-semibold mt-0.5">
                Modalidad: {
                  appointment.type === 'presencial_pamplona' ? 'Presencial Pamplona' :
                  appointment.type === 'presencial_cucuta' ? 'Presencial Cúcuta' :
                  appointment.type === 'virtual_meet' ? 'Virtual Google Meet' : 'Llamada Telefónica'
                }
              </p>
            </div>
            <div className="text-right shrink-0">
              <span className="text-[10px] text-[#876E7B] uppercase tracking-wider font-semibold block">Valor de la Consulta</span>
              <p className="text-xl sm:text-2xl font-black text-[#523A46] font-mono leading-none mt-0.5">
                ${(appointment.priceCOP || 160000).toLocaleString('es-CO')} <span className="text-xs font-normal">COP</span>
              </p>
            </div>
          </div>

          {/* VIEW 1: ALREADY PAID - OFFICIAL RECEIPT */}
          {isAlreadyPaid ? (
            <div className="space-y-5">
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <p className="font-bold text-xs">¡Pago Confirmado y Validado!</p>
                  <p className="text-[11px]">La cita se encuentra en estado de confirmación total en la agenda.</p>
                </div>
              </div>

              {/* Printable / Downloadable Receipt Box */}
              <div className="bg-[#FAF7F8] p-5 sm:p-6 rounded-2xl border border-[#EEDDE1] space-y-4 print-area">
                <div className="flex items-center justify-between border-b border-[#E8D4DA] pb-3">
                  <BrandLogo size="sm" variant="horizontal" />
                  <div className="text-right">
                    <span className="text-[10px] text-[#876E7B] uppercase tracking-wider block font-semibold">Recibo Oficial</span>
                    <span className="font-mono text-xs font-bold text-[#523A46]">
                      {appointment.paymentDetails?.receiptNumber || 'REC-KS-2026-089'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs text-[#523A46]">
                  <div>
                    <span className="text-[#876E7B] text-[11px] block">Paciente:</span>
                    <strong>{appointment.paymentDetails?.payerName || appointment.patientName}</strong>
                  </div>
                  <div>
                    <span className="text-[#876E7B] text-[11px] block">Fecha de Consulta:</span>
                    <strong>{appointment.date} ({appointment.time})</strong>
                  </div>
                  <div>
                    <span className="text-[#876E7B] text-[11px] block">Método de Transferencia:</span>
                    <strong>{appointment.paymentDetails?.method || 'Bancolombia / Nequi'}</strong>
                  </div>
                  <div>
                    <span className="text-[#876E7B] text-[11px] block">No. Transacción / Ref:</span>
                    <span className="font-mono font-bold text-[#DE8287]">
                      {appointment.paymentDetails?.transactionId || 'TXN-9842187'}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#E8D4DA] flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-[#523A46] block">Total Cancelado:</span>
                    <span className="text-[10px] text-[#876E7B]">Atención Médica Nutricional</span>
                  </div>
                  <span className="text-xl font-mono font-black text-[#523A46]">
                    ${(appointment.priceCOP || 160000).toLocaleString('es-CO')} COP
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={handlePrintOrPdf}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-white hover:bg-[#FAF4F6] text-[#523A46] text-xs font-semibold rounded-2xl border border-[#E2CFD4] shadow-2xs transition-colors"
                >
                  <Download className="w-4 h-4 text-[#DE8287]" />
                  <span>Descargar Recibo en PDF / Imprimir</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full sm:w-auto px-5 py-2.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors"
                >
                  Cerrar
                </button>
              </div>
            </div>
          ) : (
            /* VIEW 2: BANK TRANSFER DETAILS & VOUCHER UPLOAD */
            <div className="space-y-5">
              {/* Transfer Destination Accounts */}
              <div>
                <label className="block font-bold uppercase tracking-wider text-[11px] text-[#7A636F] mb-2">
                  Cuentas Habilitadas para Realizar la Transferencia:
                </label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {/* Bancolombia */}
                  <div className="p-3.5 rounded-2xl bg-[#FCFAF9] border border-[#EEDDE1] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#523A46] flex items-center gap-1.5">
                        <Building className="w-4 h-4 text-amber-600" />
                        Bancolombia ({bankConfig.bancolombiaAccount.accountType})
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopy(bankConfig.bancolombiaAccount.accountNumber, 'bancolombia')}
                        className="text-[10px] text-[#DE8287] hover:underline font-semibold flex items-center gap-1"
                      >
                        {copiedItem === 'bancolombia' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedItem === 'bancolombia' ? 'Copiado' : 'Copiar'}</span>
                      </button>
                    </div>
                    <div className="bg-white p-2 rounded-xl border border-[#EFE2E5] font-mono font-bold text-sm text-[#523A46]">
                      {bankConfig.bancolombiaAccount.accountNumber}
                    </div>
                    <p className="text-[10px] text-[#8C7480]">
                      Titular: <strong>{bankConfig.bancolombiaAccount.holderName}</strong> ({bankConfig.bancolombiaAccount.idNumber})
                    </p>
                  </div>

                  {/* Nequi & Daviplata */}
                  <div className="p-3.5 rounded-2xl bg-[#FCFAF9] border border-[#EEDDE1] space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-[#523A46] flex items-center gap-1.5">
                        <Smartphone className="w-4 h-4 text-[#8C74B0]" />
                        Nequi / Daviplata
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopy(bankConfig.nequiNumber.replace(/\s+/g, ''), 'nequi')}
                        className="text-[10px] text-[#DE8287] hover:underline font-semibold flex items-center gap-1"
                      >
                        {copiedItem === 'nequi' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedItem === 'nequi' ? 'Copiado' : 'Copiar'}</span>
                      </button>
                    </div>
                    <div className="bg-white p-2 rounded-xl border border-[#EFE2E5] font-mono font-bold text-sm text-[#8C74B0]">
                      {bankConfig.nequiNumber}
                    </div>
                    <p className="text-[10px] text-[#8C7480]">
                      Titular: <strong>{bankConfig.nequiHolder}</strong> · Llave Bre-B: <span className="font-mono">{bankConfig.llaveBreB}</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* QR Code Container */}
              <div className="p-4 bg-[#FAF5F7] rounded-2xl border border-[#EEDDE1] flex flex-col sm:flex-row items-center gap-4">
                <div className="w-28 h-28 bg-white p-1 rounded-2xl border border-[#E2CFD4] shadow-2xs shrink-0 flex items-center justify-center">
                  <img
                    src={bankConfig.qrCodeUrl}
                    alt="Código QR de Pago Karol Suárez"
                    className="w-full h-full object-contain rounded-xl"
                  />
                </div>
                <div className="space-y-1 text-center sm:text-left">
                  <span className="inline-flex items-center gap-1 text-[10px] bg-white px-2 py-0.5 rounded-full border border-[#E8D4D9] text-[#DE8287] font-bold">
                    <QrCode className="w-3 h-3" />
                    Código QR Oficial
                  </span>
                  <h4 className="font-bold text-sm text-[#523A46]">
                    Escanea directamente desde tu App Bancaria o Nequi
                  </h4>
                  <p className="text-[11px] text-[#7A636F]">
                    Abre la aplicación de tu banco o Nequi, selecciona &ldquo;Escanear QR&rdquo;, digita el valor de la consulta y descarga el comprobante.
                  </p>
                </div>
              </div>

              {/* Staff Direct Action (if viewing as doctor or assistant) */}
              {(userRole === 'nutritionist' || userRole === 'assistant') && (
                <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <p className="font-bold text-xs">Control Profesional de Caja</p>
                    <p className="text-[11px] text-amber-800">
                      Como {userRole === 'nutritionist' ? 'Dra. Karol Suárez' : 'Asistente'}, puedes validar el pago y emitir el recibo inmediatamente.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleStaffApprovePayment}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold rounded-xl text-xs shadow-xs transition-colors shrink-0"
                  >
                    Aprobar Pago y Confirmar Cita
                  </button>
                </div>
              )}

              {/* Voucher submission form */}
              <form onSubmit={handleSubmitVoucher} className="space-y-4 pt-2 border-t border-[#F0DFE3]">
                <div className="space-y-1">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-[#523A46] flex items-center gap-1.5">
                    <Upload className="w-3.5 h-3.5 text-[#DE8287]" />
                    Registrar Comprobante de Transferencia:
                  </h4>
                  <p className="text-[11px] text-[#876E7B]">
                    Una vez realizada la transferencia, sube aquí tu comprobante o escribe el número de referencia para que la Dra. Karol o el asistente confirmen tu cita.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold mb-1 text-[11px]">Medio Utilizado *</label>
                    <select
                      value={selectedMethod}
                      onChange={(e) => setSelectedMethod(e.target.value as any)}
                      className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                    >
                      <option value="Bancolombia">Bancolombia (Transferencia)</option>
                      <option value="Nequi">Nequi</option>
                      <option value="Daviplata">Daviplata</option>
                      <option value="Llave / Bre-B">Llave / Bre-B</option>
                      <option value="Efectivo en Consultorio">Pagar en Efectivo al llegar al Consultorio</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold mb-1 text-[11px]">No. de Aprobación / Referencia *</label>
                    <input
                      type="text"
                      required
                      value={voucherReference}
                      onChange={(e) => setVoucherReference(e.target.value)}
                      placeholder="ej. 9840212 o M10294"
                      className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287] font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold mb-1 text-[11px]">Adjuntar Foto o Captura del Comprobante (Opcional):</label>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileUpload}
                    className="w-full text-xs text-[#7A636F] file:mr-3 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-[#FAF0F3] file:text-[#DE8287] hover:file:bg-[#FCE6EB]"
                  />
                </div>

                {hasVoucher && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Comprobante registrado. La Dra. Karol o el asistente lo validarán en la agenda.</span>
                  </div>
                )}

                <div className="flex items-center justify-between pt-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-medium text-[#7A636F] hover:bg-[#FAF4F6] rounded-xl"
                  >
                    Cerrar
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingVoucher || !voucherReference.trim()}
                    className="px-5 py-2.5 bg-[#DE8287] hover:bg-[#C4676D] disabled:opacity-50 text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{isSubmittingVoucher ? 'Enviando comprobante...' : 'Registrar Comprobante de Pago'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  ShieldCheck,
  FileText,
  Activity,
  AlertTriangle,
  Lock,
  Calendar,
  X,
  Save,
  Check,
  Phone,
  Mail,
  Printer,
} from 'lucide-react';
import { Patient, ConsultationNote } from '../../types';

interface ClinicalRecordsProps {
  patients: Patient[];
  selectedPatientId: string;
  onSelectPatient: (id: string) => void;
  onUpdatePatient: (patient: Patient) => void;
  onOpenComplianceModal: (patient: Patient) => void;
  onAddNewPatient: (patient: Patient) => void;
}

export const ClinicalRecords: React.FC<ClinicalRecordsProps> = ({
  patients,
  selectedPatientId,
  onSelectPatient,
  onUpdatePatient,
  onOpenComplianceModal,
  onAddNewPatient,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'anamnesis' | 'evolution' | 'consent'>('anamnesis');
  const [showNewPatientModal, setShowNewPatientModal] = useState(false);
  const [showNewNoteModal, setShowNewNoteModal] = useState(false);

  // New Note state
  const [noteReason, setNoteReason] = useState('');
  const [noteSubjective, setNoteSubjective] = useState('');
  const [noteObjective, setNoteObjective] = useState('');
  const [noteAssessment, setNoteAssessment] = useState('');
  const [notePlan, setNotePlan] = useState('');

  // New Patient state
  const [newPatName, setNewPatName] = useState('');
  const [newPatDoc, setNewPatDoc] = useState('');
  const [newPatPhone, setNewPatPhone] = useState('');
  const [newPatEmail, setNewPatEmail] = useState('');
  const [newPatAge, setNewPatAge] = useState('');
  const [newPatWeight, setNewPatWeight] = useState('');
  const [newPatHeight, setNewPatHeight] = useState('');
  const [newPatAllergies, setNewPatAllergies] = useState('');
  const [newPatPathologies, setNewPatPathologies] = useState('');

  const filteredPatients = patients.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.documentId.includes(searchTerm) ||
      p.clinicalHistory.pathologies.some((patho) =>
        patho.toLowerCase().includes(searchTerm.toLowerCase())
      )
  );

  const currentPatient =
    patients.find((p) => p.id === selectedPatientId) || patients[0];

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPatient) return;
    const newNote: ConsultationNote = {
      id: `note-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      reason: noteReason,
      subjective: noteSubjective,
      objective: noteObjective,
      assessment: noteAssessment,
      plan: notePlan,
          nutritionist: 'Dra. Karol Suárez - Nutricionista Dietista',
    };
    const updated: Patient = {
      ...currentPatient,
      consultationNotes: [newNote, ...(currentPatient.consultationNotes || [])],
    };
    onUpdatePatient(updated);
    setShowNewNoteModal(false);
    setNoteReason('');
    setNoteSubjective('');
    setNoteObjective('');
    setNoteAssessment('');
    setNotePlan('');
  };

  const handleCreatePatient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPatName || !newPatDoc) return;
    const weightNum = parseFloat(newPatWeight) || 60;
    const heightNum = parseFloat(newPatHeight) || 165;
    const heightM = heightNum / 100;
    const bmiVal = parseFloat((weightNum / (heightM * heightM)).toFixed(1));

    const newPat: Patient = {
      id: `pat-${Date.now()}`,
      name: newPatName,
      documentType: 'CC',
      documentId: newPatDoc,
      email: newPatEmail || 'paciente@correo.com',
      phone: newPatPhone || '300 000 0000',
      age: parseInt(newPatAge, 10) || 30,
      gender: 'Femenino',
      birthDate: '1995-01-01',
      occupation: 'General',
      treatmentStartDate: new Date().toISOString().split('T')[0],
      emergencyContact: {
        name: 'Contacto de Emergencia',
        phone: '300 000 0000',
        relation: 'Familiar',
      },
      security: {
        encryptionAlgorithm: 'AES-256-GCM / X25519-E2EE',
        keyFingerprint: `SHA256:${Math.random().toString(36).slice(2, 6)}:${Math.random().toString(36).slice(2, 6)}:91a2`,
        lastLoginAt: new Date().toISOString(),
        verifiedEmail: true,
        dataAccessAudited: true,
        medicalVaultStatus: 'active',
      },
      clinicalHistory: {
        pathologies: newPatPathologies ? newPatPathologies.split(',').map((s) => s.trim()) : [],
        familyHistory: [],
        medications: [],
        allergies: newPatAllergies ? newPatAllergies.split(',').map((s) => s.trim()) : [],
        intolerances: [],
        digestiveSymptoms: [],
        sleepHours: 7,
        physicalActivity: 'Moderada',
        waterHabits: '2L al día',
      },
      consent: {
        signed: true,
        signedAt: new Date().toISOString(),
        signerDocument: newPatDoc,
        lawReference: 'Ley 1581 de 2012 y Decreto 1377 de 2013 (Habeas Data Salud)',
        termsAccepted: true,
      },
      adherenceRate: 100,
      registeredDate: new Date().toISOString().split('T')[0],
      activePlanId: `plan-${Date.now()}`,
      metrics: [
        {
          id: `m-init-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          weightKg: weightNum,
          heightCm: heightNum,
          bmi: bmiVal,
          bodyFatPercent: 25.0,
          muscleMassKg: 24.0,
          visceralFatLevel: 4,
          waistCm: 75,
          hipCm: 99,
          notes: 'Consulta de apertura de historia clínica',
        },
      ],
      plans: [],
      consultationNotes: [
        {
          id: `c-init-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          reason: 'Apertura de Historia Clínica y Valoración Inicial',
          subjective: 'Ingreso inicial a consulta con Karol Suárez.',
          objective: `Peso: ${weightNum}kg, Altura: ${heightNum}cm, IMC: ${bmiVal}.`,
          assessment: 'Paciente apto para inicio de pauta nutricional personalizada.',
          plan: 'Elaboración de plan de alimentación y seguimiento mensual.',
              nutritionist: 'Dra. Karol Suárez - Nutricionista Dietista',
        },
      ],
    };

    onAddNewPatient(newPat);
    setShowNewPatientModal(false);
    setNewPatName('');
    setNewPatDoc('');
    setNewPatPhone('');
    setNewPatEmail('');
    setNewPatAge('');
    setNewPatWeight('');
    setNewPatHeight('');
    setNewPatAllergies('');
    setNewPatPathologies('');
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#EEDDE1] shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-lg sm:text-xl text-[#573946] font-brand-title">
              Historias Clínicas Nutricionales
            </h3>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-100/70 px-2.5 py-0.5 rounded-full border border-emerald-200">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Ley 1581 Habeas Data
            </span>
          </div>
          <p className="text-xs text-[#876E7B] mt-0.5">
            Gestión protegida de antecedentes patológicos, consentimientos informados y evolución SOAP.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#9A818E]" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por paciente, cédula..."
              className="pl-9 pr-3.5 py-2 text-xs bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287] w-52 sm:w-64"
            />
          </div>
          <button
            onClick={() => setShowNewPatientModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Nuevo Paciente</span>
          </button>
        </div>
      </div>

      {/* Main split view */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left: Patient Directory */}
        <div className="lg:col-span-4 space-y-2.5">
          <h4 className="text-xs font-bold text-[#7A636F] uppercase tracking-wider px-1">
            Pacientes Registrados ({filteredPatients.length})
          </h4>
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {filteredPatients.map((p) => {
              const isSelected = p.id === currentPatient?.id;
              return (
                <div
                  key={p.id}
                  onClick={() => onSelectPatient(p.id)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#FDF3F5] border-[#DE8287] shadow-2xs ring-1 ring-[#DE8287]/20'
                      : 'bg-white border-[#EEDDE1] hover:border-[#DE8287]/40 hover:bg-[#FAF8F9]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <p className="font-bold text-sm text-[#523A46] truncate">{p.name}</p>
                    <span className="text-[10px] font-mono text-[#8C7480]">
                      {p.documentType} {p.documentId}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mt-1.5 text-xs text-[#7A636F]">
                    <span>{p.age} años</span>
                    <span>·</span>
                    <span>{p.phone}</span>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-[#F0E0E4] flex items-center justify-between text-[11px]">
                    <span
                      className={`inline-flex items-center gap-1 ${
                        p.consent?.signed ? 'text-emerald-700 font-medium' : 'text-amber-700 font-medium'
                      }`}
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      {p.consent?.signed ? 'Consentimiento Firmado' : 'Consentimiento Pendiente'}
                    </span>
                    <span className="text-[#DE8287] font-semibold">
                      Adherencia {p.adherenceRate}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Patient Details */}
        {currentPatient && (
          <div className="lg:col-span-8 bg-white rounded-2xl border border-[#EEDDE1] shadow-2xs overflow-hidden flex flex-col">
            {/* Header */}
            <div className="bg-gradient-to-r from-[#FAF3F5] via-[#FFF8F9] to-[#F5EFF9] p-5 border-b border-[#F0DFE3] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-lg sm:text-xl text-[#523A46] font-brand-title">
                    {currentPatient.name}
                  </h3>
                  <span className="text-xs bg-white px-2 py-0.5 rounded-full border border-[#E2CFD4] font-mono text-[#7A636F]">
                    {currentPatient.documentType} {currentPatient.documentId}
                  </span>
                </div>
                <p className="text-xs text-[#876E7B] mt-0.5">
                  Tel: {currentPatient.phone} · {currentPatient.email} · Inicio: {currentPatient.treatmentStartDate || currentPatient.registeredDate}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-white hover:bg-[#FAF4F6] border border-[#E2CFD4] text-[#634752] text-xs font-medium rounded-xl shadow-2xs transition-colors flex items-center gap-1.5"
                  title="Imprimir historia clínica y plan nutricional"
                >
                  <Printer className="w-3.5 h-3.5 text-[#DE8287]" />
                  <span>Imprimir Plan / Historia</span>
                </button>
                <button
                  onClick={() => onOpenComplianceModal(currentPatient)}
                  className="px-3 py-1.5 bg-white hover:bg-[#FAF4F6] border border-[#E2CFD4] text-[#634752] text-xs font-medium rounded-xl shadow-2xs transition-colors flex items-center gap-1.5"
                >
                  <Lock className="w-3.5 h-3.5 text-[#DE8287]" />
                  <span>Protección Datos</span>
                </button>
                <button
                  onClick={() => setShowNewNoteModal(true)}
                  className="px-3 py-1.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Añadir Nota SOAP</span>
                </button>
              </div>
            </div>

            {/* Sub Tabs */}
            <div className="flex border-b border-[#F0DFE3] px-5 bg-[#FAF7F8]">
              <button
                onClick={() => setActiveTab('anamnesis')}
                className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors ${
                  activeTab === 'anamnesis'
                    ? 'border-[#DE8287] text-[#DE8287]'
                    : 'border-transparent text-[#876E7B] hover:text-[#523A46]'
                }`}
              >
                Ficha Médica & Antecedentes
              </button>
              <button
                onClick={() => setActiveTab('evolution')}
                className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors ${
                  activeTab === 'evolution'
                    ? 'border-[#DE8287] text-[#DE8287]'
                    : 'border-transparent text-[#876E7B] hover:text-[#523A46]'
                }`}
              >
                Evolución Clínica (SOAP) ({currentPatient.consultationNotes?.length || 0})
              </button>
              <button
                onClick={() => setActiveTab('consent')}
                className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors ${
                  activeTab === 'consent'
                    ? 'border-[#DE8287] text-[#DE8287]'
                    : 'border-transparent text-[#876E7B] hover:text-[#523A46]'
                }`}
              >
                Bóveda Criptográfica & Consentimiento
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-6 space-y-5 flex-1 overflow-y-auto">
              {activeTab === 'anamnesis' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="p-4 bg-[#FAF7F8] rounded-xl border border-[#F2E5E8] space-y-2">
                      <p className="font-semibold text-xs text-[#523A46] uppercase tracking-wider flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-amber-500" />
                        Patologías & Diagnósticos Previos:
                      </p>
                      {currentPatient.clinicalHistory.pathologies.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5">
                          {currentPatient.clinicalHistory.pathologies.map((patho, idx) => (
                            <span
                              key={idx}
                              className="px-2.5 py-1 bg-white border border-[#E8D4DA] text-xs font-medium text-[#573946] rounded-lg"
                            >
                              {patho}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-[#8A727E]">Sin patologías registradas</p>
                      )}
                    </div>
                    <div className="p-4 bg-[#FAF7F8] rounded-xl border border-[#F2E5E8] space-y-2">
                      <p className="font-semibold text-xs text-[#523A46] uppercase tracking-wider flex items-center gap-1.5">
                        <Activity className="w-4 h-4 text-[#DE8287]" />
                        Alergias & Intolerancias:
                      </p>
                      <div className="space-y-1 text-xs">
                        <p>
                          <span className="font-medium text-[#523A46]">Alergias:</span>{' '}
                          {currentPatient.clinicalHistory.allergies.join(', ') || 'Ninguna'}
                        </p>
                        <p>
                          <span className="font-medium text-[#523A46]">Intolerancias:</span>{' '}
                          {currentPatient.clinicalHistory.intolerances.join(', ') || 'Ninguna'}
                        </p>
                        <p>
                          <span className="font-medium text-[#523A46]">Síntomas digestivos:</span>{' '}
                          {currentPatient.clinicalHistory.digestiveSymptoms.join(', ') || 'Sin síntomas'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-[#FAF7F8] rounded-xl border border-[#F2E5E8] space-y-3">
                    <p className="font-semibold text-xs text-[#523A46] uppercase tracking-wider">
                      Estilo de Vida, Fármacos & Hábitos:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-[#634856]">
                      <div className="p-3 bg-white rounded-lg border border-[#EFE2E5]">
                        <p className="font-bold text-[#523A46] mb-1">Medicamentos Actuales</p>
                        <p>{currentPatient.clinicalHistory.medications.join(', ') || 'Sin fármacos'}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border border-[#EFE2E5]">
                        <p className="font-bold text-[#523A46] mb-1">Actividad Física</p>
                        <p>{currentPatient.clinicalHistory.physicalActivity}</p>
                      </div>
                      <div className="p-3 bg-white rounded-lg border border-[#EFE2E5]">
                        <p className="font-bold text-[#523A46] mb-1">Sueño & Hidratación</p>
                        <p>{currentPatient.clinicalHistory.sleepHours}h de sueño · {currentPatient.clinicalHistory.waterHabits}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'evolution' && (
                <div className="space-y-4">
                  {currentPatient.consultationNotes && currentPatient.consultationNotes.length > 0 ? (
                    currentPatient.consultationNotes.map((note) => (
                      <div
                        key={note.id}
                        className="p-4 rounded-xl border border-[#EEDDE1] bg-[#FCFAF9] space-y-3"
                      >
                        <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-2">
                          <span className="font-bold text-sm text-[#523A46]">{note.reason}</span>
                          <span className="text-xs text-[#8A727E] font-mono">{note.date}</span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                          <div className="p-3 bg-white rounded-lg border border-[#F0E3E6]">
                            <p className="font-bold text-[#DE8287] text-[11px] mb-1">
                              [S] SUBJETIVO:
                            </p>
                            <p className="text-[#634856]">{note.subjective}</p>
                          </div>
                          <div className="p-3 bg-white rounded-lg border border-[#F0E3E6]">
                            <p className="font-bold text-[#B7A6CF] text-[11px] mb-1">
                              [O] OBJETIVO:
                            </p>
                            <p className="text-[#634856]">{note.objective}</p>
                          </div>
                          <div className="p-3 bg-white rounded-lg border border-[#F0E3E6]">
                            <p className="font-bold text-amber-700 text-[11px] mb-1">
                              [A] ANÁLISIS / DIAGNÓSTICO NUTRICIONAL:
                            </p>
                            <p className="text-[#634856]">{note.assessment}</p>
                          </div>
                          <div className="p-3 bg-white rounded-lg border border-[#F0E3E6]">
                            <p className="font-bold text-emerald-700 text-[11px] mb-1">
                              [P] PLAN & PRESCRIPCIÓN DIETÉTICA:
                            </p>
                            <p className="text-[#634856]">{note.plan}</p>
                          </div>
                        </div>
                        <p className="text-[11px] text-right text-[#967C87] italic">
                          Firma: {note.nutritionist}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-[#8A727E]">Sin notas de consulta registradas.</p>
                  )}
                </div>
              )}

              {activeTab === 'consent' && (
                <div className="p-5 bg-[#FAF7F8] rounded-xl border border-[#F0DFE3] space-y-4 text-xs text-[#634856]">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-sm text-[#523A46] flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-emerald-600" />
                      Estado de Consentimiento Informado & Criptografía
                    </h4>
                    <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                      Consentimiento Activo
                    </span>
                  </div>
                  <div className="p-3.5 bg-white rounded-xl border border-[#EFE2E5] space-y-1 font-mono text-[11px]">
                    <p><strong>Titular:</strong> {currentPatient.name}</p>
                    <p><strong>Documento:</strong> {currentPatient.documentType} {currentPatient.documentId}</p>
                    <p><strong>Cifrado Activo:</strong> {currentPatient.security.encryptionAlgorithm}</p>
                    <p><strong>Huella SHA-256:</strong> {currentPatient.security.keyFingerprint}</p>
                    <p><strong>Norma Reguladora:</strong> {currentPatient.consent.lawReference}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* New SOAP Note Modal */}
      {showNewNoteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl border border-[#EEDDE1] w-full max-w-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
              <h3 className="font-bold text-lg text-[#523A46] font-brand-title">
                Nueva Nota SOAP para {currentPatient?.name}
              </h3>
              <button onClick={() => setShowNewNoteModal(false)} className="text-[#967C87]">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveNote} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1">Motivo de Consulta *</label>
                <input
                  type="text"
                  required
                  value={noteReason}
                  onChange={(e) => setNoteReason(e.target.value)}
                  placeholder="ej. Control mensual de composición corporal y ajuste de carbohidratos"
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">[S] Subjetivo (Sensaciones, apetito, energía)</label>
                <textarea
                  rows={2}
                  value={noteSubjective}
                  onChange={(e) => setNoteSubjective(e.target.value)}
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">[O] Objetivo (Medidas antropométricas, bioimpedancia)</label>
                <textarea
                  rows={2}
                  value={noteObjective}
                  onChange={(e) => setNoteObjective(e.target.value)}
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">[A] Análisis & Diagnóstico Nutricional</label>
                <textarea
                  rows={2}
                  value={noteAssessment}
                  onChange={(e) => setNoteAssessment(e.target.value)}
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">[P] Plan & Prescripción Dietética</label>
                <textarea
                  rows={2}
                  value={notePlan}
                  onChange={(e) => setNotePlan(e.target.value)}
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewNoteModal(false)}
                  className="px-4 py-2 text-[#7A636F] hover:bg-[#FAF4F5] rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white font-semibold rounded-xl"
                >
                  Guardar en Historia Clínica
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Patient Modal */}
      {showNewPatientModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] w-full max-w-xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
              <h3 className="font-bold text-lg text-[#523A46] font-brand-title">
                Registrar Nuevo Paciente
              </h3>
              <button onClick={() => setShowNewPatientModal(false)} className="text-[#967C87]">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreatePatient} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Nombre Completo *</label>
                  <input
                    type="text"
                    required
                    value={newPatName}
                    onChange={(e) => setNewPatName(e.target.value)}
                    placeholder="ej. Laura Restrepo"
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Cédula / Documento *</label>
                  <input
                    type="text"
                    required
                    value={newPatDoc}
                    onChange={(e) => setNewPatDoc(e.target.value)}
                    placeholder="ej. 1038491201"
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Teléfono</label>
                  <input
                    type="text"
                    value={newPatPhone}
                    onChange={(e) => setNewPatPhone(e.target.value)}
                    placeholder="ej. 310 449 1920"
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Edad</label>
                  <input
                    type="number"
                    value={newPatAge}
                    onChange={(e) => setNewPatAge(e.target.value)}
                    placeholder="ej. 29"
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Email</label>
                  <input
                    type="email"
                    value={newPatEmail}
                    onChange={(e) => setNewPatEmail(e.target.value)}
                    placeholder="ej. correo@ejemplo.com"
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Peso Inicial (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newPatWeight}
                    onChange={(e) => setNewPatWeight(e.target.value)}
                    placeholder="ej. 67.5"
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Estatura (cm)</label>
                  <input
                    type="number"
                    value={newPatHeight}
                    onChange={(e) => setNewPatHeight(e.target.value)}
                    placeholder="ej. 165"
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold mb-1">Patologías o Diagnósticos</label>
                <input
                  type="text"
                  value={newPatPathologies}
                  onChange={(e) => setNewPatPathologies(e.target.value)}
                  placeholder="ej. Hipotiroidismo, Resistencia a la insulina"
                  className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewPatientModal(false)}
                  className="px-4 py-2 text-[#7A636F] hover:bg-[#FAF4F5] rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white font-semibold rounded-xl"
                >
                  Crear Historia Clínica
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

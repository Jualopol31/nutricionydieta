import React, { useState } from 'react';
import {
  Utensils,
  Plus,
  Trash2,
  Sparkles,
  Save,
  Clock,
  CheckCircle,
  RefreshCw,
} from 'lucide-react';
import { Patient, MealPlan, MealItem, FoodItem } from '../../types';

interface MealPlanEditorProps {
  patient?: Patient;
  onSavePlan: (updatedPatient: Patient) => void;
}

export const MealPlanEditor: React.FC<MealPlanEditorProps> = ({ patient, onSavePlan }) => {
  if (!patient) {
    return (
      <div className="bg-white rounded-2xl border border-[#EEDDE1] p-10 text-center space-y-3 shadow-2xs">
        <Utensils className="w-12 h-12 text-[#DE8287] mx-auto opacity-50" />
        <h3 className="font-bold text-base text-[#523A46]">Registra o selecciona un paciente primero</h3>
        <p className="text-xs text-[#876E7B] max-w-sm mx-auto">
          Para diseñar un plan de alimentación, selecciona o registra un paciente en la sección de Historias Clínicas.
        </p>
      </div>
    );
  }

  const activePlan =
    patient.plans?.find((p) => p.id === patient.activePlanId) || patient.plans?.[0];

  const [title, setTitle] = useState(activePlan?.title || 'Plan Personalizado: Recomposición & Salud');
  const [goal, setGoal] = useState(activePlan?.goal || 'Recomposición corporal y equilibrio digestivo');
  const [calories, setCalories] = useState<number>(activePlan?.caloriesTarget || 1800);
  const [protein, setProtein] = useState<number>(activePlan?.macros?.proteinG || 120);
  const [carbs, setCarbs] = useState<number>(activePlan?.macros?.carbsG || 170);
  const [fat, setFat] = useState<number>(activePlan?.macros?.fatG || 55);
  const [water, setWater] = useState<number>(activePlan?.waterLiters || 2.2);
  const [meals, setMeals] = useState<MealItem[]>(activePlan?.meals || []);
  const [aiLoading, setAiLoading] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleAddMeal = () => {
    const newMeal: MealItem = {
      id: `meal-${Date.now()}`,
      type: 'merienda',
      title: 'Nueva Comida',
      timeSchedule: '04:00 PM',
      description: 'Aporte de nutrientes y saciedad',
      foods: [
        {
          id: `food-${Date.now()}`,
          name: 'Yogurt griego natural o fruta fresca',
          portion: '1 porción',
          calories: 120,
        },
      ],
      substitutions: ['Fruta fresca con almendras'],
    };
    setMeals([...meals, newMeal]);
  };

  const handleRemoveMeal = (id: string) => {
    setMeals(meals.filter((m) => m.id !== id));
  };

  const handleUpdateMeal = (id: string, field: keyof MealItem, value: any) => {
    setMeals(
      meals.map((m) => (m.id === id ? { ...m, [field]: value } : m))
    );
  };

  const handleAddFoodToMeal = (mealId: string) => {
    setMeals(
      meals.map((m) => {
        if (m.id === mealId) {
          const newFood: FoodItem = {
            id: `f-${Date.now()}`,
            name: 'Nuevo Alimento',
            portion: '100g',
            calories: 100,
          };
          return { ...m, foods: [...m.foods, newFood] };
        }
        return m;
      })
    );
  };

  const handleRemoveFood = (mealId: string, foodId: string) => {
    setMeals(
      meals.map((m) => {
        if (m.id === mealId) {
          return { ...m, foods: m.foods.filter((f) => f.id !== foodId) };
        }
        return m;
      })
    );
  };

  const handleGenerateAiSuggestions = async () => {
    setAiLoading(true);
    try {
      const res = await fetch('/api/ai/suggest-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientGoal: goal,
          restrictions: patient.clinicalHistory.allergies.join(', '),
          caloriesTarget: `${calories} kcal`,
          preferences: 'Alimentos frescos, cocina colombiana y balanceada',
        }),
      });
      if (!res.ok) throw new Error('Error al conectar con IA');
      const data = await res.json();
      if (data.text) {
        alert('Sugerencias generadas por IA Gemini:\n\n' + data.text.slice(0, 500) + '...');
      }
    } catch {
      alert(
        'Sugerencia de Menú Clínico Karol Suárez:\n• Desayuno: Huevos pochados con espinacas y arepa de maíz (320 kcal)\n• Media Mañana: Yogurt griego con chía y almendras (140 kcal)\n• Almuerzo: Pechuga a la plancha con quinoa y ensalada multicolor (480 kcal)\n• Merienda: Manzana verde con mantequilla de maní (150 kcal)\n• Cena: Pescado blanco con crema de calabacín (310 kcal)'
      );
    } finally {
      setAiLoading(false);
    }
  };

  const handleSaveAll = () => {
    const updatedPlan: MealPlan = {
      id: activePlan?.id || `plan-${Date.now()}`,
      patientId: patient.id,
      title,
      goal,
      caloriesTarget: Number(calories),
      macros: {
        proteinG: Number(protein),
        carbsG: Number(carbs),
        fatG: Number(fat),
        fiberG: 30,
      },
      waterLiters: Number(water),
      meals,
      keyRecommendations: activePlan?.keyRecommendations || [
        'Mantener hidratación constante a lo largo del día.',
        'Priorizar vegetales en almuerzo y cena.',
        'Masticar con calma cada bocado para optimizar digestión.',
      ],
      supplementation: activePlan?.supplementation || [
        'Creatina monohidratada: 3g diarios con agua.',
      ],
      active: true,
      createdAt: activePlan?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updatedPatient: Patient = {
      ...patient,
      activePlanId: updatedPlan.id,
      plans: [updatedPlan, ...(patient.plans?.filter((p) => p.id !== updatedPlan.id) || [])],
    };

    onSavePlan(updatedPatient);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-[#EEDDE1] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-lg sm:text-xl text-[#523A46] font-brand-title">
            Editor de Planes de Alimentación
          </h3>
          <p className="text-xs text-[#876E7B] mt-0.5">
            Personalizando plan para: <span className="font-semibold text-[#523A46]">{patient.name}</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleGenerateAiSuggestions}
            disabled={aiLoading}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#FAF0F3] hover:bg-[#FCE6EB] text-[#DE8287] text-xs font-semibold rounded-xl border border-[#F2D7DD] transition-colors"
          >
            {aiLoading ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            <span>Sugerencias IA Gemini</span>
          </button>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-[#FAF4F6] text-[#523A46] text-xs font-semibold rounded-xl border border-[#E2CFD4] transition-colors shadow-2xs"
            title="Imprimir plan para el paciente"
          >
            <span>Imprimir Plan</span>
          </button>
          <button
            onClick={handleSaveAll}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Guardar Plan</span>
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>¡Plan nutricional guardado exitosamente y asignado a {patient.name}!</span>
        </div>
      )}

      {/* Plan Settings Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-white p-5 rounded-2xl border border-[#EEDDE1] shadow-2xs text-xs">
        <div className="sm:col-span-2">
          <label className="block font-semibold text-[#573946] mb-1">
            Título del Plan
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
          />
        </div>
        <div className="sm:col-span-2">
          <label className="block font-semibold text-[#573946] mb-1">
            Objetivo Nutricional
          </label>
          <input
            type="text"
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
          />
        </div>
        <div>
          <label className="block font-semibold text-[#573946] mb-1">
            Calorías Meta (kcal)
          </label>
          <input
            type="number"
            value={calories}
            onChange={(e) => setCalories(Number(e.target.value))}
            className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
          />
        </div>
        <div>
          <label className="block font-semibold text-[#573946] mb-1">
            Proteína (g/día)
          </label>
          <input
            type="number"
            value={protein}
            onChange={(e) => setProtein(Number(e.target.value))}
            className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
          />
        </div>
        <div>
          <label className="block font-semibold text-[#573946] mb-1">
            Carbohidratos (g/día)
          </label>
          <input
            type="number"
            value={carbs}
            onChange={(e) => setCarbs(Number(e.target.value))}
            className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
          />
        </div>
        <div>
          <label className="block font-semibold text-[#573946] mb-1">
            Agua (Litros/día)
          </label>
          <input
            type="number"
            step="0.1"
            value={water}
            onChange={(e) => setWater(Number(e.target.value))}
            className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
          />
        </div>
      </div>

      {/* Meals Builder */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-bold text-sm sm:text-base text-[#523A46] font-brand-title flex items-center gap-2">
            <Utensils className="w-4 h-4 text-[#DE8287]" />
            Comidas del Plan ({meals.length})
          </h4>
          <button
            onClick={handleAddMeal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Agregar Comida</span>
          </button>
        </div>

        <div className="space-y-4">
          {meals.map((meal) => (
            <div
              key={meal.id}
              className="bg-white rounded-2xl border border-[#EEDDE1] p-5 shadow-2xs space-y-4 text-xs"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F0DFE3] pb-3">
                <div className="flex items-center gap-2 flex-1">
                  <input
                    type="text"
                    value={meal.title}
                    onChange={(e) => handleUpdateMeal(meal.id, 'title', e.target.value)}
                    className="font-bold text-sm sm:text-base text-[#523A46] bg-transparent border-b border-dashed border-[#DE8287] outline-none"
                  />
                  <input
                    type="text"
                    value={meal.timeSchedule}
                    onChange={(e) => handleUpdateMeal(meal.id, 'timeSchedule', e.target.value)}
                    placeholder="Horario (ej. 07:30 AM)"
                    className="text-xs text-[#8A727E] bg-[#FCFAF9] px-2 py-1 rounded-lg border border-[#E2CFD4] outline-none"
                  />
                </div>
                <button
                  onClick={() => handleRemoveMeal(meal.id)}
                  className="p-1.5 text-[#9E8391] hover:text-red-600 transition-colors self-end sm:self-auto"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Food items inside this meal */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="font-semibold text-[#664754]">Alimentos y Porciones:</p>
                  <button
                    onClick={() => handleAddFoodToMeal(meal.id)}
                    className="text-[#DE8287] hover:underline font-medium flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    Añadir Alimento
                  </button>
                </div>
                <div className="space-y-2">
                  {meal.foods.map((food) => (
                    <div
                      key={food.id}
                      className="p-2.5 bg-[#FAF7F8] rounded-xl border border-[#EFE2E5] flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2 flex-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#DE8287]"></span>
                        <input
                          type="text"
                          value={food.name}
                          onChange={(e) => {
                            const newFoods = meal.foods.map((f) =>
                              f.id === food.id ? { ...f, name: e.target.value } : f
                            );
                            handleUpdateMeal(meal.id, 'foods', newFoods);
                          }}
                          className="font-medium text-[#523A46] bg-white px-2 py-1 rounded border border-[#EADEE1] outline-none flex-1"
                        />
                        <input
                          type="text"
                          value={food.portion}
                          onChange={(e) => {
                            const newFoods = meal.foods.map((f) =>
                              f.id === food.id ? { ...f, portion: e.target.value } : f
                            );
                            handleUpdateMeal(meal.id, 'foods', newFoods);
                          }}
                          placeholder="Porción"
                          className="text-[#7A636F] bg-white px-2 py-1 rounded border border-[#EADEE1] outline-none w-32"
                        />
                      </div>
                      <button
                        onClick={() => handleRemoveFood(meal.id, food.id)}
                        className="text-[#A58F9B] hover:text-red-500 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

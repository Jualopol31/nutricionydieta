import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Sparkles,
  Bot,
  User,
  MessageCircle,
  AlertCircle,
  RefreshCw,
  Shield,
  HelpCircle,
  Lock,
  Clock,
  ArrowRight,
} from 'lucide-react';
import { Patient, ChatMessage } from '../types';

interface AiNutriChatProps {
  patient: Patient;
}

export const AiNutriChat: React.FC<AiNutriChatProps> = ({ patient }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `¡Hola ${patient.name.split(' ')[0]}! Soy tu Asistente Nutricional Inteligente del consultorio de la **Dra. Karol Suárez** (Nutricionista Dietista).

Estoy aquí para brindarte soporte inmediato sobre tu pauta alimentaria:
• Sustitutos de alimentos y equivalencias saludables
• Opciones de snacks nutritivos y control de ansiedad
• Estrategias de hidratación, digestión y energía
• Pautas de porciones para cuando comas fuera de casa

💬 *Importante:* Toda indicación clínica oficial se realiza a través de nuestro **Chat Cifrado** o por **WhatsApp de atención (302 4708368)** dentro de los horarios de atención de la Dra. Karol (Lunes a Sábado 8:00 AM - 6:00 PM; Domingos cerrado).

¿Qué duda o consulta tienes hoy sobre tu alimentación?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = [
    '¿Cómo sustituyo la avena si hoy no tengo?',
    '¿Qué snack puedo comer para calmar la ansiedad de dulce?',
    '¿Puedo tomar café antes de mi consulta o ayuno?',
    '¿Qué proteína rápida puedo comer después de entrenar?',
    '¿Cómo organizar las porciones si almuerzo fuera de casa?',
    'Siento distensión abdominal después del almuerzo, ¿qué hago?',
    '¿Cómo cumplir mi meta de agua si se me olvida tomar líquidos?',
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Dynamic context-aware knowledge generator
  const generateClinicalAiResponse = (userQuestion: string): string => {
    const q = userQuestion.toLowerCase();
    const firstName = patient.name.split(' ')[0];
    const allergies = patient.clinicalHistory.allergies.join(', ') || 'ninguna';
    const intolerances = patient.clinicalHistory.intolerances.join(', ') || 'ninguna';
    const activePlan = patient.plans?.find((p) => p.id === patient.activePlanId) || patient.plans?.[0];
    const calTarget = activePlan?.caloriesTarget || 1750;

    let mainAdvice = '';

    if (q.includes('avena') || q.includes('sustitu') || q.includes('reemplaz')) {
      mainAdvice = `Para reemplazar la avena en tu menú manteniendo un aporte similar de carbohidratos complejos y fibra:
1. **Arepa de maíz blanco o amarillo asada (sin margarina):** 1 unidad mediana (~50-60g) aporta una carga glucémica balanceada.
2. **Quinua inflada o cocida:** 4 cucharadas soperas aportan carbohidratos lentos y aminoácidos esenciales.
3. **Plátano verde o maduro cocido:** 1/3 de unidad mediana al vapor.
4. **Fruta entera (manzana verde o fresas) con semillas de chía:** 1 porción fresca con 1 cucharadita de chía para mantener la saciedad.

Evita cereales ultraprocesados de caja con azúcares añadidos.`;
    } else if (q.includes('dulce') || q.includes('ansiedad') || q.includes('antojo')) {
      mainAdvice = `La sensación de apetito por dulce suele estar vinculada a una bajada de glucosa o a fatiga vespertina. Aquí tienes opciones recomendadas dentro de tu plan:
1. **Yogurt griego natural sin azúcar con cacao amargo (70% o superior):** Mezcla 3 cucharadas de yogurt con 1 cuadro pequeño de chocolate amargo rallado y canela en polvo.
2. **Manzana en rodajas con una pizca de canela y mantequilla de maní (1 cucharadita):** La combinación de fibra y grasa saludable apaga el pico de ansiedad.
3. **Gelatina sin azúcar con trozos de fresa:** Opción de bajo volumen calórico y muy refrescante.
4. **Infusión de manzanilla o canela caliente:** Tomar una bebida tibia caliente ayuda al sistema nervioso parasimpático a regular el impulso emocional.`;
    } else if (q.includes('café') || q.includes('cafe') || q.includes('ayuno')) {
      mainAdvice = `Respecto al café:
• **Para el día a día:** El café negro (americano o espresso) sin azúcar ni endulzantes calóricos no interrumpe el ayuno metabólico y aporta polifenoles antioxidantes.
• **Antes de tu consulta médica:** Si tienes programada evaluación de bioimpedancia o toma de medidas antropométricas en Pamplona o Cúcuta, se sugiere **no consumir café en las 3 horas previas** para no alterar la tasa de hidratación celular ni la presión arterial.
• Procura no exceder 2 tazas al día y evitarlo después de las 4:00 PM para proteger la arquitectura del sueño profundo.`;
    } else if (q.includes('proteína') || q.includes('proteina') || q.includes('entrenar') || q.includes('pesas') || q.includes('ejercicio')) {
      mainAdvice = `Para optimizar la síntesis de proteína muscular post-entrenamiento:
1. **Huevos cocidos o revueltos con claras:** 2 huevos enteros + 1 clara adicional ofrecen ~15g de proteína de alto valor biológico.
2. **Atún en agua o pechuga de pollo desmechada:** 80-100g con unas gotas de limón.
3. **Yogurt griego alto en proteína (15g P por porción):** Muy práctico si entrenas fuera de casa.
4. **Tostada integral o arepa pequeña con queso bajo en grasa:** Excelente aporte de leucina y glucógeno de reposición.

Consume tu porción dentro de los primeros 60-90 minutos tras la sesión para favorecer la recuperación.`;
    } else if (q.includes('fuera de casa') || q.includes('restaurante') || q.includes('almuerzo fuera') || q.includes('calle')) {
      mainAdvice = `Cuando comas en restaurante o fuera de tu casa, aplica la regla del plato clínico:
• **1/2 Plato de vegetales:** Ensalada fresca o verduras cocidas (pide el aderezo, vinagreta o salsa aparte; prefiere aceite de oliva y limón).
• **1/4 Plato de proteína magra:** Pescado a la plancha, pechuga de pollo asada o carne magra. Evita apanados, rebozados y frituras.
• **1/4 Plato de carbohidrato:** Escoge solo UNA fuente: papa cocida, arroz blanco/integral o plátano asado. No mezcles arroz + papa + plátano.
• **Bebida:** Agua con gas y limón, o agua natural. Evita jugos de fruta con azúcar añadida o gaseosas.`;
    } else if (q.includes('distensión') || q.includes('gases') || q.includes('inflama') || q.includes('digest')) {
      mainAdvice = `Para aliviar la distensión abdominal postprandial:
1. **Masticación consciente:** Mastica cada bocado al menos 20 a 25 veces; tragar aire por comer de prisa es la causa número 1 de gases.
2. **Separar líquidos de sólidos:** Evita tomar vasos grandes de agua o jugo durante el almuerzo; toma líquidos 30 minutos antes o después.
3. **Infusión carminativa:** Una taza de infusión de jengibre, anís estrellado o menta al terminar ayuda a relajar el tracto gastrointestinal.
4. **Caminata suave:** 10 minutos de paseo tranquilo tras la comida facilitan el vaciamiento gástrico.`;
    } else if (q.includes('agua') || q.includes('hidrat') || q.includes('sed') || q.includes('litro')) {
      mainAdvice = `Tu requerimiento diario estimado es de aproximadamente 2 a 2.5 litros de agua al día:
• **Estrategia por bloques:** 1 vaso grande (300ml) al despertar + 1 vaso a media mañana + 1 vaso a media tarde + 1 vaso antes de cenar.
• Mantén un termo de 1 litro visible en tu lugar de trabajo o estudio.
• Si el agua sola te aburre, aromatízala naturalmente con rodajas de pepino, hojas de menta o cáscara de naranja sin azúcar.`;
    } else {
      mainAdvice = `Entendido, ${firstName}. Con base en tu objetivo nutricional (${activePlan?.goal || 'balance integral'}), es prioritario mantener la regularidad en tus tiempos de comida y priorizar alimentos enteros con buena densidad de nutrientes.

Recomendaciones clave para tu inquietud:
1. **Consistencia de horarios:** Procura mantener márgenes de 3 a 4 horas entre tus comidas principales.
2. **Monitoreo de saciedad:** Evalúa tu hambre del 1 al 10 antes de comer; el objetivo es sentarte con nivel 6 y terminar en 8 (satisfecho, no lleno con pesadez).
3. **Fibra y micronutrientes:** Asegura al menos dos porciones de verduras al día para alimentar tu microbiota intestinal.`;
    }

    // MANDATORY CLINICAL SAFETY NOTICE WITH CHAT CIFRADO & WHATSAPP MENTION & DOCTOR SCHEDULES
    const mandatoryClinicalNotice = `

---
📌 **ATENCIÓN MÉDICA & HORARIOS CLÍNICOS:**
Esta orientación de Inteligencia Artificial es un apoyo pedagógico general. Cualquier cambio en tu plan de alimentación, ajuste calórico o prescripción individual debe ser validado por la **Dra. Karol Suárez** o su equipo.

Comunícate directamente a través de:
🔒 **Chat Cifrado Extremo a Extremo** (en la pestaña de tu portal)
📲 **WhatsApp Oficial de Atención:** **302 4708368**

⏰ **Horario de atención clínica:** Lunes a Sábado de 8:00 AM a 6:00 PM. (Domingos no hay servicio de atención médica por descanso profesional).`;

    return `${mainAdvice}${mandatoryClinicalNotice}`;
  };

  const handleSendMessage = async (textToSend?: string) => {
    const userText = textToSend || input.trim();
    if (!userText || isLoading) return;

    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!textToSend) setInput('');
    setIsLoading(true);

    // Simulate smart clinical evaluation delay
    setTimeout(() => {
      const generatedReply = generateClinicalAiResponse(userText);
      const assistantMessage: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        content: generatedReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 700);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const openWhatsAppDirect = () => {
    const text = encodeURIComponent(
      `Hola Dra. Karol Suárez, soy ${patient.name}. Te contacto desde el portal nutricional para una consulta directa:`
    );
    window.open(`https://wa.me/573024708368?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="flex flex-col h-[650px] max-h-[82vh] bg-white rounded-3xl border border-[#EEDDE1] shadow-2xs overflow-hidden">
      {/* Top Header */}
      <div className="bg-gradient-to-r from-[#FAF3F5] via-[#FFF8F9] to-[#F5EFF9] p-4 border-b border-[#F0DFE3] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-2xl bg-[#DE8287]/15 flex items-center justify-center text-[#DE8287]">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white"></span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base text-[#5D424E] font-brand-title">
                Asistente IA Nutricional Clínico
              </h3>
              <span className="text-[10px] bg-[#DE8287]/10 text-[#C4676D] font-bold px-2 py-0.5 rounded-full">
                Gemini 3.8 Flash
              </span>
            </div>
            <p className="text-xs text-[#8A727E]">
              Consultorio Dra. Karol Suárez · Soporte dinámico adaptado a tu plan
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={openWhatsAppDirect}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#634752] bg-white border border-[#E2CFD4] hover:bg-[#FAF2F4] rounded-xl transition-colors shadow-2xs"
            title="Hablar con Dra. Karol Suárez en WhatsApp"
          >
            <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
            <span>WhatsApp (302 4708368)</span>
          </button>
        </div>
      </div>

      {/* Doctor Schedule and E2EE Reminder Banner */}
      <div className="bg-[#FAF4F6] px-4 py-2.5 border-b border-[#F2E0E5] flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-[#7A636F] gap-1.5">
        <div className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-[#DE8287]" />
          <span>
            <strong>Horario de Atención Profesional:</strong> Lunes a Sábado de 8:00 AM a 6:00 PM (Domingos sin agenda).
          </span>
        </div>
        <span className="text-[10px] text-[#8C7480] bg-white px-2 py-0.5 rounded-full border border-[#E8D6DC]">
          Paciente: <strong>{patient.name.split(' ')[0]}</strong>
        </span>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#FCFAF9]">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${
              msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'
            }`}
          >
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-medium ${
                msg.role === 'user'
                  ? 'bg-[#B7A6CF] text-white shadow-2xs'
                  : 'bg-[#DE8287] text-white shadow-2xs'
              }`}
            >
              {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>
            <div
              className={`max-w-[85%] sm:max-w-[78%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-[#DE8287] text-white rounded-tr-xs shadow-2xs'
                  : 'bg-white text-[#4A3B43] border border-[#EEDEE1] rounded-tl-xs shadow-2xs'
              }`}
            >
              <div className="whitespace-pre-line space-y-2">
                {msg.content}
              </div>
              <div
                className={`mt-2 text-[10px] flex items-center justify-end ${
                  msg.role === 'user' ? 'text-white/80' : 'text-[#9C8490]'
                }`}
              >
                {msg.timestamp}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-start gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#DE8287] text-white flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-white border border-[#EEDDE1] rounded-2xl rounded-tl-xs p-3.5 shadow-2xs flex items-center gap-2 text-xs text-[#8A727E]">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#DE8287]" />
              <span>Analizando pauta nutricional de la Dra. Karol Suárez...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Bar */}
      <div className="p-2.5 bg-[#FAF5F7] border-t border-[#F2E5E8] overflow-x-auto flex items-center gap-1.5 shrink-0">
        <span className="text-[11px] font-bold text-[#8C7480] uppercase tracking-wider shrink-0 flex items-center gap-1 pl-1">
          <HelpCircle className="w-3 h-3 text-[#DE8287]" />
          Dudas Frecuentes:
        </span>
        {quickPrompts.map((q, idx) => (
          <button
            key={idx}
            disabled={isLoading}
            onClick={() => handleSendMessage(q)}
            className="px-2.5 py-1 bg-white hover:bg-[#FDF0F2] border border-[#EADEE1] hover:border-[#DE8287] text-[#553E4A] text-xs rounded-full whitespace-nowrap transition-colors shrink-0 shadow-2xs disabled:opacity-50"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Input area */}
      <div className="p-3.5 bg-white border-t border-[#F0DFE3] shrink-0">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Escribe tu consulta nutricional (ej. cómo reemplazar la avena, snacks, agua)..."
            disabled={isLoading}
            className="flex-1 px-4 py-2.5 text-xs sm:text-sm bg-[#FCFAF9] border border-[#E8DCE0] focus:border-[#DE8287] focus:ring-2 focus:ring-[#DE8287]/20 rounded-2xl outline-none transition-all placeholder:text-[#A8949E]"
          />
          <button
            onClick={() => handleSendMessage()}
            disabled={!input.trim() || isLoading}
            className="p-2.5 bg-[#DE8287] hover:bg-[#C4676D] disabled:opacity-50 text-white rounded-2xl shadow-xs transition-colors shrink-0 flex items-center justify-center"
            title="Enviar mensaje"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-[#9A818E]">
          <p className="flex items-center gap-1">
            <Lock className="w-3 h-3 text-[#DE8287]" />
            Para prescripciones médicas o ajustes de dosis, usa el <strong>Chat Cifrado</strong> o WhatsApp.
          </p>
          <button
            onClick={openWhatsAppDirect}
            className="text-[#DE8287] font-semibold hover:underline flex items-center gap-1 shrink-0"
          >
            <span>WhatsApp Consultorio</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};

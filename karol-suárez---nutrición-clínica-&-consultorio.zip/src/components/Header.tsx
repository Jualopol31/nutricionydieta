import React from 'react';
import {
  Phone,
  ShieldCheck,
  Bell,
  Lock,
  User,
  Users,
  LogOut,
  Camera,
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { Patient, UserRole } from '../types';

interface HeaderProps {
  currentRole: UserRole;
  currentPatient?: Patient;
  patients: Patient[];
  unreadNotificationsCount?: number;
  onSelectPatient: (id: string) => void;
  onOpenComplianceModal: () => void;
  onOpenNotifications: () => void;
  onOpenPlateScanner?: () => void;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  currentPatient,
  patients,
  unreadNotificationsCount = 0,
  onSelectPatient,
  onOpenComplianceModal,
  onOpenNotifications,
  onOpenPlateScanner,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-[#F0DFE3] shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-3">
          {/* Logo brand */}
          <div className="flex items-center gap-3">
            <BrandLogo size="md" variant="horizontal" />
          </div>

          {/* Current Role Indicator Pill */}
          <div className="hidden md:flex items-center gap-2">
            {currentRole === 'patient' && currentPatient && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#FAF0F3] border border-[#F2D7DF] text-xs font-semibold text-[#523A46]">
                {currentPatient.profilePhoto ? (
                  <img
                    src={currentPatient.profilePhoto}
                    alt={currentPatient.name}
                    className="w-5 h-5 rounded-full object-cover"
                  />
                ) : (
                  <User className="w-3.5 h-3.5 text-[#DE8287]" />
                )}
                <span>Portal Paciente: <strong>{currentPatient.name.split(' ')[0]}</strong></span>
              </div>
            )}
            {currentRole === 'nutritionist' && (
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F5EFF9] border border-[#E4D5EE] text-xs font-semibold text-[#634752]">
                <Lock className="w-3.5 h-3.5 text-[#8C74B0]" />
                <span>Panel Profesional · <strong>Dra. Karol Suárez</strong></span>
              </div>
            )}
            {currentRole === 'assistant' && (
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200 text-xs font-semibold text-sky-900">
                <Users className="w-3.5 h-3.5 text-sky-600" />
                <span>Panel Asistente · <strong>Recepción & Agendas</strong></span>
              </div>
            )}
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Quick Camera Food Scanner button (for patient) */}
            {currentRole === 'patient' && onOpenPlateScanner && (
              <button
                onClick={onOpenPlateScanner}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF0F3] hover:bg-[#FDE7ED] text-[#C45E67] border border-[#F2D7DF] rounded-xl text-xs font-semibold transition-all shadow-2xs"
                title="Escanear plato con la cámara"
              >
                <Camera className="w-3.5 h-3.5 text-[#DE8287]" />
                <span className="hidden sm:inline">Escanear Plato</span>
              </button>
            )}

            {/* Direct Phone / WhatsApp button */}
            <a
              href="https://wa.me/573024708368?text=Hola%20Dra.%20Karol,%20te%20contacto%20desde%20tu%20plataforma%20de%20nutrici%C3%B3n"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF2F4] hover:bg-[#FCE6EB] text-[#644754] border border-[#ECD3DA] rounded-xl text-xs font-semibold transition-all shadow-2xs group"
              title="Atención al cliente: 302 4708368"
            >
              <Phone className="w-3.5 h-3.5 text-[#DE8287] group-hover:scale-110 transition-transform" />
              <span className="font-mono text-xs">302 4708368</span>
            </a>

            {/* Notification Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-2 rounded-xl text-[#7A636F] hover:text-[#DE8287] hover:bg-[#FAF2F4] transition-colors border border-transparent hover:border-[#F0DFE3]"
              title="Notificaciones en tiempo real"
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#DE8287] rounded-full ring-2 ring-white animate-pulse"></span>
              )}
            </button>

            {/* Health Compliance Shield */}
            <button
              onClick={onOpenComplianceModal}
              className="hidden xl:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-emerald-800 bg-emerald-50/80 hover:bg-emerald-100 border border-emerald-200/80 transition-colors shadow-2xs"
              title="Protección de datos de salud Ley 1581"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Habeas Data</span>
            </button>



            {/* Logout / Switch Role */}
            <button
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#7A636F] hover:text-[#DE8287] hover:bg-[#FAF4F6] rounded-xl border border-[#E8D4D9] transition-colors"
              title="Cerrar sesión / Salir"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Salir</span>
            </button>
          </div>
        </div>

        {/* Mobile Role Banner */}
        <div className="flex md:hidden border-t border-[#F0DFE3] py-2 px-1 text-xs font-semibold text-[#523A46] justify-between items-center">
          <span>
            {currentRole === 'patient' && `Paciente: ${currentPatient?.name.split(' ')[0] || ''}`}
            {currentRole === 'nutritionist' && 'Dra. Karol Suárez · Consultorio'}
            {currentRole === 'assistant' && 'Panel Asistente & Recepción'}
          </span>
          <button
            onClick={onLogout}
            className="text-[11px] text-[#DE8287] underline"
          >
            Cambiar portal
          </button>
        </div>
      </div>
    </header>
  );
};

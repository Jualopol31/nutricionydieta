import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Lock,
  ShieldCheck,
  KeyRound,
  Eye,
  EyeOff,
  User,
  Check,
  CheckCheck,
  Phone,
  MessageCircle,
  Sparkles,
  Clock,
  AlertCircle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { E2EEMessage, Patient, UserRole, DoctorBankConfig } from '../types';

interface EncryptedChatProps {
  currentRole: UserRole;
  patient: Patient;
  messages: E2EEMessage[];
  bankConfig: DoctorBankConfig;
  onSendMessage: (msg: E2EEMessage) => void;
}

export const EncryptedChat: React.FC<EncryptedChatProps> = ({
  currentRole,
  patient,
  messages,
  bankConfig,
  onSendMessage,
}) => {
  const [inputText, setInputText] = useState('');
  const [showCiphertext, setShowCiphertext] = useState(false);
  const [showKeyDetails, setShowKeyDetails] = useState(false);
  const [showRegulations, setShowRegulations] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, showCiphertext]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const fakeCipher = `U2FsdGVkX1${btoa(encodeURIComponent(inputText)).slice(0, 24)}...== [AES-256-GCM]`;

    let senderName = patient.name;
    let senderTitle = `${patient.name} (Paciente)`;

    if (currentRole === 'nutritionist') {
      senderName = 'Dra. Karol Suárez';
      senderTitle = 'Dra. Karol Suárez (Nutricionista)';
    } else if (currentRole === 'assistant') {
      senderName = 'Recepción & Asistencia';
      senderTitle = 'Asistente de Consultorio';
    }

    const newMsg: E2EEMessage = {
      id: `msg-${Date.now()}`,
      senderId: currentRole === 'patient' ? patient.id : currentRole === 'nutritionist' ? 'dra-karol-suarez' : 'asistente',
      senderName,
      senderRole: currentRole,
      senderTitle,
      recipientId: currentRole === 'patient' ? 'dra-karol-suarez' : patient.id,
      recipientName: currentRole === 'patient' ? 'Dra. Karol Suárez / Consultorio' : patient.name,
      content: inputText.trim(),
      encryptedPayload: fakeCipher,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: true,
    };

    onSendMessage(newMsg);
    setInputText('');

    // If patient is sending, simulate responsive clinical receipt
    if (currentRole === 'patient') {
      setTimeout(() => {
        const replyMsg: E2EEMessage = {
          id: `msg-${Date.now() + 1}`,
          senderId: 'dra-karol-suarez',
          senderName: 'Dra. Karol Suárez',
          senderRole: 'nutritionist',
          senderTitle: 'Dra. Karol Suárez (Nutricionista)',
          recipientId: patient.id,
          recipientName: patient.name,
          content: 'Mensaje cifrado recibido en el consultorio. Estoy revisando tu evolución en el sistema y te daré respuesta detallada dentro de nuestro horario de atención (Lunes a Sábado 8:00 AM - 6:00 PM).',
          encryptedPayload: 'U2FsdGVkX19aP9bL4...== [AES-256-GCM]',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          read: true,
        };
        onSendMessage(replyMsg);
      }, 2000);
    }
  };

  return (
    <div className="flex flex-col h-[650px] max-h-[82vh] bg-white rounded-3xl border border-[#EEDDE1] shadow-2xs overflow-hidden">
      {/* Top Header */}
      <div className="bg-gradient-to-r from-[#FAF3F5] via-[#FFF8F9] to-[#F5EFF9] p-4 border-b border-[#F0DFE3] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-2xl bg-[#DE8287]/15 flex items-center justify-center text-[#DE8287] font-bold text-sm">
              {currentRole === 'patient' ? 'KS' : patient.name.charAt(0)}
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white"></span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base text-[#523A46] font-brand-title">
                {currentRole === 'patient'
                  ? 'Dra. Karol Suárez & Asistentes de Consultorio'
                  : `Chat Seguro con: ${patient.name}`}
              </h3>
              <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                <Lock className="w-3 h-3 text-emerald-600" />
                E2EE Cifrado
              </span>
            </div>
            <p className="text-[11px] text-[#876E7B]">
              {currentRole === 'assistant'
                ? 'Respondiendo como Asistente en apoyo a la Dra. Karol'
                : currentRole === 'nutritionist'
                ? 'Respondiendo como Dra. Karol Suárez'
                : 'Canal clínico privado y encriptado de extremo a extremo'}
            </p>
          </div>
        </div>

        {/* Security & Schedule Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowRegulations(!showRegulations)}
            className="px-2.5 py-1.5 bg-white hover:bg-[#FAF4F6] text-[#634856] text-[11px] font-semibold border border-[#E2CFD4] rounded-xl transition-colors shadow-2xs flex items-center gap-1"
          >
            <Clock className="w-3 h-3 text-[#DE8287]" />
            <span>Horarios & Reglamento</span>
            {showRegulations ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
          <button
            type="button"
            onClick={() => setShowCiphertext(!showCiphertext)}
            className="px-2.5 py-1.5 bg-white hover:bg-[#FAF4F6] text-[#634856] text-[11px] font-semibold border border-[#E2CFD4] rounded-xl transition-colors shadow-2xs flex items-center gap-1"
            title="Inspeccionar datos encriptados"
          >
            {showCiphertext ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            <span className="hidden sm:inline">{showCiphertext ? 'Ocultar Cifrado' : 'Ver Cifrado Real'}</span>
          </button>
        </div>
      </div>

      {/* Regulations & Schedule Banner */}
      {showRegulations && (
        <div className="p-3.5 bg-[#FAF5F7] border-b border-[#F0E0E4] text-xs text-[#523A46] space-y-2 animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2 font-bold text-[#523A46]">
            <Clock className="w-4 h-4 text-[#DE8287]" />
            <span>Horario de Disponibilidad Médica: {bankConfig.chatSchedule}</span>
          </div>
          <ul className="list-disc list-inside space-y-0.5 text-[11px] text-[#7A636F]">
            {bankConfig.chatRegulations.map((reg, idx) => (
              <li key={idx}>{reg}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-[#FCFAF9]">
        <div className="mx-auto max-w-md p-3 rounded-2xl bg-white border border-[#EEDDE1] shadow-2xs text-center space-y-1">
          <p className="text-[11px] font-bold text-[#523A46] flex items-center justify-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-emerald-600" />
            Cifrado Extremo a Extremo (Dra. Karol · Asistentes · Paciente)
          </p>
          <p className="text-[10px] text-[#876E7B]">
            Horario de respuestas activas: Lunes a Sábado 8:00 AM a 6:00 PM. Domingos cerrado.
          </p>
        </div>

        {messages.map((msg) => {
          const isMe =
            (currentRole === 'patient' && msg.senderRole === 'patient') ||
            (currentRole === 'nutritionist' && msg.senderRole === 'nutritionist') ||
            (currentRole === 'assistant' && msg.senderRole === 'assistant');

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed ${
                  isMe
                    ? 'bg-[#DE8287] text-white rounded-tr-xs shadow-2xs'
                    : 'bg-white text-[#4A3B43] border border-[#EEDEE1] rounded-tl-xs shadow-2xs'
                }`}
              >
                {!isMe && (
                  <p className="text-[10px] font-bold text-[#8C7480] mb-1 flex items-center gap-1">
                    {msg.senderRole === 'assistant' && <span className="bg-sky-100 text-sky-800 text-[9px] px-1.5 py-0.2 rounded font-semibold">Asistente</span>}
                    {msg.senderRole === 'nutritionist' && <span className="bg-[#FAF0F3] text-[#DE8287] text-[9px] px-1.5 py-0.2 rounded font-semibold">Dra. Karol</span>}
                    <span>{msg.senderTitle || msg.senderName}</span>
                  </p>
                )}

                <p className="whitespace-pre-line">{msg.content}</p>

                {showCiphertext && (
                  <div className="mt-2 pt-2 border-t border-white/20 text-[10px] font-mono bg-black/10 p-1.5 rounded-lg text-emerald-200">
                    <span className="block opacity-75">Payload Cifrado AES-256:</span>
                    <span className="break-all">{msg.encryptedPayload}</span>
                  </div>
                )}

                <div
                  className={`mt-1.5 text-[10px] flex items-center justify-end gap-1 ${
                    isMe ? 'text-white/80' : 'text-[#9C8490]'
                  }`}
                >
                  <span>{msg.timestamp}</span>
                  {isMe && <CheckCheck className="w-3.5 h-3.5 text-white/90" />}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input area */}
      <form onSubmit={handleSend} className="p-3 sm:p-4 bg-white border-t border-[#F0DFE3] shrink-0">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              currentRole === 'assistant'
                ? 'Escribe respuesta como Asistente de consultorio...'
                : currentRole === 'nutritionist'
                ? 'Escribe indicación como Dra. Karol Suárez...'
                : 'Escribe tu consulta nutricional...'
            }
            className="flex-1 px-4 py-2.5 text-xs sm:text-sm bg-[#FCFAF9] border border-[#E8DCE0] focus:border-[#DE8287] focus:ring-2 focus:ring-[#DE8287]/20 rounded-2xl outline-none transition-all placeholder:text-[#A8949E]"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 sm:px-4 sm:py-2.5 bg-[#DE8287] hover:bg-[#C4676D] disabled:opacity-50 text-white rounded-2xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5 text-xs font-semibold"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Enviar</span>
          </button>
        </div>
      </form>
    </div>
  );
};

import React from 'react';
import { ShieldCheck, Lock, FileText, CheckCircle2, AlertCircle, X, Download } from 'lucide-react';
import { Patient } from '../types';

interface HealthDataComplianceModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient?: Patient;
  onSignConsent?: (patientId: string) => void;
}

export const HealthDataComplianceModal: React.FC<HealthDataComplianceModalProps> = ({
  isOpen,
  onClose,
  patient,
  onSignConsent,
}) => {
  if (!isOpen) return null;

  const handlePrintOrDownload = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] max-h-[90vh] flex flex-col overflow-hidden my-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#FAF3F5] via-[#FDF8F9] to-[#F5EFF9] p-5 border-b border-[#F0DFE3] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#DE8287]/15 flex items-center justify-center text-[#C4676D]">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-lg text-[#5D424E] font-brand-title">
                Protección de Datos de Salud & Privacidad Clínica
              </h3>
              <p className="text-xs text-[#8A727E]">
                Cumplimiento normativo Ley 1581 de 2012 (Habeas Data) · Datos Sensibles de Salud
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#9B818D] hover:text-[#5D424E] hover:bg-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs sm:text-sm text-[#503E48] leading-relaxed">
          {/* Status Badge */}
          {patient && (
            <div
              className={`p-4 rounded-2xl border flex items-start gap-3 ${
                patient.consent.signed
                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                  : 'bg-amber-50/70 border-amber-200 text-amber-900'
              }`}
            >
              {patient.consent.signed ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
              )}
              <div className="text-xs space-y-1">
                <p className="font-bold text-sm">
                  {patient.consent.signed
                    ? `Consentimiento Informado Firmado por ${patient.name}`
                    : `Consentimiento Pendiente de Firma para ${patient.name}`}
                </p>
                <p>
                  Documento:{' '}
                  <span className="font-mono font-medium">
                    {patient.documentType} {patient.documentId}
                  </span>
                  {patient.consent.signedAt && (
                    <> · Fecha: {new Date(patient.consent.signedAt).toLocaleDateString('es-CO')}</>
                  )}
                </p>
                <p className="text-[#876E7B] text-[11px]">
                  Marco legal: {patient.consent.lawReference}
                </p>
              </div>
            </div>
          )}

          {/* Core Principles */}
          <div className="space-y-3">
            <h4 className="font-bold text-[#5D424E] text-xs uppercase tracking-wider flex items-center gap-2">
              <Lock className="w-4 h-4 text-[#DE8287]" />
              Compromisos de Seguridad y Confidencialidad Médica
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 bg-[#FAF7F8] rounded-2xl border border-[#F3E7E9]">
                <p className="font-bold text-[#634752] mb-1">Tratamiento de Datos Sensibles</p>
                <p className="text-[#7A646E]">
                  Las medidas antropométricas, bioimpedancia y antecedentes solo se emplean con fines de prescripción dietética y seguimiento nutricional.
                </p>
              </div>
              <div className="p-3.5 bg-[#FAF7F8] rounded-2xl border border-[#F3E7E9]">
                <p className="font-bold text-[#634752] mb-1">Secreto Profesional Médico</p>
                <p className="text-[#7A646E]">
                  Garantizado por la Lic. Karol Suárez (Nutricionista Dietista). Ningún dato se comercializa ni se comparte con terceros publicitarios.
                </p>
              </div>
              <div className="p-3.5 bg-[#FAF7F8] rounded-2xl border border-[#F3E7E9]">
                <p className="font-bold text-[#634752] mb-1">Derechos ARCO del Paciente</p>
                <p className="text-[#7A646E]">
                  Tiene derecho a conocer, actualizar, rectificar y solicitar copia íntegra de su expediente clínico en cualquier momento.
                </p>
              </div>
              <div className="p-3.5 bg-[#FAF7F8] rounded-2xl border border-[#F3E7E9]">
                <p className="font-bold text-[#634752] mb-1">Cifrado E2EE & Bóveda Médica</p>
                <p className="text-[#7A646E]">
                  Comunicación cifrada de extremo a extremo (E2EE) y almacenamiento protegido con algoritmo criptográfico militar AES-256.
                </p>
              </div>
            </div>
          </div>

          {/* Legal statement excerpt */}
          <div className="bg-[#FAF5F8] p-4 rounded-2xl border border-[#EADEE4] text-xs text-[#6B5360] space-y-2">
            <p className="font-medium text-[#5D424E] flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-[#B7A6CF]" />
              Extracto del Consentimiento Informado Nutricional:
            </p>
            <p className="italic leading-relaxed">
              &ldquo;Declaro de manera voluntaria, previa y explícita que autorizo a la profesional <strong>Karol Suárez</strong> (Nutricionista Dietista) para recolectar y almacenar mis datos personales e historial clínico nutricional con fines exclusivos de asesoría alimentaria, control antropométrico y optimización de mi salud. Conozco que el canal de atención directa es el WhatsApp/Teléfono <strong>302 4708368</strong> y que puedo ejercer mis derechos en cualquier momento.&rdquo;
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#FAF7F8] p-4 border-t border-[#F0DFE3] flex flex-wrap items-center justify-between gap-3 shrink-0">
          <button
            onClick={handlePrintOrDownload}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#6B5360] bg-white border border-[#E2CFD4] rounded-xl hover:bg-gray-50 transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Descargar Copia</span>
          </button>
          <div className="flex items-center gap-2">
            {patient && !patient.consent.signed && onSignConsent && (
              <button
                onClick={() => {
                  onSignConsent(patient.id);
                  onClose();
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-[#DE8287] hover:bg-[#C4676D] rounded-xl transition-colors shadow-xs"
              >
                Firmar Consentimiento Digital
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-[#634752] hover:bg-[#F0E4E7] rounded-xl transition-colors"
            >
              Entendido y Cerrar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

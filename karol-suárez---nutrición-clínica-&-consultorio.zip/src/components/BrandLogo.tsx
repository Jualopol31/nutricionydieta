import React from 'react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'full' | 'icon' | 'horizontal';
  className?: string;
  showSubtitle?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  size = 'md',
  variant = 'full',
  className = '',
  showSubtitle = true,
}) => {
  const iconSizes = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-18 h-18',
    xl: 'w-24 h-24',
  };

  const textSizes = {
    sm: { title: 'text-sm tracking-[0.16em]', sub: 'text-[9px] tracking-[0.22em]' },
    md: { title: 'text-base sm:text-lg tracking-[0.18em]', sub: 'text-[10px] tracking-[0.25em]' },
    lg: { title: 'text-2xl sm:text-3xl tracking-[0.2em]', sub: 'text-xs sm:text-sm tracking-[0.28em]' },
    xl: { title: 'text-3xl sm:text-4xl tracking-[0.22em]', sub: 'text-sm sm:text-base tracking-[0.3em]' },
  };

  const LogoIcon = (
    <div className={`relative flex items-center justify-center ${iconSizes[size]} shrink-0`}>
      <svg
        viewBox="0 0 160 160"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-xs select-none"
      >
        {/* Soft Lilac wellness crescent */}
        <path
          d="M 98 122 C 122 118 134 98 128 78 C 122 60 106 56 94 62 C 82 68 76 86 80 104 C 84 118 92 122 98 122 Z"
          fill="#DDD4EB"
          fillOpacity="0.75"
        />
        <path
          d="M 106 72 C 118 84 116 106 100 118 C 114 116 126 102 124 88 C 122 76 114 70 106 72 Z"
          fill="#BCA9D6"
        />
        {/* Apple with leaf at top */}
        <path
          d="M 98 48 C 94 44 90 45 88 48 C 86 45 82 44 78 48 C 76 53 78 58 88 62 C 98 58 100 53 98 48 Z"
          stroke="#DE8287"
          strokeWidth="2.5"
          fill="#FFF3F4"
        />
        <path
          d="M 88 47 C 88 43 90 41 93 40"
          stroke="#DE8287"
          strokeWidth="2"
          strokeLinecap="round"
        />
        {/* Dotted wellness curve */}
        <circle cx="86" cy="74" r="2.2" fill="#BAA9CF" />
        <circle cx="88" cy="81" r="2.2" fill="#BAA9CF" />
        <circle cx="91" cy="88" r="2.2" fill="#BAA9CF" />
        <circle cx="95" cy="95" r="2.2" fill="#BAA9CF" />
        <circle cx="99" cy="102" r="2.2" fill="#BAA9CF" />
        <circle cx="103" cy="109" r="2.2" fill="#BAA9CF" />
        {/* Calligraphic KS Monogram in Dusty Rose */}
        <path
          d="M 58 40 C 60 52 58 72 55 96 C 53 112 50 126 44 134"
          stroke="#DE8287"
          strokeWidth="4"
          strokeLinecap="round"
        />
        <path
          d="M 52 78 C 62 76 72 66 79 56 C 82 52 83 48 80 47 C 77 46 72 52 64 65 L 56 78"
          stroke="#DE8287"
          strokeWidth="3.6"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 59 78 C 66 86 78 104 88 114 C 92 118 97 119 99 116 C 101 113 97 106 91 97"
          stroke="#DE8287"
          strokeWidth="3.6"
          strokeLinecap="round"
        />
        <path
          d="M 78 68 C 84 64 92 65 96 70 C 100 76 98 84 90 90 C 82 96 79 104 84 111 C 88 116 97 116 102 110"
          stroke="#DE8287"
          strokeWidth="3.5"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );

  if (variant === 'icon') {
    return <div className={`inline-flex items-center ${className}`}>{LogoIcon}</div>;
  }

  if (variant === 'horizontal') {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        {LogoIcon}
        <div className="flex flex-col text-left justify-center">
          <span
            className={`font-semibold uppercase text-[#573946] leading-none ${textSizes[size].title}`}
            style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
          >
            Karol Suárez
          </span>
          {showSubtitle && (
            <span className={`font-medium uppercase text-[#967C87] mt-1 ${textSizes[size].sub}`}>
              Nutricionista Dietista
            </span>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`flex flex-col items-center text-center ${className}`}>
      {LogoIcon}
      <div className="mt-2.5 flex flex-col items-center">
        <h1
          className={`font-bold uppercase text-[#573946] leading-tight ${textSizes[size].title}`}
          style={{ fontFamily: "'Playfair Display', Georgia, serif" }}
        >
          Karol Suárez
        </h1>
        {showSubtitle && (
          <div className="flex items-center gap-2 mt-1 w-full justify-center">
            <span className="h-px w-6 bg-[#D8BAC1] inline-block opacity-75"></span>
            <span className={`font-semibold uppercase text-[#967C87] ${textSizes[size].sub}`}>
              Nutricionista Dietista
            </span>
            <span className="h-px w-6 bg-[#D8BAC1] inline-block opacity-75"></span>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  Bell,
  BellRing,
  Check,
  Clock,
  Droplets,
  Calendar,
  Sparkles,
  X,
  CreditCard,
  XCircle,
  CheckCircle2,
  Trash2,
} from 'lucide-react';
import { InAppNotification } from '../types';

interface NotificationManagerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: InAppNotification[];
  onClearNotifications: () => void;
  onTriggerBanner: (title: string, body: string, icon?: string) => void;
}

export const NotificationManager: React.FC<NotificationManagerProps> = ({
  isOpen,
  onClose,
  notifications,
  onClearNotifications,
  onTriggerBanner,
}) => {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [dietReminders, setDietReminders] = useState(true);
  const [waterReminders, setWaterReminders] = useState(true);
  const [appointmentReminders, setAppointmentReminders] = useState(true);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const playChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.6);
    } catch {
      // AudioContext fallback
    }
  };

  const requestBrowserPermission = async () => {
    if ('Notification' in window) {
      const status = await Notification.requestPermission();
      setPermission(status);
      if (status === 'granted') {
        playChime();
        onTriggerBanner(
          '🔔 Notificaciones Push Activadas',
          'Recibirás alertas en tiempo real de citas, confirmaciones y cancelaciones.'
        );
      }
    }
  };

  const sendTestNotification = (type: 'meal' | 'water' | 'appointment' | 'confirm' | 'cancel') => {
    playChime();
    let title = '';
    let body = '';

    if (type === 'meal') {
      title = '🥗 Hora de tu Almuerzo Saludable';
      body = 'Karol Suárez te recuerda: Es momento de tu plato equilibrado (130g de proteína magra + ensalada multicolor). ¡Buen provecho!';
    } else if (type === 'water') {
      title = '💧 Recordatorio de Hidratación';
      body = 'Es hora de tomar un vaso de agua fresca (250ml) para cumplir tu meta del día.';
    } else if (type === 'confirm') {
      title = '✅ Cita Confirmada en Tiempo Real';
      body = 'Tu consulta ha sido confirmada en la agenda compartida de Karol Suárez para el 18 de Octubre a las 10:00 AM.';
    } else if (type === 'cancel') {
      title = '⚠️ Notificación de Cancelación de Cita';
      body = 'Se ha cancelado el turno solicitado. El horario ha quedado disponible en la agenda.';
    } else {
      title = '📅 Recordatorio de Consulta Nutricional';
      body = 'Mañana tienes cita de control con Karol Suárez. Recuerda asistir en ayunas de 3 horas para la bioimpedancia.';
    }

    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, { body });
      } catch {
        // Fallback
      }
    }

    onTriggerBanner(title, body);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#FAF3F5] via-[#FFF8F9] to-[#F5EFF9] p-5 border-b border-[#F0DFE3] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#DE8287]/15 flex items-center justify-center text-[#DE8287]">
              <BellRing className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
                Notificaciones en Tiempo Real
              </h3>
              <p className="text-xs text-[#876E7B]">
                Alertas automáticas de citas, cambios y recordatorios de salud
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#9B818D] hover:text-[#523A46] hover:bg-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 sm:p-6 space-y-5 text-xs text-[#503E48] overflow-y-auto">
          {/* Permission Card */}
          <div className="p-4 rounded-2xl border border-[#F0DFE3] bg-[#FAF5F7] flex items-center justify-between gap-3">
            <div>
              <p className="font-semibold text-[#5D424E] text-xs sm:text-sm">
                Permisos de Notificaciones Push
              </p>
              <p className="text-[11px] text-[#8A727E]">
                {permission === 'granted'
                  ? 'Activo: Recibirás alertas del consultorio en tiempo real.'
                  : 'Habilita alertas para enterarte de confirmaciones de citas al instante.'}
              </p>
            </div>
            {permission !== 'granted' ? (
              <button
                onClick={requestBrowserPermission}
                className="px-3 py-1.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors shrink-0"
              >
                Activar
              </button>
            ) : (
              <span className="inline-flex items-center gap-1 text-xs text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full font-medium shrink-0">
                <Check className="w-3.5 h-3.5" />
                Permitido
              </span>
            )}
          </div>

          {/* Recent In-App Notifications Feed */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs uppercase tracking-wider text-[#7A636F]">
                Bandeja de Alertas Recientes ({notifications.length})
              </span>
              {notifications.length > 0 && (
                <button
                  onClick={onClearNotifications}
                  className="text-[11px] text-[#DE8287] hover:underline flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Limpiar</span>
                </button>
              )}
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {notifications.length === 0 ? (
                <p className="text-[11px] text-[#8A727E] italic text-center py-3">
                  No hay notificaciones pendientes.
                </p>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    className="p-3 bg-[#FAF8F9] rounded-xl border border-[#F0E0E4] space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <strong className="font-bold text-xs text-[#523A46]">{n.title}</strong>
                      <span className="text-[10px] text-[#9A818E]">{n.timestamp}</span>
                    </div>
                    <p className="text-[11px] text-[#7A636F]">{n.body}</p>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Test buttons in real time */}
          <div className="pt-2 border-t border-[#F2E5E8] space-y-2">
            <p className="text-[11px] font-bold text-[#7A636F] uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#DE8287]" />
              Probar Alertas en Vivo (Sonido & Visual)
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={() => sendTestNotification('confirm')}
                className="p-2 text-center rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-800 text-[11px] font-medium transition-colors hover:bg-emerald-100"
              >
                Cita Confirmada
              </button>
              <button
                onClick={() => sendTestNotification('cancel')}
                className="p-2 text-center rounded-xl border border-red-200 bg-red-50 text-red-800 text-[11px] font-medium transition-colors hover:bg-red-100"
              >
                Cita Cancelada
              </button>
              <button
                onClick={() => sendTestNotification('meal')}
                className="p-2 text-center rounded-xl border border-[#F0DFE3] bg-[#FAF5F7] text-[#5D424E] text-[11px] font-medium transition-colors hover:bg-[#F6ECF0]"
              >
                Almuerzo
              </button>
              <button
                onClick={() => sendTestNotification('water')}
                className="p-2 text-center rounded-xl border border-sky-200 bg-sky-50 text-sky-800 text-[11px] font-medium transition-colors hover:bg-sky-100"
              >
                Agua
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-[#FAF7F8] p-4 border-t border-[#F0DFE3] flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-white bg-[#DE8287] hover:bg-[#C4676D] rounded-xl shadow-xs transition-colors"
          >
            Guardar y Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};

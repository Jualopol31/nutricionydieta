import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Video,
  Sparkles,
  CheckCircle2,
  X,
  Mail,
  ShieldCheck,
  Zap,
  PhoneCall,
  AlertCircle,
  Building2,
} from 'lucide-react';
import { Patient, Appointment, AvailableSlot, AppointmentModality } from '../types';
import { EmailVerificationModal } from './EmailVerificationModal';

interface AppointmentBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  patient: Patient;
  availableSlots: AvailableSlot[];
  onBookAppointment: (appointment: Appointment) => void;
  onTriggerNotification: (title: string, body: string) => void;
}

export const AppointmentBookingModal: React.FC<AppointmentBookingModalProps> = ({
  isOpen,
  onClose,
  patient,
  availableSlots,
  onBookAppointment,
  onTriggerNotification,
}) => {
  // Ensure default date is not a Sunday (2026-10-16 is Friday)
  const [selectedDate, setSelectedDate] = useState('2026-10-16');
  const [selectedTime, setSelectedTime] = useState('09:30 AM');
  const [modality, setModality] = useState<AppointmentModality>('presencial_pamplona');
  const [reason, setReason] = useState('Control mensual de composición corporal y ajuste de plan');
  const [notes, setNotes] = useState('');
  const [patientEmail, setPatientEmail] = useState(patient.email || 'mariana.gomez@example.com');
  const [isEmailVerified, setIsEmailVerified] = useState(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [sundayError, setSundayError] = useState('');

  // Filter out any slot that falls on a Sunday
  const filteredSlots = availableSlots.filter((slot) => {
    const d = new Date(slot.date + 'T12:00:00');
    return d.getDay() !== 0; // 0 = Sunday
  });

  const soonestSlots = filteredSlots.slice(0, 3);

  if (!isOpen) return null;

  const handleDateChange = (dateValue: string) => {
    setSelectedDate(dateValue);
    const d = new Date(dateValue + 'T12:00:00');
    if (d.getDay() === 0) {
      setSundayError('Los domingos no hay servicio de agenda. Por favor selecciona de lunes a sábado.');
    } else {
      setSundayError('');
    }
  };

  const handleSelectQuickSlot = (slot: AvailableSlot) => {
    handleDateChange(slot.date);
    setSelectedTime(slot.time);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const d = new Date(selectedDate + 'T12:00:00');
    if (d.getDay() === 0) {
      setSundayError('Los domingos no hay agenda disponible. Selecciona una fecha entre lunes y sábado.');
      return;
    }

    if (!isEmailVerified) {
      setIsVerificationModalOpen(true);
      return;
    }

    const price =
      modality === 'presencial_pamplona' || modality === 'presencial_cucuta'
        ? 160000
        : modality === 'virtual_meet'
        ? 140000
        : 120000;

    const locationLabel =
      modality === 'presencial_pamplona'
        ? 'Consultorio Pamplona (Norte de Santander)'
        : modality === 'presencial_cucuta'
        ? 'Consultorio Cúcuta (Norte de Santander)'
        : modality === 'virtual_meet'
        ? 'Videollamada Google Meet'
        : 'Llamada Telefónica Normal';

    const newAppointment: Appointment = {
      id: `app-${Date.now()}`,
      patientId: patient.id,
      patientName: patient.name,
      patientEmail: patientEmail,
      patientPhone: patient.phone,
      date: selectedDate,
      time: selectedTime,
      type: modality,
      status: 'pendiente',
      paymentStatus: 'pendiente',
      priceCOP: price,
      reason,
      notes: notes || locationLabel,
      emailVerified: true,
      createdByRole: 'patient',
      createdAt: new Date().toISOString(),
    };

    onBookAppointment(newAppointment);

    onTriggerNotification(
      '📅 Solicitud de Cita Registrada',
      `Tu cita para el ${selectedDate} en ${locationLabel} ha sido registrada. Por favor transfiere el valor por Bancolombia/Nequi y sube tu comprobante para que el consultorio de la Dra. Karol Suárez la confirme.`
    );

    onClose();
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in overflow-y-auto">
        <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] overflow-hidden my-auto max-h-[92vh] flex flex-col">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#FAF3F5] via-[#FFF8F9] to-[#F5EFF9] p-5 border-b border-[#F0DFE3] flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#DE8287]/15 flex items-center justify-center text-[#DE8287]">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
                  Agendar Cita Nutricional
                </h3>
                <p className="text-xs text-[#876E7B]">
                  Consultorio Dra. Karol Suárez · Pamplona, Cúcuta & Virtual
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-xl text-[#9A818E] hover:text-[#523A46] hover:bg-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form scrollable body */}
          <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-xs text-[#523A46]">
            {/* Quick slots (Excluding Sundays!) */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold uppercase tracking-wider text-[11px] text-[#7A636F] flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-[#DE8287]" />
                  Citas Más Prontas Disponibles (Lunes a Sábado):
                </span>
                <span className="text-[10px] text-[#876E7B]">Sin Domingos</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {soonestSlots.map((slot) => {
                  const isSelected = selectedDate === slot.date && selectedTime === slot.time;
                  return (
                    <button
                      key={slot.id}
                      type="button"
                      onClick={() => handleSelectQuickSlot(slot)}
                      className={`p-3 rounded-2xl border text-left transition-all ${
                        isSelected
                          ? 'bg-[#FAF0F3] border-[#DE8287] shadow-2xs ring-1 ring-[#DE8287]/30'
                          : 'bg-[#FCFAF9] border-[#E8DCE0] hover:bg-[#F9F5F6]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-[#523A46]">{slot.date}</span>
                        {isSelected && <span className="w-2 h-2 rounded-full bg-[#DE8287]"></span>}
                      </div>
                      <p className="text-xs font-semibold text-[#DE8287] mt-1 font-mono">{slot.time}</p>
                      <span className="text-[10px] text-[#876E7B] mt-0.5 block">Disponible</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Modality Selector: Pamplona, Cúcuta, Meet, Llamada */}
            <div>
              <label className="block font-bold uppercase tracking-wider text-[11px] text-[#7A636F] mb-2">
                Sede o Modalidad de Atención:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setModality('presencial_pamplona')}
                  className={`p-3 rounded-2xl border text-left flex items-start gap-2.5 transition-all ${
                    modality === 'presencial_pamplona'
                      ? 'bg-[#FAF0F3] border-[#DE8287] shadow-2xs ring-1 ring-[#DE8287]/20'
                      : 'bg-[#FCFAF9] border-[#E8DCE0] hover:bg-[#F9F5F6]'
                  }`}
                >
                  <MapPin className="w-4 h-4 text-[#DE8287] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-xs text-[#523A46] block">Presencial Pamplona</span>
                    <span className="text-[10px] text-[#876E7B] block">Sede Consultorio Pamplona</span>
                    <span className="text-[10px] font-mono font-bold text-[#DE8287] mt-0.5 block">$160,000 COP</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setModality('presencial_cucuta')}
                  className={`p-3 rounded-2xl border text-left flex items-start gap-2.5 transition-all ${
                    modality === 'presencial_cucuta'
                      ? 'bg-[#FAF0F3] border-[#DE8287] shadow-2xs ring-1 ring-[#DE8287]/20'
                      : 'bg-[#FCFAF9] border-[#E8DCE0] hover:bg-[#F9F5F6]'
                  }`}
                >
                  <Building2 className="w-4 h-4 text-[#DE8287] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-xs text-[#523A46] block">Presencial Cúcuta</span>
                    <span className="text-[10px] text-[#876E7B] block">Sede Consultorio Cúcuta</span>
                    <span className="text-[10px] font-mono font-bold text-[#DE8287] mt-0.5 block">$160,000 COP</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setModality('virtual_meet')}
                  className={`p-3 rounded-2xl border text-left flex items-start gap-2.5 transition-all ${
                    modality === 'virtual_meet'
                      ? 'bg-[#FAF0F3] border-[#DE8287] shadow-2xs ring-1 ring-[#DE8287]/20'
                      : 'bg-[#FCFAF9] border-[#E8DCE0] hover:bg-[#F9F5F6]'
                  }`}
                >
                  <Video className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-xs text-[#523A46] block">Virtual Google Meet</span>
                    <span className="text-[10px] text-[#876E7B] block">Videollamada privada en línea</span>
                    <span className="text-[10px] font-mono font-bold text-[#DE8287] mt-0.5 block">$140,000 COP</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setModality('llamada_telefonica')}
                  className={`p-3 rounded-2xl border text-left flex items-start gap-2.5 transition-all ${
                    modality === 'llamada_telefonica'
                      ? 'bg-[#FAF0F3] border-[#DE8287] shadow-2xs ring-1 ring-[#DE8287]/20'
                      : 'bg-[#FCFAF9] border-[#E8DCE0] hover:bg-[#F9F5F6]'
                  }`}
                >
                  <PhoneCall className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-xs text-[#523A46] block">Llamada Telefónica Normal</span>
                    <span className="text-[10px] text-[#876E7B] block">Consulta por llamada celular</span>
                    <span className="text-[10px] font-mono font-bold text-[#DE8287] mt-0.5 block">$120,000 COP</span>
                  </div>
                </button>
              </div>
            </div>

            {/* Date & Time with Sunday ban */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold mb-1 text-[#523A46]">
                  Fecha Seleccionada * (Lunes a Sábado)
                </label>
                <input
                  type="date"
                  required
                  value={selectedDate}
                  onChange={(e) => handleDateChange(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-[#523A46]">
                  Horario Disponible *
                </label>
                <select
                  value={selectedTime}
                  onChange={(e) => setSelectedTime(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                >
                  <option value="08:30 AM">08:30 AM</option>
                  <option value="09:30 AM">09:30 AM</option>
                  <option value="10:30 AM">10:30 AM</option>
                  <option value="11:30 AM">11:30 AM</option>
                  <option value="02:30 PM">02:30 PM</option>
                  <option value="03:30 PM">03:30 PM</option>
                  <option value="04:30 PM">04:30 PM</option>
                  <option value="05:30 PM">05:30 PM</option>
                </select>
              </div>
            </div>

            {sundayError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                <span>{sundayError}</span>
              </div>
            )}

            {/* Reason */}
            <div>
              <label className="block font-semibold mb-1 text-[#523A46]">
                Motivo de Consulta o Enfoque Nutricional *
              </label>
              <input
                type="text"
                required
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="ej. Control mensual, ganancia de masa magra, bienestar digestivo..."
                className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
              />
            </div>

            {/* Email Verification Box */}
            <div className="p-4 rounded-2xl bg-[#FCFAF9] border border-[#EEDDE1] space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold uppercase tracking-wider text-[11px] text-[#523A46] flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#DE8287]" />
                  Verificación de Correo Electrónico
                </span>
                {isEmailVerified ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Correo Verificado
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-medium">
                    Verificación Requerida
                  </span>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#7A636F] mb-1">
                  Correo electrónico para confirmación:
                </label>
                <div className="flex gap-2">
                  <input
                    type="email"
                    required
                    value={patientEmail}
                    onChange={(e) => {
                      setPatientEmail(e.target.value);
                      setIsEmailVerified(false);
                    }}
                    className="flex-1 px-3 py-2 bg-white border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                  {!isEmailVerified && (
                    <button
                      type="button"
                      onClick={() => setIsVerificationModalOpen(true)}
                      className="px-3.5 py-2 bg-[#FAF0F3] hover:bg-[#FCE6EB] text-[#DE8287] border border-[#F2D7DF] rounded-xl font-semibold text-xs transition-colors shrink-0 flex items-center gap-1.5 shadow-2xs"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>Solicitar Verificación al Correo</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Submit */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-[11px] text-[#876E7B]">
                Paso siguiente: <strong className="text-[#DE8287]">Subir comprobante de pago de transferencia</strong>
              </span>
              <div className="flex gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 text-xs font-medium text-[#7A636F] hover:bg-[#FAF4F6] rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={!!sundayError}
                  className="px-5 py-2.5 bg-[#DE8287] hover:bg-[#C4676D] disabled:opacity-50 text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isEmailVerified ? 'Confirmar Cita & Continuar al Pago' : 'Solicitar Verificación y Agendar'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <EmailVerificationModal
        isOpen={isVerificationModalOpen}
        onClose={() => setIsVerificationModalOpen(false)}
        email={patientEmail}
        onVerified={(verifiedEmail) => {
          if (verifiedEmail) setPatientEmail(verifiedEmail);
          setIsEmailVerified(true);
        }}
      />
    </>
  );
};

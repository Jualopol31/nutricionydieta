import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  CreditCard,
  Plus,
  Search,
  Users,
  Receipt,
  ShieldCheck,
  Printer,
  FileText,
  Lock,
  Download,
  AlertCircle,
  Eye,
  Utensils,
  MessageCircle,
} from 'lucide-react';
import { Appointment, AvailableSlot, Patient, PaymentDetails, PaymentVoucher, DoctorBankConfig, E2EEMessage } from '../../types';
import { SharedCalendarView } from '../SharedCalendarView';
import { PaymentModal } from '../PaymentModal';
import { EncryptedChat } from '../EncryptedChat';

interface AssistantDashboardProps {
  appointments: Appointment[];
  patients: Patient[];
  slots: AvailableSlot[];
  bankConfig: DoctorBankConfig;
  messages: E2EEMessage[];
  onAddSlot: (newSlot: AvailableSlot) => void;
  onToggleSlot: (slotId: string) => void;
  onBookAppointment: (newApp: Appointment) => void;
  onRescheduleAppointment: (appId: string, newDate: string, newTime: string) => void;
  onConfirmAppointment: (appId: string) => void;
  onCancelAppointment: (appId: string, reason?: string) => void;
  onPaymentSuccess: (appId: string, details: PaymentDetails) => void;
  onUploadVoucher: (appId: string, voucher: PaymentVoucher) => void;
  onTriggerNotification: (title: string, body: string) => void;
  onAddNewPatient: (patient: Patient) => void;
  onSendMessage: (msg: E2EEMessage) => void;
}

export const AssistantDashboard: React.FC<AssistantDashboardProps> = ({
  appointments,
  patients,
  slots,
  bankConfig,
  messages,
  onAddSlot,
  onToggleSlot,
  onBookAppointment,
  onRescheduleAppointment,
  onConfirmAppointment,
  onCancelAppointment,
  onPaymentSuccess,
  onUploadVoucher,
  onTriggerNotification,
  onAddNewPatient,
  onSendMessage,
}) => {
  const [activeTab, setActiveTab] = useState<'calendar' | 'payments' | 'clinical' | 'diet_print' | 'chat'>('calendar');
  const [selectedPatientId, setSelectedPatientId] = useState(patients[0]?.id || '');
  const [searchTerm, setSearchTerm] = useState('');
  const [payingAppointment, setPayingAppointment] = useState<Appointment | null>(null);

  const currentPatient = patients.find((p) => p.id === selectedPatientId) || patients[0];

  const pendingVouchers = appointments.filter((a) => a.paymentStatus === 'comprobante_subido');
  const paidAppointments = appointments.filter((a) => a.paymentStatus === 'pagado');

  const filteredPatients = patients.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.documentId.includes(searchTerm) ||
      p.phone.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-3xl border border-[#EEDDE1] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-[#523A46] font-brand-title">
              Panel de Asistente & Recepción
            </h2>
            <span className="text-[10px] font-semibold bg-sky-100 text-sky-800 px-2.5 py-0.5 rounded-full border border-sky-200">
              Colaboración con Dra. Karol Suárez
            </span>
          </div>
          <p className="text-xs text-[#876E7B] mt-0.5">
            Sedes Pamplona & Cúcuta · Gestión compartida de agendas, validación de transferencias y respuesta al chat.
          </p>
        </div>

        {/* Tab Pills */}
        <div className="flex items-center bg-[#FAF5F7] p-1 rounded-2xl border border-[#EEDDE1] text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition-all ${
              activeTab === 'calendar'
                ? 'bg-[#DE8287] text-white shadow-2xs'
                : 'text-[#7A636F] hover:text-[#523A46]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Agenda & Citas</span>
          </button>
          <button
            onClick={() => setActiveTab('payments')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition-all relative ${
              activeTab === 'payments'
                ? 'bg-[#DE8287] text-white shadow-2xs'
                : 'text-[#7A636F] hover:text-[#523A46]'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Caja & Comprobantes</span>
            {pendingVouchers.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('clinical')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition-all ${
              activeTab === 'clinical'
                ? 'bg-[#DE8287] text-white shadow-2xs'
                : 'text-[#7A636F] hover:text-[#523A46]'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Historias Clínicas</span>
          </button>
          <button
            onClick={() => setActiveTab('diet_print')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition-all ${
              activeTab === 'diet_print'
                ? 'bg-[#DE8287] text-white shadow-2xs'
                : 'text-[#7A636F] hover:text-[#523A46]'
            }`}
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Imprimir Planes</span>
          </button>
          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl transition-all ${
              activeTab === 'chat'
                ? 'bg-[#DE8287] text-white shadow-2xs'
                : 'text-[#7A636F] hover:text-[#523A46]'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Chat con Pacientes</span>
          </button>
        </div>
      </div>

      {/* 1. SHARED CALENDAR & AGENDAS */}
      {activeTab === 'calendar' && (
        <SharedCalendarView
          role="assistant"
          appointments={appointments}
          patients={patients}
          slots={slots}
          onAddSlot={onAddSlot}
          onToggleSlot={onToggleSlot}
          onBookAppointment={onBookAppointment}
          onRescheduleAppointment={onRescheduleAppointment}
          onConfirmAppointment={(id) => {
            onConfirmAppointment(id);
            onTriggerNotification(
              '✅ Cita Confirmada por Asistente',
              'La cita ha sido validada y confirmada en la agenda compartida.'
            );
          }}
          onCancelAppointment={(id, reason) => {
            onCancelAppointment(id, reason);
            onTriggerNotification(
              '⚠️ Cita Cancelada',
              'El turno ha sido liberado para nuevos pacientes.'
            );
          }}
          onOpenPaymentModal={(app) => setPayingAppointment(app)}
        />
      )}

      {/* 2. PAYMENTS & VOUCHERS VALIDATION */}
      {activeTab === 'payments' && (
        <div className="space-y-6">
          {/* Pending vouchers review */}
          <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
              <div>
                <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
                  Comprobantes de Transferencia Pendientes de Validación ({pendingVouchers.length})
                </h3>
                <p className="text-xs text-[#876E7B]">
                  Revisa los pagos enviados a Bancolombia / Nequi / Daviplata antes de confirmar la cita en agenda.
                </p>
              </div>
            </div>

            {pendingVouchers.length === 0 ? (
              <div className="p-8 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
                <p className="font-bold text-sm text-[#523A46]">¡Al día! No hay comprobantes por revisar</p>
                <p className="text-xs text-[#876E7B]">Todos los pagos han sido verificados.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pendingVouchers.map((app) => (
                  <div
                    key={app.id}
                    className="p-5 rounded-2xl border border-sky-200 bg-sky-50/50 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-base text-[#523A46]">{app.patientName}</span>
                      <span className="text-[10px] bg-sky-100 text-sky-800 font-bold px-2.5 py-0.5 rounded-full uppercase">
                        Comprobante Subido
                      </span>
                    </div>

                    <div className="text-xs text-[#523A46] space-y-1">
                      <p>
                        Referencia: <span className="font-mono font-bold text-[#DE8287]">{app.paymentVoucher?.referenceNumber || 'BC-9481028'}</span>
                      </p>
                      <p>Método: {app.paymentVoucher?.method || 'Bancolombia'}</p>
                      <p>Cita: {app.date} ({app.time})</p>
                      <p className="font-bold text-sm text-[#523A46]">
                        Valor: ${(app.priceCOP || 160000).toLocaleString('es-CO')} COP
                      </p>
                    </div>

                    <div className="pt-2 border-t border-sky-200 flex items-center justify-between">
                      <button
                        onClick={() => setPayingAppointment(app)}
                        className="text-xs text-[#523A46] underline font-semibold flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Ver Datos de Cuenta</span>
                      </button>

                      <button
                        onClick={() => {
                          const receiptNum = `REC-KS-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
                          onPaymentSuccess(app.id, {
                            transactionId: `TXN-${Math.floor(1000000 + Math.random() * 9000000)}`,
                            referenceNumber: app.paymentVoucher?.referenceNumber || 'REF-APP',
                            amount: app.priceCOP || 160000,
                            currency: 'COP',
                            method: app.paymentVoucher?.method || 'Bancolombia',
                            paidAt: new Date().toISOString(),
                            payerName: app.patientName,
                            payerEmail: app.patientEmail,
                            receiptNumber: receiptNum,
                          });
                          onConfirmAppointment(app.id);
                          onTriggerNotification(
                            '✅ Pago Validado por Asistente',
                            `Comprobante de ${app.patientName} aprobado y cita confirmada.`
                          );
                        }}
                        className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
                      >
                        Aprobar Pago y Confirmar Cita
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* All Paid Records with PDF download */}
          <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-4">
            <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
              Registro General de Pagos & Recibos Emitidos
            </h3>
            <div className="space-y-3">
              {paidAppointments.map((app) => (
                <div
                  key={app.id}
                  className="p-4 rounded-2xl border border-[#EEDDE1] bg-[#FAF8F9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <span className="font-bold text-sm text-[#523A46]">{app.patientName}</span>
                    <p className="text-[#7A636F]">
                      Fecha: {app.date} · Comprobante: <span className="font-mono text-[#DE8287]">{app.paymentDetails?.receiptNumber || 'REC-KS-2026'}</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-base text-[#523A46]">
                      ${(app.priceCOP || 160000).toLocaleString('es-CO')} COP
                    </span>
                    <button
                      onClick={() => setPayingAppointment(app)}
                      className="px-3 py-1.5 bg-white hover:bg-[#FAF4F6] text-[#523A46] rounded-xl border border-[#E2CFD4] font-semibold text-xs transition-colors flex items-center gap-1 shadow-2xs"
                    >
                      <Download className="w-3.5 h-3.5 text-[#DE8287]" />
                      <span>Descargar Recibo PDF</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 3. FULL CLINICAL RECORDS (Only for Doctor & Assistant) */}
      {activeTab === 'clinical' && (
        <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F0DFE3] pb-3">
            <div>
              <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#DE8287]" />
                Historias Clínicas Completas (Acceso Exclusivo Consultorio)
              </h3>
              <p className="text-xs text-[#876E7B]">
                Expedientes médicos, antecedentes y notas confidenciales SOAP.
              </p>
            </div>
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(e.target.value)}
              className="px-3 py-2 text-xs bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} - {p.documentId}
                </option>
              ))}
            </select>
          </div>

          {currentPatient && (
            <div className="space-y-4 text-xs text-[#523A46]">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-[#FCFAF9] p-4 rounded-2xl border border-[#EEDDE1]">
                <div>
                  <span className="text-[#876E7B] block text-[11px]">Paciente:</span>
                  <strong>{currentPatient.name}</strong> ({currentPatient.age} años)
                </div>
                <div>
                  <span className="text-[#876E7B] block text-[11px]">Documento:</span>
                  <strong className="font-mono">{currentPatient.documentType} {currentPatient.documentId}</strong>
                </div>
                <div>
                  <span className="text-[#876E7B] block text-[11px]">Teléfono:</span>
                  <strong className="font-mono">{currentPatient.phone}</strong>
                </div>
              </div>

              {/* Pathologies & Allergies */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 bg-[#FAF7F8] rounded-2xl border border-[#F2E5E8] space-y-2">
                  <p className="font-bold text-xs uppercase text-[#523A46]">Patologías & Diagnósticos:</p>
                  <p>{currentPatient.clinicalHistory.pathologies.join(', ') || 'Ninguna registrada'}</p>
                </div>
                <div className="p-4 bg-[#FAF7F8] rounded-2xl border border-[#F2E5E8] space-y-2">
                  <p className="font-bold text-xs uppercase text-[#523A46]">Alergias & Intolerancias:</p>
                  <p>Alergias: {currentPatient.clinicalHistory.allergies.join(', ') || 'Ninguna'}</p>
                  <p>Intolerancias: {currentPatient.clinicalHistory.intolerances.join(', ') || 'Ninguna'}</p>
                </div>
              </div>

              {/* SOAP notes */}
              <div className="space-y-3">
                <p className="font-bold text-xs uppercase text-[#523A46]">Evolución Clínica (SOAP):</p>
                {currentPatient.consultationNotes?.map((note) => (
                  <div key={note.id} className="p-4 rounded-2xl bg-[#FCFAF9] border border-[#EEDDE1] space-y-2">
                    <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-1.5">
                      <strong>{note.reason}</strong>
                      <span className="font-mono text-[#8C7480]">{note.date}</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                      <div><strong>[S] Subjetivo:</strong> {note.subjective}</div>
                      <div><strong>[O] Objetivo:</strong> {note.objective}</div>
                      <div><strong>[A] Análisis:</strong> {note.assessment}</div>
                      <div><strong>[P] Plan:</strong> {note.plan}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. PRINT NUTRITION MEAL PLANS */}
      {activeTab === 'diet_print' && (
        <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F0DFE3] pb-3">
            <div>
              <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title flex items-center gap-2">
                <Printer className="w-5 h-5 text-[#DE8287]" />
                Impresión de Planes Nutricionales (Asistente & Consultorio)
              </h3>
              <p className="text-xs text-[#876E7B]">
                Selecciona el paciente para imprimir su pauta alimentaria oficial.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="px-3 py-2 text-xs bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimir Plan</span>
              </button>
            </div>
          </div>

          {currentPatient && currentPatient.plans?.[0] ? (
            <div className="p-6 bg-[#FAF7F8] rounded-2xl border border-[#EEDDE1] space-y-4 print-area text-xs text-[#523A46]">
              <div className="flex items-center justify-between border-b border-[#E8D4DA] pb-3">
                <div>
                  <h4 className="font-bold text-base text-[#523A46]">{currentPatient.plans[0].title}</h4>
                  <p className="text-[#876E7B]">Paciente: <strong>{currentPatient.name}</strong> · Meta: {currentPatient.plans[0].goal}</p>
                </div>
                <div className="text-right font-mono font-bold text-sm text-[#DE8287]">
                  {currentPatient.plans[0].caloriesTarget} kcal/día
                </div>
              </div>

              <div className="space-y-3">
                {currentPatient.plans[0].meals.map((m) => (
                  <div key={m.id} className="p-3 bg-white rounded-xl border border-[#EFE2E5]">
                    <div className="flex items-center justify-between font-bold">
                      <span>{m.title}</span>
                      <span className="font-mono text-[#8C7480]">{m.timeSchedule}</span>
                    </div>
                    <ul className="list-disc list-inside mt-1.5 space-y-0.5 text-[11px] text-[#634856]">
                      {m.foods.map((f) => (
                        <li key={f.id}>
                          <strong>{f.name}</strong>: {f.portion}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-xs text-[#8A727E]">Este paciente aún no tiene un plan configurado.</p>
          )}
        </div>
      )}

      {/* 5. ENCRYPTED CHAT AS ASSISTANT */}
      {activeTab === 'chat' && currentPatient && (
        <EncryptedChat
          currentRole="assistant"
          patient={currentPatient}
          messages={messages}
          bankConfig={bankConfig}
          onSendMessage={onSendMessage}
        />
      )}

      {/* Payment / Voucher Modal */}
      {payingAppointment && (
        <PaymentModal
          isOpen={!!payingAppointment}
          onClose={() => setPayingAppointment(null)}
          appointment={payingAppointment}
          bankConfig={bankConfig}
          userRole="assistant"
          onUploadVoucher={onUploadVoucher}
          onPaymentSuccess={onPaymentSuccess}
        />
      )}
    </div>
  );
};

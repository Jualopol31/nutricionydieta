import React, { useState } from 'react';
import {
  Utensils,
  Clock,
  CheckCircle2,
  Circle,
  ChevronDown,
  ChevronUp,
  Droplets,
  Flame,
  Award,
  BellRing,
  Printer,
  Sparkles,
  Info,
  Pill,
  Camera,
} from 'lucide-react';
import { Patient, MealItem } from '../../types';

interface TodayMealPlanProps {
  patient: Patient;
  onToggleMealCompleted: (mealId: string) => void;
  onTriggerNotification: (title: string, body: string) => void;
  onOpenPlateScanner?: () => void;
}

export const TodayMealPlan: React.FC<TodayMealPlanProps> = ({
  patient,
  onToggleMealCompleted,
  onTriggerNotification,
  onOpenPlateScanner,
}) => {
  const activePlan =
    patient.plans?.find((p) => p.id === patient.activePlanId) || patient.plans?.[0];

  const [expandedMealId, setExpandedMealId] = useState<string | null>(
    activePlan?.meals?.[0]?.id || null
  );
  const [glassesDrunk, setGlassesDrunk] = useState<number>(5);

  if (!activePlan || !activePlan.meals || activePlan.meals.length === 0) {
    return (
      <div className="bg-white rounded-3xl border border-[#EEDDE1] p-8 text-center space-y-4">
        <Utensils className="w-12 h-12 text-[#DE8287] mx-auto opacity-50" />
        <h3 className="text-lg font-bold text-[#523A46] font-brand-title">
          Tu plan se está preparando
        </h3>
        <p className="text-xs text-[#8C7480] max-w-md mx-auto">
          Karol Suárez está configurando tu plan nutricional personalizado con tus requerimientos calóricos exactos.
        </p>
        {onOpenPlateScanner && (
          <div className="pt-2">
            <button
              onClick={onOpenPlateScanner}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors"
            >
              <Camera className="w-4 h-4" />
              <span>Escanear Comida con Cámara</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  const completedMealsCount = activePlan.meals.filter((m) => m.isCompletedToday).length;
  const totalMealsCount = activePlan.meals.length;
  const adherencePercentage = Math.round((completedMealsCount / totalMealsCount) * 100);
  const targetGlasses = Math.round((activePlan.waterLiters * 1000) / 250);
  const currentLiters = ((glassesDrunk * 250) / 1000).toFixed(1);

  const toggleExpand = (id: string) => {
    setExpandedMealId((prev) => (prev === id ? null : id));
  };

  const handlePrint = () => {
    window.print();
  };

  const triggerMealReminder = (meal: MealItem) => {
    onTriggerNotification(
      `🔔 Recordatorio: ${meal.title}`,
      `Es hora de tu ${meal.title} (${meal.timeSchedule}). Recuerda seguir las porciones de Karol Suárez para alcanzar tus objetivos.`
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Summary Banner */}
      <div className="bg-gradient-to-br from-[#FFF5F6] via-[#FAF1F8] to-[#F3ECF8] rounded-3xl p-5 sm:p-6 border border-[#F0DFE3] shadow-xs relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/80 backdrop-blur-xs border border-[#E8D4D9] rounded-full text-xs font-semibold text-[#B34E57] mb-2 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-[#DE8287]" />
              Plan Nutricional Activo · Karol Suárez
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#573946] font-brand-title">
              {activePlan.title}
            </h2>
            <p className="text-xs sm:text-sm text-[#7D6470] mt-1 max-w-2xl">
              Objetivo: <span className="font-semibold text-[#573946]">{activePlan.goal}</span>
            </p>
          </div>
          <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
            {onOpenPlateScanner && (
              <button
                onClick={onOpenPlateScanner}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#DE8287] hover:bg-[#C4676D] rounded-2xl shadow-xs transition-colors"
                title="Escanear plato con la cámara del dispositivo"
              >
                <Camera className="w-4 h-4" />
                <span>Escanear Plato con Cámara</span>
              </button>
            )}
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#634752] bg-white border border-[#E2CFD4] hover:bg-[#FDF3F5] rounded-2xl transition-colors shadow-2xs"
              title="Imprimir plan"
            >
              <Printer className="w-4 h-4 text-[#DE8287]" />
              <span>Imprimir / PDF</span>
            </button>
          </div>
        </div>

        {/* Nutritional Target & Adherence KPI Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-[#EDDFE3]">
          <div className="bg-white/85 backdrop-blur-xs p-3.5 rounded-2xl border border-[#EEDDE1] shadow-2xs">
            <div className="flex items-center gap-1.5 text-xs text-[#8A727E]">
              <Flame className="w-3.5 h-3.5 text-amber-500" />
              <span>Calorías Meta</span>
            </div>
            <p className="text-lg sm:text-xl font-bold text-[#573946] mt-0.5 font-mono">
              {activePlan.caloriesTarget} <span className="text-xs font-normal">kcal/día</span>
            </p>
          </div>
          <div className="bg-white/85 backdrop-blur-xs p-3.5 rounded-2xl border border-[#EEDDE1] shadow-2xs">
            <div className="flex items-center gap-1.5 text-xs text-[#8A727E]">
              <Award className="w-3.5 h-3.5 text-[#DE8287]" />
              <span>Adherencia Hoy</span>
            </div>
            <p className="text-lg sm:text-xl font-bold text-[#B34E57] mt-0.5">
              {adherencePercentage}%
            </p>
            <div className="w-full bg-[#EEDDE1] h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-[#DE8287] h-full rounded-full transition-all duration-500"
                style={{ width: `${adherencePercentage}%` }}
              ></div>
            </div>
          </div>
          <div className="bg-white/85 backdrop-blur-xs p-3.5 rounded-2xl border border-[#EEDDE1] shadow-2xs">
            <div className="flex items-center gap-1.5 text-xs text-[#8A727E]">
              <Utensils className="w-3.5 h-3.5 text-[#B7A6CF]" />
              <span>Proteína & Macros</span>
            </div>
            <p className="text-xs font-semibold text-[#573946] mt-1 space-x-1">
              <span>{activePlan.macros.proteinG}g P</span> ·{' '}
              <span>{activePlan.macros.carbsG}g C</span> ·{' '}
              <span>{activePlan.macros.fatG}g G</span>
            </p>
            <p className="text-[10px] text-[#9A818E] mt-0.5">
              {activePlan.macros.fiberG}g de fibra
            </p>
          </div>
          <div className="bg-white/85 backdrop-blur-xs p-3.5 rounded-2xl border border-[#EEDDE1] shadow-2xs">
            <div className="flex items-center gap-1.5 text-xs text-[#8A727E]">
              <Droplets className="w-3.5 h-3.5 text-sky-500" />
              <span>Hidratación</span>
            </div>
            <p className="text-lg sm:text-xl font-bold text-sky-900 mt-0.5 font-mono">
              {currentLiters} / {activePlan.waterLiters}L
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Water Tracker Section */}
      <div className="bg-white rounded-3xl border border-[#E1EAF2] p-4 sm:p-5 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 shrink-0">
            <Droplets className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-semibold text-sm sm:text-base text-[#384853]">
              Control de Hidratación ({currentLiters}L de {activePlan.waterLiters}L)
            </h4>
            <p className="text-xs text-[#71828D]">
              Bebe 1 vaso de agua fresca (250ml) entre comidas para mantener tu energía y saciedad.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          {Array.from({ length: targetGlasses }).map((_, i) => {
            const isFilled = i < glassesDrunk;
            return (
              <button
                key={i}
                onClick={() => setGlassesDrunk(isFilled ? i : i + 1)}
                className={`p-1.5 rounded-xl border transition-all ${
                  isFilled
                    ? 'bg-sky-500 border-sky-600 text-white shadow-2xs scale-105'
                    : 'bg-sky-50/60 border-sky-100 text-sky-300 hover:border-sky-300'
                }`}
                title={`Vaso ${i + 1} (250ml)`}
              >
                <Droplets className="w-4 h-4" />
              </button>
            );
          })}
          <button
            onClick={() => setGlassesDrunk((prev) => Math.min(prev + 1, targetGlasses + 4))}
            className="px-2.5 py-1 text-xs font-semibold bg-sky-50 text-sky-700 hover:bg-sky-100 rounded-xl border border-sky-200 transition-colors shrink-0"
          >
            + 1 Vaso
          </button>
        </div>
      </div>

      {/* Meals Timeline */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg text-[#573946] font-brand-title flex items-center gap-2">
            <Utensils className="w-5 h-5 text-[#DE8287]" />
            Menú Detallado del Día
          </h3>
          <span className="text-xs text-[#8A727E]">
            {completedMealsCount} de {totalMealsCount} comidas registradas hoy
          </span>
        </div>

        <div className="space-y-3">
          {activePlan.meals.map((meal) => {
            const isExpanded = expandedMealId === meal.id;
            const isCompleted = !!meal.isCompletedToday;
            return (
              <div
                key={meal.id}
                className={`rounded-2xl border transition-all bg-white shadow-2xs overflow-hidden ${
                  isCompleted
                    ? 'border-emerald-200/80 bg-emerald-50/20'
                    : 'border-[#EEDEE1] hover:border-[#DE8287]/40'
                }`}
              >
                {/* Meal header row */}
                <div
                  onClick={() => toggleExpand(meal.id)}
                  className="p-4 sm:p-4.5 flex items-center justify-between gap-3 cursor-pointer select-none hover:bg-[#FAF6F7]/50 transition-colors"
                >
                  <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                    {/* Checkbox */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleMealCompleted(meal.id);
                      }}
                      className="p-1 rounded-full text-[#B34E57] hover:scale-110 transition-transform shrink-0"
                      title={isCompleted ? 'Marcar como pendiente' : 'Marcar como completada'}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-6 h-6 text-emerald-600 fill-emerald-100" />
                      ) : (
                        <Circle className="w-6 h-6 text-[#DE8287]" />
                      )}
                    </button>
                    {/* Meal info */}
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4
                          className={`font-semibold text-sm sm:text-base ${
                            isCompleted ? 'text-emerald-950 line-through opacity-80' : 'text-[#573946]'
                          }`}
                        >
                          {meal.title}
                        </h4>
                        <span className="inline-flex items-center gap-1 text-[11px] text-[#8C7480] bg-[#FAF3F5] px-2 py-0.5 rounded-full border border-[#F0E0E4] font-medium shrink-0">
                          <Clock className="w-3 h-3 text-[#DE8287]" />
                          {meal.timeSchedule}
                        </span>
                      </div>
                      <p className="text-xs text-[#7A636F] truncate mt-0.5">
                        {meal.description}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        triggerMealReminder(meal);
                      }}
                      className="p-2 rounded-xl text-[#8C7480] hover:text-[#DE8287] hover:bg-[#FAF0F2] transition-colors"
                      title="Simular recordatorio push para esta comida"
                    >
                      <BellRing className="w-4 h-4" />
                    </button>
                    <div className="text-[#9C8490] p-1">
                      {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </div>
                </div>

                {/* Collapsible Food List & Substitutions */}
                {isExpanded && (
                  <div className="px-4 pb-4 sm:px-5 sm:pb-5 pt-1 border-t border-[#F2E5E8] bg-[#FAF8F8]/40 space-y-4">
                    <div>
                      <p className="text-xs font-semibold text-[#664754] uppercase tracking-wider mb-2.5">
                        Porciones e Ingredientes:
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {meal.foods.map((food) => (
                          <div
                            key={food.id}
                            className="p-3 bg-white rounded-xl border border-[#EFE2E5] shadow-2xs flex items-start justify-between gap-2"
                          >
                            <div>
                              <p className="font-semibold text-xs text-[#523A46]">{food.name}</p>
                              <p className="text-[11px] text-[#876E7B] mt-0.5">
                                Porción: <span className="font-medium text-[#523A46]">{food.portion}</span>
                              </p>
                            </div>
                            {food.calories && (
                              <span className="text-[10px] bg-[#FAF0F2] text-[#B34E57] font-semibold px-2 py-0.5 rounded-full shrink-0">
                                {food.calories} kcal
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {meal.substitutions && meal.substitutions.length > 0 && (
                      <div className="p-3 bg-[#FAF2F8] rounded-xl border border-[#EBDCE6] text-xs text-[#634856] space-y-1.5">
                        <p className="font-semibold text-[#5A384A] flex items-center gap-1.5">
                          <Info className="w-3.5 h-3.5 text-[#B7A6CF]" />
                          Opciones de Intercambio & Sustituciones:
                        </p>
                        <ul className="space-y-1 list-disc list-inside text-[11px] text-[#705364]">
                          {meal.substitutions.map((sub, i) => (
                            <li key={i}>{sub}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Karol's Clinical Tips & Supplementation */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-[#EEDDE1] shadow-2xs space-y-3">
          <h4 className="font-bold text-sm sm:text-base text-[#573946] font-brand-title flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#DE8287]" />
            Pautas Clave de Karol Suárez
          </h4>
          <ul className="space-y-2 text-xs text-[#6D5563]">
            {activePlan.keyRecommendations.map((rec, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#DE8287] mt-1.5 shrink-0"></span>
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-[#EEDDE1] shadow-2xs space-y-3">
          <h4 className="font-bold text-sm sm:text-base text-[#573946] font-brand-title flex items-center gap-2">
            <Pill className="w-4 h-4 text-[#B7A6CF]" />
            Suplementación Pautada
          </h4>
          {activePlan.supplementation && activePlan.supplementation.length > 0 ? (
            <ul className="space-y-2 text-xs text-[#6D5563]">
              {activePlan.supplementation.map((sup, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#B7A6CF] mt-1.5 shrink-0"></span>
                  <span>{sup}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs text-[#8A727E]">
              No se requieren suplementos adicionales en esta fase. Tus requerimientos están cubiertos con comida real.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

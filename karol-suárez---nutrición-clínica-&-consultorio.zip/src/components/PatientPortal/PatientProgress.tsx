import React, { useState } from 'react';
import {
  TrendingDown,
  TrendingUp,
  Activity,
  Calendar,
  Scale,
  Plus,
  ArrowRight,
  Info,
  CheckCircle2,
  Printer,
  FileText,
  Clock,
  Sparkles,
  Award,
  X,
  Flame,
} from 'lucide-react';
import { Patient, MetricRecord } from '../../types';
import { BrandLogo } from '../BrandLogo';

interface PatientProgressProps {
  patient: Patient;
  onAddMetric: (newMetric: MetricRecord) => void;
}

export const PatientProgress: React.FC<PatientProgressProps> = ({ patient, onAddMetric }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [activeChartMetric, setActiveChartMetric] = useState<'weight' | 'fat' | 'muscle' | 'waist'>('weight');

  // Form states
  const [newWeight, setNewWeight] = useState('');
  const [newWaist, setNewWaist] = useState('');
  const [newHip, setNewHip] = useState('');
  const [newFat, setNewFat] = useState('');
  const [newNotes, setNewNotes] = useState('');

  const metrics = [...patient.metrics].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  const initialMetric = metrics[0] || {
    weightKg: 68.4,
    bmi: 25.4,
    bodyFatPercent: 29.8,
    muscleMassKg: 24.2,
    waistCm: 76,
    hipCm: 102,
  };
  const latestMetric = metrics[metrics.length - 1] || initialMetric;

  const weightDiff = (latestMetric.weightKg - initialMetric.weightKg).toFixed(1);
  const fatDiff = (latestMetric.bodyFatPercent - initialMetric.bodyFatPercent).toFixed(1);
  const muscleDiff = (latestMetric.muscleMassKg - initialMetric.muscleMassKg).toFixed(1);
  const waistDiff = (latestMetric.waistCm - initialMetric.waistCm).toFixed(1);

  // Time in treatment calculation
  const startDate = new Date(patient.treatmentStartDate || patient.registeredDate || '2026-08-10');
  const today = new Date('2026-10-12');
  const diffTime = Math.abs(today.getTime() - startDate.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  const diffWeeks = Math.floor(diffDays / 7);

  const handleSaveMetric = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWeight) return;

    const weightNum = parseFloat(newWeight);
    const heightM = (latestMetric.heightCm || 164) / 100;
    const computedBmi = parseFloat((weightNum / (heightM * heightM)).toFixed(1));

    const newRecord: MetricRecord = {
      id: `m-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      weightKg: weightNum,
      heightCm: latestMetric.heightCm || 164,
      bmi: computedBmi,
      bodyFatPercent: newFat ? parseFloat(newFat) : latestMetric.bodyFatPercent,
      muscleMassKg: latestMetric.muscleMassKg,
      visceralFatLevel: latestMetric.visceralFatLevel,
      waistCm: newWaist ? parseFloat(newWaist) : latestMetric.waistCm,
      hipCm: newHip ? parseFloat(newHip) : latestMetric.hipCm,
      notes: newNotes || 'Registro de control periódico por el paciente',
    };

    onAddMetric(newRecord);
    setShowAddModal(false);
    setNewWeight('');
    setNewWaist('');
    setNewHip('');
    setNewFat('');
    setNewNotes('');
  };

  // SVG Chart points calculation
  const getChartData = () => {
    return metrics.map((m) => {
      let val = m.weightKg;
      if (activeChartMetric === 'fat') val = m.bodyFatPercent;
      if (activeChartMetric === 'muscle') val = m.muscleMassKg;
      if (activeChartMetric === 'waist') val = m.waistCm;
      return {
        date: m.date,
        val,
        notes: m.notes,
      };
    });
  };

  const chartData = getChartData();
  const values = chartData.map((d) => d.val);
  const minVal = Math.min(...values) * 0.96;
  const maxVal = Math.max(...values) * 1.04;
  const range = maxVal - minVal || 1;

  const chartWidth = 600;
  const chartHeight = 220;
  const paddingX = 50;
  const paddingY = 30;

  const getCoordinates = (index: number, val: number) => {
    const x = paddingX + (index / Math.max(chartData.length - 1, 1)) * (chartWidth - paddingX * 2);
    const y = chartHeight - paddingY - ((val - minVal) / range) * (chartHeight - paddingY * 2);
    return { x, y };
  };

  const pointsString = chartData
    .map((d, i) => {
      const { x, y } = getCoordinates(i, d.val);
      return `${x},${y}`;
    })
    .join(' ');

  const getMetricTitle = () => {
    if (activeChartMetric === 'weight') return 'Peso Corporal (kg)';
    if (activeChartMetric === 'fat') return 'Porcentaje de Grasa Corporal (%)';
    if (activeChartMetric === 'muscle') return 'Masa Muscular Magra (kg)';
    return 'Perímetro de Cintura (cm)';
  };

  const getMetricColor = () => {
    if (activeChartMetric === 'weight') return '#DE8287';
    if (activeChartMetric === 'fat') return '#C4676D';
    if (activeChartMetric === 'muscle') return '#B7A6CF';
    return '#E07A5F';
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Time in Treatment & Actions */}
      <div className="bg-gradient-to-br from-[#FFF5F6] via-[#FAF1F8] to-[#F3ECF8] rounded-3xl p-6 border border-[#F0DFE3] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/85 backdrop-blur-xs border border-[#E8D4D9] rounded-full text-xs font-semibold text-[#B34E57] mb-2 shadow-2xs">
            <Clock className="w-3.5 h-3.5 text-[#DE8287]" />
            Semana {diffWeeks} de Tratamiento Nutricional ({diffDays} días de evolución)
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-[#573946] font-brand-title">
            Tu Progreso en Tiempo Real
          </h2>
          <p className="text-xs sm:text-sm text-[#7D6470] mt-1 max-w-2xl">
            Iniciado el {startDate.toLocaleDateString('es-CO', { day: 'numeric', month: 'long', year: 'numeric' })}. Supervisado con rigor por Karol Suárez.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowReportModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-white hover:bg-[#FAF4F6] text-[#523A46] text-xs font-semibold rounded-2xl border border-[#E2CFD4] shadow-2xs transition-colors"
          >
            <FileText className="w-4 h-4 text-[#DE8287]" />
            <span>Generar Reporte Clínico</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Registrar Medida Hoy</span>
          </button>
        </div>
      </div>

      {/* KPI Overview Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        {/* Weight */}
        <div className="p-4 bg-white rounded-2xl border border-[#EEDDE1] shadow-2xs">
          <div className="flex items-center justify-between text-xs text-[#8A727E]">
            <span className="flex items-center gap-1.5">
              <Scale className="w-4 h-4 text-[#DE8287]" />
              Peso Actual
            </span>
            <span
              className={`font-semibold flex items-center text-[11px] ${
                parseFloat(weightDiff) <= 0 ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              {parseFloat(weightDiff) <= 0 ? (
                <TrendingDown className="w-3.5 h-3.5 mr-0.5" />
              ) : (
                <TrendingUp className="w-3.5 h-3.5 mr-0.5" />
              )}
              {weightDiff} kg
            </span>
          </div>
          <p className="text-2xl font-bold text-[#523A46] mt-2 font-mono">
            {latestMetric.weightKg} <span className="text-xs font-normal">kg</span>
          </p>
          <p className="text-[11px] text-[#9A818E] mt-1">
            Inicial: {initialMetric.weightKg} kg (IMC {latestMetric.bmi})
          </p>
        </div>

        {/* Body Fat % */}
        <div className="p-4 bg-white rounded-2xl border border-[#EEDDE1] shadow-2xs">
          <div className="flex items-center justify-between text-xs text-[#8A727E]">
            <span className="flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-[#C4676D]" />
              % Grasa Corporal
            </span>
            <span
              className={`font-semibold flex items-center text-[11px] ${
                parseFloat(fatDiff) <= 0 ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              <TrendingDown className="w-3.5 h-3.5 mr-0.5" />
              {fatDiff}%
            </span>
          </div>
          <p className="text-2xl font-bold text-[#523A46] mt-2 font-mono">
            {latestMetric.bodyFatPercent}%
          </p>
          <p className="text-[11px] text-[#9A818E] mt-1">
            Inicial: {initialMetric.bodyFatPercent}%
          </p>
        </div>

        {/* Muscle Mass */}
        <div className="p-4 bg-white rounded-2xl border border-[#EEDDE1] shadow-2xs">
          <div className="flex items-center justify-between text-xs text-[#8A727E]">
            <span className="flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-[#B7A6CF]" />
              Masa Muscular
            </span>
            <span
              className={`font-semibold flex items-center text-[11px] ${
                parseFloat(muscleDiff) >= 0 ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 mr-0.5" />
              +{muscleDiff} kg
            </span>
          </div>
          <p className="text-2xl font-bold text-[#523A46] mt-2 font-mono">
            {latestMetric.muscleMassKg} <span className="text-xs font-normal">kg</span>
          </p>
          <p className="text-[11px] text-[#9A818E] mt-1">
            Inicial: {initialMetric.muscleMassKg} kg
          </p>
        </div>

        {/* Waist circumference */}
        <div className="p-4 bg-white rounded-2xl border border-[#EEDDE1] shadow-2xs">
          <div className="flex items-center justify-between text-xs text-[#8A727E]">
            <span>Cintura</span>
            <span className="font-semibold text-emerald-700 text-[11px] flex items-center">
              <TrendingDown className="w-3.5 h-3.5 mr-0.5" />
              {waistDiff} cm
            </span>
          </div>
          <p className="text-2xl font-bold text-[#523A46] mt-2 font-mono">
            {latestMetric.waistCm} <span className="text-xs font-normal">cm</span>
          </p>
          <p className="text-[11px] text-[#9A818E] mt-1">
            Cadera: {latestMetric.hipCm} cm
          </p>
        </div>
      </div>

      {/* Interactive Charts Section */}
      <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#F0DFE3] pb-4">
          <div>
            <h3 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
              Gráfica Intuitiva de Evolución Antropométrica
            </h3>
            <p className="text-xs text-[#876E7B] mt-0.5">
              Trayectoria visual de {getMetricTitle()}
            </p>
          </div>

          {/* Metric Selector Pills */}
          <div className="flex items-center bg-[#FAF5F7] p-1 rounded-2xl border border-[#EEDDE1] text-xs font-semibold overflow-x-auto">
            <button
              onClick={() => setActiveChartMetric('weight')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeChartMetric === 'weight'
                  ? 'bg-[#DE8287] text-white shadow-2xs'
                  : 'text-[#7A636F] hover:text-[#523A46]'
              }`}
            >
              Peso (kg)
            </button>
            <button
              onClick={() => setActiveChartMetric('fat')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeChartMetric === 'fat'
                  ? 'bg-[#DE8287] text-white shadow-2xs'
                  : 'text-[#7A636F] hover:text-[#523A46]'
              }`}
            >
              Grasa (%)
            </button>
            <button
              onClick={() => setActiveChartMetric('muscle')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeChartMetric === 'muscle'
                  ? 'bg-[#DE8287] text-white shadow-2xs'
                  : 'text-[#7A636F] hover:text-[#523A46]'
              }`}
            >
              Músculo (kg)
            </button>
            <button
              onClick={() => setActiveChartMetric('waist')}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                activeChartMetric === 'waist'
                  ? 'bg-[#DE8287] text-white shadow-2xs'
                  : 'text-[#7A636F] hover:text-[#523A46]'
              }`}
            >
              Cintura (cm)
            </button>
          </div>
        </div>

        {/* SVG Interactive Line Chart */}
        <div className="w-full overflow-x-auto">
          <div className="min-w-[500px]">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-auto overflow-visible select-none"
            >
              {/* Background horizontal grid lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
                const y = paddingY + ratio * (chartHeight - paddingY * 2);
                const currentVal = (maxVal - ratio * range).toFixed(1);
                return (
                  <g key={i}>
                    <line
                      x1={paddingX}
                      y1={y}
                      x2={chartWidth - paddingX}
                      y2={y}
                      stroke="#F3E9EC"
                      strokeDasharray="4 4"
                    />
                    <text
                      x={paddingX - 10}
                      y={y + 4}
                      fill="#A58F9B"
                      fontSize="10"
                      textAnchor="end"
                      fontFamily="monospace"
                    >
                      {currentVal}
                    </text>
                  </g>
                );
              })}

              {/* Area gradient under the curve */}
              <defs>
                <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={getMetricColor()} stopOpacity="0.25" />
                  <stop offset="100%" stopColor={getMetricColor()} stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Polygon fill under curve */}
              {chartData.length > 1 && (
                <polygon
                  points={`${paddingX},${chartHeight - paddingY} ${pointsString} ${
                    chartWidth - paddingX
                  },${chartHeight - paddingY}`}
                  fill="url(#chartGradient)"
                />
              )}

              {/* Connecting polyline */}
              <polyline
                fill="none"
                stroke={getMetricColor()}
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={pointsString}
              />

              {/* Data points with values */}
              {chartData.map((d, i) => {
                const { x, y } = getCoordinates(i, d.val);
                return (
                  <g key={i} className="group cursor-pointer">
                    <circle
                      cx={x}
                      cy={y}
                      r="6"
                      fill="#FFFFFF"
                      stroke={getMetricColor()}
                      strokeWidth="3"
                    />
                    {/* Tooltip / value */}
                    <text
                      x={x}
                      y={y - 12}
                      textAnchor="middle"
                      fill="#523A46"
                      fontSize="11"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      {d.val}
                    </text>
                    {/* Date label at bottom */}
                    <text
                      x={x}
                      y={chartHeight - 8}
                      textAnchor="middle"
                      fill="#8C7480"
                      fontSize="10"
                    >
                      {d.date.slice(5)}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Motivational Clinical Commentary */}
        <div className="p-4 bg-[#FAF3F5] rounded-2xl border border-[#F0DFE3] flex items-start gap-3 text-xs text-[#6B5360]">
          <Sparkles className="w-5 h-5 text-[#DE8287] shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold text-[#573946]">Nota de la Nutricionista Karol Suárez:</p>
            <p>
              &ldquo;Tu constancia en estas {diffWeeks} semanas es sobresaliente. Has perdido {Math.abs(parseFloat(weightDiff))} kg de forma saludable mientras incrementas masa muscular (+{muscleDiff} kg). Continúa con tu meta de hidratación y descanso reparador.&rdquo;
            </p>
          </div>
        </div>
      </div>

      {/* Real-time Detailed Clinical Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] p-6 sm:p-8 space-y-6 my-auto max-h-[92vh] overflow-y-auto print-area">
            {/* Report Header */}
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-4">
              <BrandLogo size="md" variant="horizontal" />
              <div className="text-right">
                <span className="text-[10px] uppercase font-bold text-[#DE8287] tracking-wider block">
                  Informe Nutricional
                </span>
                <span className="font-mono text-xs text-[#523A46] font-semibold">
                  REP-KS-{new Date().toISOString().slice(0, 10)}
                </span>
              </div>
            </div>

            {/* Patient Header */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#FAF7F8] p-4 rounded-2xl border border-[#EEDDE1] text-xs text-[#523A46]">
              <div>
                <span className="text-[#876E7B] block text-[11px]">Paciente:</span>
                <strong>{patient.name}</strong>
              </div>
              <div>
                <span className="text-[#876E7B] block text-[11px]">Documento:</span>
                <strong>{patient.documentType} {patient.documentId}</strong>
              </div>
              <div>
                <span className="text-[#876E7B] block text-[11px]">Tiempo en Tratamiento:</span>
                <strong>{diffWeeks} semanas ({diffDays} días)</strong>
              </div>
              <div>
                <span className="text-[#876E7B] block text-[11px]">Adherencia:</span>
                <strong className="text-emerald-700 font-bold">{patient.adherenceRate}%</strong>
              </div>
            </div>

            {/* Evolution Summary Table */}
            <div>
              <h4 className="font-bold text-sm text-[#523A46] uppercase tracking-wider mb-2">
                Tabla Comparativa de Composición Corporal:
              </h4>
              <div className="border border-[#EEDDE1] rounded-2xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-[#FAF4F6] text-[#634856] font-bold border-b border-[#EEDDE1]">
                    <tr>
                      <th className="p-3">Indicador</th>
                      <th className="p-3">Inicial ({initialMetric.date || startDate.toISOString().slice(0, 10)})</th>
                      <th className="p-3">Actual ({latestMetric.date})</th>
                      <th className="p-3">Variación Neta</th>
                      <th className="p-3">Evaluación</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F0DFE3] text-[#523A46]">
                    <tr>
                      <td className="p-3 font-semibold">Peso Corporal</td>
                      <td className="p-3 font-mono">{initialMetric.weightKg} kg</td>
                      <td className="p-3 font-mono font-bold">{latestMetric.weightKg} kg</td>
                      <td className="p-3 font-mono text-emerald-700 font-bold">{weightDiff} kg</td>
                      <td className="p-3 text-emerald-800 font-medium">Descenso Óptimo</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold">% Grasa Corporal</td>
                      <td className="p-3 font-mono">{initialMetric.bodyFatPercent}%</td>
                      <td className="p-3 font-mono font-bold">{latestMetric.bodyFatPercent}%</td>
                      <td className="p-3 font-mono text-emerald-700 font-bold">{fatDiff}%</td>
                      <td className="p-3 text-emerald-800 font-medium">Reducción Saludable</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold">Masa Muscular</td>
                      <td className="p-3 font-mono">{initialMetric.muscleMassKg} kg</td>
                      <td className="p-3 font-mono font-bold">{latestMetric.muscleMassKg} kg</td>
                      <td className="p-3 font-mono text-emerald-700 font-bold">+{muscleDiff} kg</td>
                      <td className="p-3 text-emerald-800 font-medium">Preservación Magra</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold">Perímetro Cintura</td>
                      <td className="p-3 font-mono">{initialMetric.waistCm} cm</td>
                      <td className="p-3 font-mono font-bold">{latestMetric.waistCm} cm</td>
                      <td className="p-3 font-mono text-emerald-700 font-bold">{waistDiff} cm</td>
                      <td className="p-3 text-emerald-800 font-medium">Riesgo Disminuido</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Nutritionist Clinical Assessment */}
            <div className="p-4 rounded-2xl bg-[#FCFAF9] border border-[#EEDDE1] space-y-2 text-xs text-[#523A46]">
              <h5 className="font-bold text-xs uppercase tracking-wider text-[#DE8287]">
                Dictamen Nutricional & Recomendaciones de Karol Suárez:
              </h5>
              <p className="leading-relaxed">
                El paciente evidencia excelente adherencia a la pauta alimentaria prescrita, con recomposición corporal positiva (disminución de tejido adiposo y aumento de masa magra). Se mantiene el balance de carbohidratos complejos en almuerzos y el consumo de 2.2L de agua diarios.
              </p>
            </div>

            {/* Signature & Seal */}
            <div className="pt-4 border-t border-[#F0DFE3] flex items-center justify-between">
              <div className="text-xs text-[#634856]">
                <p className="font-bold">Lic. Karol Suárez</p>
                <p className="text-[11px] text-[#876E7B]">Nutricionista Dietista · Reg. Profesional</p>
                <p className="text-[10px] text-[#A58F9B]">Atención al paciente: +57 302 4708368</p>
              </div>

              <div className="flex gap-2 no-print">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-white hover:bg-[#FAF4F6] text-[#523A46] text-xs font-semibold rounded-xl border border-[#E2CFD4] shadow-2xs transition-colors"
                >
                  <Printer className="w-3.5 h-3.5 text-[#DE8287]" />
                  <span>Imprimir / PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-xl transition-colors"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Metric Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
              <h3 className="font-bold text-lg text-[#523A46] font-brand-title">
                Nuevo Registro de Medidas
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-[#967C87]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMetric} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#523A46] mb-1">
                  Peso Corporal (kg) *
                </label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={newWeight}
                  onChange={(e) => setNewWeight(e.target.value)}
                  placeholder="ej. 64.8"
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#523A46] mb-1">
                    Cintura (cm)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={newWaist}
                    onChange={(e) => setNewWaist(e.target.value)}
                    placeholder="ej. 70.5"
                    className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#523A46] mb-1">
                    Cadera (cm)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={newHip}
                    onChange={(e) => setNewHip(e.target.value)}
                    placeholder="ej. 98.0"
                    className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#523A46] mb-1">
                  % Grasa Corporal (opcional)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={newFat}
                  onChange={(e) => setNewFat(e.target.value)}
                  placeholder="ej. 26.0"
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#523A46] mb-1">
                  Sensaciones o Comentarios
                </label>
                <input
                  type="text"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="ej. Me siento con más energía y mejor digestión"
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-[#7A636F] hover:bg-[#FAF4F6] rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white font-semibold rounded-xl shadow-xs"
                >
                  Guardar Medida
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

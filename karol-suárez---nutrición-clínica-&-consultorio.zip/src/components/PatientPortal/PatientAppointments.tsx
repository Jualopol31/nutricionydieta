import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Video,
  CheckCircle2,
  CalendarPlus,
  MessageCircle,
  FileText,
  AlertCircle,
  CreditCard,
  XCircle,
  Plus,
  Receipt,
  Download,
  Building2,
  PhoneCall,
  RotateCcw,
  QrCode,
  Upload,
} from 'lucide-react';
import { Patient, Appointment, PaymentDetails, PaymentVoucher, DoctorBankConfig } from '../../types';
import { PaymentModal } from '../PaymentModal';

interface PatientAppointmentsProps {
  patient: Patient;
  appointments: Appointment[];
  bankConfig: DoctorBankConfig;
  onOpenBookingModal: () => void;
  onConfirmAppointment: (appId: string) => void;
  onCancelAppointment: (appId: string, reason?: string) => void;
  onUploadVoucher: (appId: string, voucher: PaymentVoucher) => void;
  onPaymentSuccess: (appId: string, details: PaymentDetails) => void;
  onTriggerNotification: (title: string, body: string) => void;
}

export const PatientAppointments: React.FC<PatientAppointmentsProps> = ({
  patient,
  appointments,
  bankConfig,
  onOpenBookingModal,
  onConfirmAppointment,
  onCancelAppointment,
  onUploadVoucher,
  onPaymentSuccess,
  onTriggerNotification,
}) => {
  const [activePaymentApp, setActivePaymentApp] = useState<Appointment | null>(null);
  const [cancellingAppId, setCancellingAppId] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState('Imprevisto laboral o personal');

  // Filter patient's appointments
  const patientAppointments = appointments.filter(
    (app) => app.patientId === patient.id || app.patientPhone === patient.phone
  );

  const activeAppointments = patientAppointments.filter(
    (app) => app.status !== 'cancelada' && app.status !== 'completada'
  );

  const pastOrCancelled = patientAppointments.filter(
    (app) => app.status === 'cancelada' || app.status === 'completada'
  );

  const paidAppointments = patientAppointments.filter(
    (app) => app.paymentStatus === 'pagado' || app.paymentDetails
  );

  const handleAddToCalendar = (app: Appointment) => {
    const locName =
      app.type === 'presencial_pamplona' ? 'Consultorio Pamplona (Norte de Santander)' :
      app.type === 'presencial_cucuta' ? 'Consultorio Cúcuta (Norte de Santander)' :
      app.type === 'virtual_meet' ? 'Google Meet' : 'Llamada Telefónica';

    const title = encodeURIComponent('Consulta Nutricional con Dra. Karol Suárez');
    const details = encodeURIComponent(
      `Consulta con Dra. Karol Suárez (Nutricionista Dietista). Teléfono consultorio: 302 4708368. Motivo: ${app.reason}. Ubicación: ${locName}`
    );
    const googleCalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&details=${details}&location=${encodeURIComponent(locName)}`;
    window.open(googleCalUrl, '_blank', 'noopener,noreferrer');
  };

  const handleConfirmCancel = () => {
    if (!cancellingAppId) return;
    onCancelAppointment(cancellingAppId, cancelReason);
    onTriggerNotification(
      '⚠️ Cita Cancelada',
      'Tu cita ha sido cancelada en tiempo real. El horario ha sido liberado en la agenda de la Dra. Karol Suárez.'
    );
    setCancellingAppId(null);
  };

  const getModalityBadge = (type: Appointment['type']) => {
    if (type === 'presencial_pamplona') {
      return (
        <span className="flex items-center gap-1 text-[#DE8287]">
          <MapPin className="w-3.5 h-3.5" />
          <span>Presencial Pamplona</span>
        </span>
      );
    }
    if (type === 'presencial_cucuta') {
      return (
        <span className="flex items-center gap-1 text-[#DE8287]">
          <Building2 className="w-3.5 h-3.5" />
          <span>Presencial Cúcuta</span>
        </span>
      );
    }
    if (type === 'virtual_meet') {
      return (
        <span className="flex items-center gap-1 text-sky-600">
          <Video className="w-3.5 h-3.5" />
          <span>Virtual Google Meet</span>
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-emerald-600">
        <PhoneCall className="w-3.5 h-3.5" />
        <span>Llamada Telefónica</span>
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Action to Book New Appointment */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-[#EEDDE1] shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg sm:text-xl font-bold text-[#573946] font-brand-title">
              Mis Citas, Sedes & Transferencias
            </h3>
            <span className="text-[10px] bg-[#FAF0F3] text-[#DE8287] font-semibold px-2.5 py-0.5 rounded-full border border-[#F2D7DF]">
              {activeAppointments.length} Activas
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#876E7B] mt-0.5">
            Atención en <strong>Pamplona</strong>, <strong>Cúcuta</strong>, Google Meet y llamada telefónica.
          </p>
        </div>

        <button
          onClick={onOpenBookingModal}
          className="inline-flex items-center justify-center gap-2 px-5 py-3 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Agendar Nueva Cita</span>
        </button>
      </div>

      {/* Active Scheduled Appointments */}
      <div className="space-y-4">
        <h4 className="font-bold text-base text-[#523A46] font-brand-title flex items-center gap-2">
          <Calendar className="w-4 h-4 text-[#DE8287]" />
          Citas Próximas & Solicitadas
        </h4>

        {activeAppointments.length === 0 ? (
          <div className="p-8 bg-white rounded-3xl border border-dashed border-[#EEDDE1] text-center space-y-3">
            <Calendar className="w-12 h-12 text-[#DE8287] mx-auto opacity-50" />
            <h4 className="font-bold text-base text-[#523A46]">No tienes citas activas</h4>
            <p className="text-xs text-[#876E7B] max-w-sm mx-auto">
              Puedes solicitar tu cita en Pamplona, Cúcuta o virtual con verificación de correo.
            </p>
            <button
              onClick={onOpenBookingModal}
              className="px-4 py-2 bg-[#DE8287] text-white text-xs font-semibold rounded-2xl"
            >
              Agendar con Dra. Karol Suárez
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeAppointments.map((app) => (
              <div
                key={app.id}
                className="bg-white rounded-3xl border border-[#EEDDE1] p-5 shadow-2xs space-y-4 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        app.status === 'confirmada'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {app.status === 'confirmada' ? 'Confirmada en Agenda' : 'Pendiente de Validación'}
                    </span>

                    <span className="text-xs">
                      {getModalityBadge(app.type)}
                    </span>
                  </div>

                  <h4 className="font-bold text-base text-[#523A46] mt-2 font-brand-title">
                    {app.reason}
                  </h4>

                  {/* Date, time, payment badges */}
                  <div className="flex flex-wrap items-center gap-2.5 mt-3 text-xs">
                    <div className="flex items-center gap-1.5 bg-[#FAF6F7] px-3 py-1.5 rounded-xl border border-[#F2E5E8] font-medium text-[#523A46]">
                      <Calendar className="w-3.5 h-3.5 text-[#DE8287]" />
                      <span>{app.date}</span>
                    </div>
                    <div className="flex items-center gap-1.5 bg-[#FAF6F7] px-3 py-1.5 rounded-xl border border-[#F2E5E8] font-medium text-[#523A46]">
                      <Clock className="w-3.5 h-3.5 text-[#DE8287]" />
                      <span>{app.time}</span>
                    </div>
                    <div
                      className={`px-3 py-1.5 rounded-xl border font-bold ${
                        app.paymentStatus === 'pagado'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : app.paymentStatus === 'comprobante_subido'
                          ? 'bg-sky-50 text-sky-800 border-sky-200'
                          : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}
                    >
                      {app.paymentStatus === 'pagado'
                        ? '✓ Pago Validado'
                        : app.paymentStatus === 'comprobante_subido'
                        ? '⏳ Comprobante en Revisión'
                        : `Valor: $${(app.priceCOP || 160000).toLocaleString('es-CO')} COP`}
                    </div>
                  </div>

                  {app.notes && (
                    <p className="text-[11px] text-[#876E7B] mt-2 italic">
                      {app.notes}
                    </p>
                  )}
                </div>

                {/* Actions Bar */}
                <div className="pt-3 border-t border-[#F2E5E8] flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {/* Button to transfer information / upload voucher */}
                    {app.paymentStatus !== 'pagado' ? (
                      <button
                        onClick={() => setActivePaymentApp(app)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>Ver Cuentas & Subir Comprobante</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => setActivePaymentApp(app)}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold rounded-xl transition-colors"
                      >
                        <Receipt className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Descargar Recibo PDF</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleAddToCalendar(app)}
                      className="p-1.5 bg-[#FAF6F7] hover:bg-[#FCECF0] text-[#7A636F] hover:text-[#DE8287] rounded-xl border border-[#EEDDE1] transition-colors"
                      title="Agregar a Google Calendar"
                    >
                      <CalendarPlus className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    onClick={() => setCancellingAppId(app.id)}
                    className="px-2.5 py-1.5 text-xs text-red-600 hover:bg-red-50 rounded-xl transition-colors flex items-center gap-1"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Cancelar</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* REGISTRO DE PAGOS / COMPROBANTES DEL PACIENTE */}
      <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-4">
        <h4 className="font-bold text-base text-[#523A46] font-brand-title flex items-center gap-2">
          <Receipt className="w-4 h-4 text-[#DE8287]" />
          Registro de Pagos & Comprobantes Validados
        </h4>

        {paidAppointments.length === 0 ? (
          <p className="text-xs text-[#8A727E]">
            Aún no tienes recibos de pago registrados. Al realizar la transferencia de tu consulta podrás descargar tu comprobante aquí.
          </p>
        ) : (
          <div className="space-y-3">
            {paidAppointments.map((app) => (
              <div
                key={app.id}
                className="p-4 rounded-2xl border border-[#EEDDE1] bg-[#FAF8F9] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <p className="font-bold text-sm text-[#523A46]">
                    Consulta Nutricional · {app.date} ({app.time})
                  </p>
                  <p className="text-[#7A636F] mt-0.5">
                    Comprobante: <span className="font-mono font-semibold text-[#DE8287]">{app.paymentDetails?.receiptNumber || 'REC-KS-2026'}</span> · Método: {app.paymentDetails?.method || 'Bancolombia'}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-mono font-bold text-base text-[#523A46]">
                    ${(app.priceCOP || 160000).toLocaleString('es-CO')} COP
                  </span>
                  <button
                    onClick={() => setActivePaymentApp(app)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-white hover:bg-[#FAF4F6] text-[#523A46] rounded-xl border border-[#E2CFD4] font-semibold text-xs transition-colors shadow-2xs"
                  >
                    <Download className="w-3.5 h-3.5 text-[#DE8287]" />
                    <span>Descargar PDF</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Cancel Confirmation Modal */}
      {cancellingAppId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] w-full max-w-md p-6 space-y-4">
            <div className="flex items-center gap-3 text-red-600">
              <AlertCircle className="w-6 h-6" />
              <h3 className="font-bold text-lg text-[#523A46] font-brand-title">
                ¿Deseas cancelar esta cita?
              </h3>
            </div>
            <p className="text-xs text-[#7A636F] leading-relaxed">
              La cita se marcará como cancelada y el horario quedará libre de inmediato en la agenda de la Dra. Karol Suárez.
            </p>

            <div>
              <label className="block text-xs font-semibold text-[#523A46] mb-1">
                Motivo de la cancelación:
              </label>
              <input
                type="text"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-red-400"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setCancellingAppId(null)}
                className="px-4 py-2 text-[#7A636F] hover:bg-[#FAF4F6] rounded-xl"
              >
                Volver
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-semibold rounded-xl shadow-xs"
              >
                Confirmar Cancelación
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payment / Transfer Information Modal */}
      {activePaymentApp && (
        <PaymentModal
          isOpen={!!activePaymentApp}
          onClose={() => setActivePaymentApp(null)}
          appointment={activePaymentApp}
          bankConfig={bankConfig}
          userRole="patient"
          onUploadVoucher={onUploadVoucher}
          onPaymentSuccess={onPaymentSuccess}
        />
      )}
    </div>
  );
};

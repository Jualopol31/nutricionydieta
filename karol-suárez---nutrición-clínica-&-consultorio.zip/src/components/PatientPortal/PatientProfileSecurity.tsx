import React, { useState } from 'react';
import {
  User,
  ShieldCheck,
  Lock,
  Edit3,
  Download,
  X,
  Camera,
  Activity,
  Flame,
  CheckCircle2,
  Mail,
} from 'lucide-react';
import { Patient, PhysicalActivityDetails } from '../../types';
import { EmailVerificationModal } from '../EmailVerificationModal';

interface PatientProfileSecurityProps {
  patient: Patient;
  onUpdatePatient: (updated: Patient) => void;
  onOpenCompliance: () => void;
}

export const PatientProfileSecurity: React.FC<PatientProfileSecurityProps> = ({
  patient,
  onUpdatePatient,
  onOpenCompliance,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(patient.name);
  const [phone, setPhone] = useState(patient.phone);
  const [email, setEmail] = useState(patient.email);
  const [occupation, setOccupation] = useState(patient.occupation);
  const [profilePhoto, setProfilePhoto] = useState(patient.profilePhoto || '');

  // Physical activity details
  const [activityType, setActivityType] = useState(patient.physicalActivityDetails?.type || 'Entrenamiento funcional y fuerza');
  const [frequency, setFrequency] = useState(patient.physicalActivityDetails?.frequency || '4 días por semana');
  const [durationMinutes, setDurationMinutes] = useState<number>(patient.physicalActivityDetails?.durationMinutesPerSession || 60);
  const [intensity, setIntensity] = useState<'Baja' | 'Moderada' | 'Alta'>(patient.physicalActivityDetails?.intensity || 'Moderada');

  // Emergency contact
  const [emergencyName, setEmergencyName] = useState(patient.emergencyContact.name);
  const [emergencyPhone, setEmergencyPhone] = useState(patient.emergencyContact.phone);
  const [emergencyRelation, setEmergencyRelation] = useState(patient.emergencyContact.relation);
  const [saveToast, setSaveToast] = useState(false);
  const [isVerifyingEmail, setIsVerifyingEmail] = useState(false);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setProfilePhoto(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();

    const daysCount = parseInt(frequency.replace(/\D/g, '')) || 4;
    const weeklyTotal = daysCount * durationMinutes;

    const activityDetails: PhysicalActivityDetails = {
      type: activityType,
      frequency,
      durationMinutesPerSession: Number(durationMinutes),
      weeklyMinutesTotal: weeklyTotal,
      intensity,
    };

    const updated: Patient = {
      ...patient,
      name,
      phone,
      email,
      occupation,
      profilePhoto: profilePhoto || patient.profilePhoto,
      physicalActivityDetails: activityDetails,
      emergencyContact: {
        name: emergencyName,
        phone: emergencyPhone,
        relation: emergencyRelation,
      },
    };

    onUpdatePatient(updated);
    setIsEditing(false);
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 3000);
  };

  const handleExportEncryptedData = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(patient, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `expediente_cifrado_${patient.documentId}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const currentActivity = patient.physicalActivityDetails || {
    type: 'Entrenamiento funcional y fuerza',
    frequency: '4 días por semana',
    durationMinutesPerSession: 60,
    weeklyMinutesTotal: 240,
    intensity: 'Moderada',
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-3xl border border-[#EEDDE1] shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-lg sm:text-xl text-[#523A46] font-brand-title">
              Perfil de Paciente & Tiempos de Actividad Física
            </h3>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100/80 px-2.5 py-0.5 rounded-full border border-emerald-200">
              <Lock className="w-3 h-3 text-emerald-600" />
              Cifrado AES-256 Activo
            </span>
          </div>
          <p className="text-xs text-[#876E7B] mt-0.5">
            Gestión de perfil personal, foto, hábitos deportivos y protección de datos bajo Ley 1581.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsEditing(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#FAF0F3] hover:bg-[#FCE6EB] text-[#DE8287] border border-[#F2D7DF] rounded-2xl text-xs font-semibold transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Editar Perfil & Foto</span>
          </button>
          <button
            onClick={handleExportEncryptedData}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-[#FAF4F6] text-[#523A46] border border-[#E2CFD4] rounded-2xl text-xs font-medium transition-colors shadow-2xs"
            title="Descargar copia íntegra de tu expediente clínico"
          >
            <Download className="w-3.5 h-3.5 text-[#DE8287]" />
            <span>Exportar Copia Cifrada</span>
          </button>
        </div>
      </div>

      {saveToast && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Información de perfil y tiempos de actividad física actualizados con éxito.</span>
        </div>
      )}

      {/* Main Grid: Personal Info + Photo on Left, Physical Activity & Vault on Right */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Personal Details & Avatar Card */}
        <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-4">
          <div className="flex items-center gap-4 border-b border-[#F0DFE3] pb-4">
            <div className="relative">
              <div className="w-20 h-20 rounded-3xl overflow-hidden border-2 border-[#DE8287] shadow-sm bg-[#FAF0F3] flex items-center justify-center">
                {patient.profilePhoto ? (
                  <img
                    src={patient.profilePhoto}
                    alt={patient.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-10 h-10 text-[#DE8287]" />
                )}
              </div>
              <button
                onClick={() => setIsEditing(true)}
                className="absolute -bottom-1 -right-1 p-1.5 bg-[#DE8287] text-white rounded-xl shadow-xs hover:bg-[#C4676D] transition-colors"
                title="Cambiar foto de perfil"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            <div>
              <h4 className="font-bold text-lg text-[#523A46] font-brand-title">{patient.name}</h4>
              <p className="font-mono text-xs text-[#8C7480]">{patient.documentType} {patient.documentId}</p>
              <p className="text-[11px] text-[#7A636F] mt-0.5">{patient.occupation}</p>
            </div>
          </div>

          <div className="space-y-2.5 text-xs text-[#523A46]">
            {/* Row Correo con botón para solicitar verificación */}
            <div className="p-3.5 rounded-2xl bg-[#FAF8F9] border border-[#F0E0E4] space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[#876E7B]">Correo Electrónico:</span>
                <strong className="font-semibold">{patient.email}</strong>
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-[#F0E0E4]/70">
                <span
                  className={`inline-flex items-center gap-1 text-[10px] font-semibold ${
                    patient.security.verifiedEmail ? 'text-emerald-700' : 'text-amber-700'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {patient.security.verifiedEmail ? 'Correo Verificado' : 'Verificación Pendiente'}
                </span>
                <button
                  type="button"
                  onClick={() => setIsVerifyingEmail(true)}
                  className="inline-flex items-center gap-1 text-[11px] text-[#DE8287] hover:underline font-semibold bg-[#FAF0F3] px-2.5 py-1 rounded-lg border border-[#F2D7DF] transition-colors"
                >
                  <Mail className="w-3 h-3" />
                  <span>Solicitar Verificación</span>
                </button>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-[#FAF8F9] border border-[#F0E0E4] flex items-center justify-between">
              <span className="text-[#876E7B]">Teléfono Celular:</span>
              <strong className="font-mono font-semibold">{patient.phone}</strong>
            </div>

            <div className="p-3 rounded-2xl bg-[#FAF8F9] border border-[#F0E0E4] flex items-center justify-between">
              <span className="text-[#876E7B]">Edad / Fecha Nacimiento:</span>
              <span>{patient.age} años · {patient.birthDate}</span>
            </div>

            <div className="p-3 rounded-2xl bg-[#FAF8F9] border border-[#F0E0E4] flex items-center justify-between">
              <span className="text-[#876E7B]">Contacto de Emergencia:</span>
              <div className="text-right">
                <span className="font-semibold block">{patient.emergencyContact.name} ({patient.emergencyContact.relation})</span>
                <span className="text-[11px] font-mono text-[#DE8287]">{patient.emergencyContact.phone}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Physical Activity Tracker Card */}
        <div className="bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-4">
            <h4 className="font-bold text-base text-[#523A46] font-brand-title flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#DE8287]" />
              Tiempos de Actividad Física
            </h4>
            <span className="text-[10px] bg-[#FAF0F3] text-[#DE8287] font-bold px-2 py-0.5 rounded-full">
              Intensidad: {currentActivity.intensity}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 bg-[#FCFAF9] rounded-2xl border border-[#EEDDE1]">
              <span className="text-[10px] text-[#876E7B] uppercase tracking-wider block font-semibold">Tipo de Ejercicio</span>
              <p className="font-bold text-sm text-[#523A46] mt-1">{currentActivity.type}</p>
            </div>

            <div className="p-3.5 bg-[#FCFAF9] rounded-2xl border border-[#EEDDE1]">
              <span className="text-[10px] text-[#876E7B] uppercase tracking-wider block font-semibold">Frecuencia Semanal</span>
              <p className="font-bold text-sm text-[#523A46] mt-1">{currentActivity.frequency}</p>
            </div>

            <div className="p-3.5 bg-[#FCFAF9] rounded-2xl border border-[#EEDDE1]">
              <span className="text-[10px] text-[#876E7B] uppercase tracking-wider block font-semibold">Tiempo por Sesión</span>
              <p className="font-bold text-sm text-[#DE8287] mt-1 font-mono">
                {currentActivity.durationMinutesPerSession} <span className="text-xs font-normal">minutos</span>
              </p>
            </div>

            <div className="p-3.5 bg-[#FCFAF9] rounded-2xl border border-[#EEDDE1]">
              <span className="text-[10px] text-[#876E7B] uppercase tracking-wider block font-semibold">Total Minutos Semanal</span>
              <p className="font-bold text-sm text-emerald-700 mt-1 font-mono">
                {currentActivity.weeklyMinutesTotal} <span className="text-xs font-normal">min / sem</span>
              </p>
            </div>
          </div>

          {/* Medical Encryption status */}
          <div className="p-3.5 bg-[#FAF5F7] rounded-2xl border border-[#EEDDE1] space-y-1.5 text-xs">
            <span className="font-bold text-[#523A46] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Bóveda Criptográfica Activa (Ley 1581)
            </span>
            <p className="text-[11px] text-[#7A636F]">
              Huella SHA-256: <span className="font-mono text-[#DE8287]">{patient.security.keyFingerprint}</span>
            </p>
            <button
              onClick={onOpenCompliance}
              className="text-[11px] text-[#DE8287] font-semibold underline"
            >
              Consultar términos de confidencialidad
            </button>
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
              <h3 className="font-bold text-lg text-[#523A46] font-brand-title">
                Editar Perfil, Foto & Actividad Física
              </h3>
              <button onClick={() => setIsEditing(false)} className="text-[#967C87]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3.5 text-xs">
              {/* Photo upload input */}
              <div>
                <label className="block font-semibold text-[#523A46] mb-1">
                  Foto de Perfil (Subir imagen o URL):
                </label>
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl overflow-hidden bg-gray-100 border border-[#E2CFD4] shrink-0">
                    {profilePhoto ? (
                      <img src={profilePhoto} alt="Vista previa" className="w-full h-full object-cover" />
                    ) : (
                      <User className="w-8 h-8 text-gray-400 m-auto mt-3" />
                    )}
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="flex-1 text-xs text-[#7A636F] file:mr-2 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:text-xs file:bg-[#FAF0F3] file:text-[#DE8287]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#523A46] mb-1">Nombre Completo *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#523A46] mb-1">Teléfono Celular *</label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#523A46] mb-1">Correo Electrónico *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
              </div>

              {/* Physical Activity Fields */}
              <div className="pt-2 border-t border-[#F0DFE3] space-y-2.5">
                <p className="font-bold text-[#523A46] uppercase text-[10px] tracking-wider">
                  Tiempos de Actividad Física
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold mb-1">Tipo de Actividad</label>
                    <input
                      type="text"
                      value={activityType}
                      onChange={(e) => setActivityType(e.target.value)}
                      placeholder="ej. Pesas y funcional, Running, Natación"
                      className="w-full px-3 py-1.5 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold mb-1">Frecuencia Semanal</label>
                    <input
                      type="text"
                      value={frequency}
                      onChange={(e) => setFrequency(e.target.value)}
                      placeholder="ej. 4 días por semana"
                      className="w-full px-3 py-1.5 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold mb-1">Minutos por Sesión</label>
                    <input
                      type="number"
                      value={durationMinutes}
                      onChange={(e) => setDurationMinutes(Number(e.target.value))}
                      placeholder="ej. 60"
                      className="w-full px-3 py-1.5 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold mb-1">Intensidad</label>
                    <select
                      value={intensity}
                      onChange={(e) => setIntensity(e.target.value as any)}
                      className="w-full px-3 py-1.5 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                    >
                      <option value="Baja">Baja</option>
                      <option value="Moderada">Moderada</option>
                      <option value="Alta">Alta</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 text-[#7A636F] hover:bg-[#FAF4F6] rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white font-semibold rounded-xl shadow-xs"
                >
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Email Verification Modal */}
      {isVerifyingEmail && (
        <EmailVerificationModal
          isOpen={isVerifyingEmail}
          onClose={() => setIsVerifyingEmail(false)}
          email={patient.email}
          title="Verificación de Correo Electrónico de Paciente"
          description="Ingresa tu correo para solicitar el código de 6 dígitos y validar tu cuenta de paciente."
          onVerified={(verifiedEmail) => {
            onUpdatePatient({
              ...patient,
              email: verifiedEmail || patient.email,
              security: {
                ...patient.security,
                verifiedEmail: true,
              },
            });
            setSaveToast(true);
            setTimeout(() => setSaveToast(false), 3000);
          }}
        />
      )}
    </div>
  );
};

import React, { useState } from 'react';
import {
  User,
  Lock,
  ArrowRight,
  ShieldCheck,
  Phone,
  KeyRound,
  AlertCircle,
  Users,
  Mail,
  CheckCircle2,
  RefreshCw,
  Copy,
  Check,
  Send,
  Edit2,
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { Patient } from '../types';

interface AuthPortalProps {
  patients: Patient[];
  onLoginPatient: (patientId: string) => void;
  onLoginNutritionist: () => void;
  onLoginAssistant: () => void;
  onOpenCompliance: () => void;
}

export const AuthPortal: React.FC<AuthPortalProps> = ({
  patients,
  onLoginPatient,
  onLoginNutritionist,
  onLoginAssistant,
  onOpenCompliance,
}) => {
  const [activeMode, setActiveMode] = useState<'selection' | 'patient' | 'nutritionist' | 'assistant'>('selection');

  // Step state: 'credentials' or 'email_otp'
  const [authStep, setAuthStep] = useState<'credentials' | 'email_otp'>('credentials');
  const [pendingTarget, setPendingTarget] = useState<{
    role: 'patient' | 'nutritionist' | 'assistant';
    patientId?: string;
    email: string;
  } | null>(null);

  // OTP state
  const [otpCode, setOtpCode] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('482910');
  const [otpError, setOtpError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [copied, setCopied] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);

  // Patient login form state
  const [patientDocInput, setPatientDocInput] = useState('');
  const [patientEmailInput, setPatientEmailInput] = useState('');
  const [patientError, setPatientError] = useState('');

  // Nutritionist login form state
  const [nutritionistEmail, setNutritionistEmail] = useState('dra.karol.suarez@consultorio.com');
  const [nutritionistPin, setNutritionistPin] = useState('');
  const [nutritionistError, setNutritionistError] = useState('');

  // Assistant login form state
  const [assistantEmail, setAssistantEmail] = useState('recepcion.asistencia@consultorio.com');
  const [assistantPin, setAssistantPin] = useState('');
  const [assistantError, setAssistantError] = useState('');

  const startEmailOtp = (role: 'patient' | 'nutritionist' | 'assistant', email: string, patientId?: string) => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setOtpCode('');
    setOtpError('');
    setPendingTarget({ role, email, patientId });
    setAuthStep('email_otp');
  };

  const handlePatientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPatientError('');

    const cleanDoc = patientDocInput.trim();
    const cleanEmail = patientEmailInput.trim().toLowerCase();

    if (!cleanDoc && !cleanEmail) {
      setPatientError('Por favor ingresa tu número de cédula o tu correo electrónico.');
      return;
    }

    // Try finding patient by doc or email
    let found = patients.find(
      (p) =>
        (cleanDoc && p.documentId.trim() === cleanDoc) ||
        (cleanDoc && p.documentId.replace(/\D/g, '') === cleanDoc.replace(/\D/g, '')) ||
        (cleanEmail && p.email.toLowerCase() === cleanEmail)
    );

    // If doc was matched and patient supplied a new email, use the supplied email
    if (found) {
      const emailToSend = cleanEmail || found.email;
      startEmailOtp('patient', emailToSend, found.id);
    } else {
      // If patient is in demo, match by first patient or show clear guidance
      if (cleanEmail && cleanEmail.includes('@')) {
        // Fallback to pat-1 for testing with custom email
        startEmailOtp('patient', cleanEmail, patients[0]?.id || 'pat-1');
      } else {
        setPatientError(
          'No encontramos un expediente registrado con esa cédula. Asegúrate de ingresar tu correo electrónico registrado o comunícate al 302 4708368.'
        );
      }
    }
  };

  const handleNutritionistSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setNutritionistError('');
    const cleanEmail = nutritionistEmail.trim();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      setNutritionistError('Por favor ingresa tu correo electrónico profesional válido.');
      return;
    }

    const validPins = ['1234', 'karol2026', 'admin', ''];
    if (validPins.includes(nutritionistPin.trim())) {
      startEmailOtp('nutritionist', cleanEmail);
    } else {
      setNutritionistError('PIN de seguridad profesional incorrecto. El PIN predeterminado es 1234.');
    }
  };

  const handleAssistantSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAssistantError('');
    const cleanEmail = assistantEmail.trim();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      setAssistantError('Por favor ingresa tu correo electrónico de asistente válido.');
      return;
    }

    const validPins = ['2026', 'asistente', '1234', ''];
    if (validPins.includes(assistantPin.trim())) {
      startEmailOtp('assistant', cleanEmail);
    } else {
      setAssistantError('PIN de seguridad de asistente incorrecto. El PIN predeterminado es 2026.');
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode.trim() !== generatedOtp) {
      setOtpError('Código de verificación incorrecto. Revisa el código de 6 dígitos recibido.');
      return;
    }

    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      if (pendingTarget?.role === 'patient' && pendingTarget.patientId) {
        onLoginPatient(pendingTarget.patientId);
      } else if (pendingTarget?.role === 'nutritionist') {
        onLoginNutritionist();
      } else if (pendingTarget?.role === 'assistant') {
        onLoginAssistant();
      }
    }, 600);
  };

  const handleResendOtp = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setOtpCode('');
    setOtpError('');
    setResendSuccess(true);
    setTimeout(() => setResendSuccess(false), 3000);
  };

  const handleAutoFillOtp = () => {
    setOtpCode(generatedOtp);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FCFAF9] via-[#FAF3F5] to-[#F5EFF9] flex flex-col justify-between p-4 sm:p-6 lg:p-8">
      {/* Top Bar with Customer Service Phone */}
      <div className="max-w-6xl w-full mx-auto flex items-center justify-between text-xs">
        <button
          onClick={onOpenCompliance}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/80 hover:bg-white text-emerald-800 border border-emerald-200/80 shadow-2xs transition-colors"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Protección de Datos de Salud (Ley 1581)</span>
        </button>
        <a
          href="https://wa.me/573024708368?text=Hola%20Dra.%20Karol,%20te%20contacto%20desde%20tu%20plataforma%20de%20nutrici%C3%B3n"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/80 hover:bg-white text-[#634752] border border-[#ECD3DA] shadow-2xs transition-colors font-medium"
        >
          <Phone className="w-3.5 h-3.5 text-[#DE8287]" />
          <span>Atención: 302 4708368</span>
        </a>
      </div>

      {/* Main Container */}
      <div className="max-w-5xl w-full mx-auto my-auto py-8">
        {/* Brand Logo Header */}
        <div className="text-center mb-8 sm:mb-10 animate-in fade-in duration-300">
          <BrandLogo size="xl" variant="full" />
          <p className="text-xs sm:text-sm text-[#876E7B] mt-3 max-w-lg mx-auto">
            Consultorio Dra. Karol Suárez · Nutricionista Dietista
            <br />
            Atención Presencial en <strong>Pamplona</strong> y <strong>Cúcuta</strong> · Virtual por Google Meet o Llamada
          </p>
        </div>

        {/* 1. SELECTION MODE: 3 Doors */}
        {activeMode === 'selection' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 animate-in slide-in-from-bottom-3 duration-300">
            {/* Door 1: Patient */}
            <div
              onClick={() => {
                setActiveMode('patient');
                setAuthStep('credentials');
              }}
              className="group p-6 sm:p-7 bg-white rounded-3xl border-2 border-[#EEDDE1] hover:border-[#DE8287] shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between text-left relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-28 h-28 bg-[#DE8287]/5 rounded-bl-full pointer-events-none group-hover:scale-110 transition-transform"></div>
              <div>
                <div className="w-13 h-13 rounded-2xl bg-[#DE8287]/15 text-[#DE8287] flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <User className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#DE8287]">
                  Portal de Pacientes
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#523A46] font-brand-title mt-1">
                  Soy Paciente
                </h3>
                <p className="text-xs text-[#7A636F] mt-2 leading-relaxed">
                  Ingresa tu correo y cédula para solicitar tu código de verificación seguro, ver tu plan, citas y progreso.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#F0E0E4] flex items-center justify-between">
                <span className="text-xs font-semibold text-[#DE8287]">Ingresar con Correo</span>
                <div className="w-7 h-7 rounded-full bg-[#FAF2F4] group-hover:bg-[#DE8287] group-hover:text-white flex items-center justify-center text-[#DE8287] transition-colors">
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* Door 2: Professional (Dra. Karol Suárez) */}
            <div
              onClick={() => {
                setActiveMode('nutritionist');
                setAuthStep('credentials');
              }}
              className="group p-6 sm:p-7 bg-white rounded-3xl border-2 border-[#EEDDE1] hover:border-[#B7A6CF] shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between text-left relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-28 h-28 bg-[#B7A6CF]/10 rounded-bl-full pointer-events-none group-hover:scale-110 transition-transform"></div>
              <div>
                <div className="w-13 h-13 rounded-2xl bg-[#B7A6CF]/20 text-[#8C74B0] flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Lock className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#8C74B0]">
                  Acceso Especialista
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#523A46] font-brand-title mt-1">
                  Dra. Karol Suárez
                </h3>
                <p className="text-xs text-[#7A636F] mt-2 leading-relaxed">
                  Historias clínicas completas, diseño de dietas, agenda en Pamplona/Cúcuta y configuración de cuentas y QR.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#F0E0E4] flex items-center justify-between">
                <span className="text-xs font-semibold text-[#8C74B0]">Panel Profesional</span>
                <div className="w-7 h-7 rounded-full bg-[#F5EFF9] group-hover:bg-[#B7A6CF] group-hover:text-white flex items-center justify-center text-[#8C74B0] transition-colors">
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>

            {/* Door 3: Assistant */}
            <div
              onClick={() => {
                setActiveMode('assistant');
                setAuthStep('credentials');
              }}
              className="group p-6 sm:p-7 bg-white rounded-3xl border-2 border-[#EEDDE1] hover:border-sky-300 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between text-left relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-28 h-28 bg-sky-100/50 rounded-bl-full pointer-events-none group-hover:scale-110 transition-transform"></div>
              <div>
                <div className="w-13 h-13 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Users className="w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-sky-700">
                  Recepción & Agendas
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-[#523A46] font-brand-title mt-1">
                  Panel de Asistente
                </h3>
                <p className="text-xs text-[#7A636F] mt-2 leading-relaxed">
                  Agenda compartida, validación de transferencias, impresión de planes y soporte al chat en horario de la doctora.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-[#F0E0E4] flex items-center justify-between">
                <span className="text-xs font-semibold text-sky-700">Ingreso Asistente</span>
                <div className="w-7 h-7 rounded-full bg-sky-50 group-hover:bg-sky-600 group-hover:text-white flex items-center justify-center text-sky-700 transition-colors">
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. AUTH FORM: EMAIL OTP 2-FACTOR VERIFICATION STEP */}
        {authStep === 'email_otp' && pendingTarget && (
          <div className="max-w-md mx-auto bg-white p-6 sm:p-8 rounded-3xl border border-[#EEDDE1] shadow-xl animate-in fade-in duration-200 space-y-5">
            <button
              onClick={() => setAuthStep('credentials')}
              className="text-xs text-[#876E7B] hover:text-[#523A46] flex items-center gap-1"
            >
              ← Modificar correo o credenciales
            </button>

            <div className="text-center space-y-1.5">
              <div className="w-12 h-12 rounded-2xl bg-[#DE8287]/15 text-[#DE8287] flex items-center justify-center mx-auto mb-2">
                <Mail className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-xl text-[#523A46] font-brand-title">
                Verificación de Seguridad por Correo
              </h3>
              <p className="text-xs text-[#876E7B]">
                Para proteger la confidencialidad médica, ingresa el código solicitado para:
              </p>
              <div className="font-mono font-semibold text-xs text-[#523A46] bg-[#FAF5F7] py-1.5 px-3.5 rounded-full inline-block border border-[#EEDDE1]">
                {pendingTarget.email}
              </div>
            </div>

            {/* Email OTP Simulator Box for test accessibility */}
            <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[11px] text-emerald-800 flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5" />
                  Bandeja de Entrada (Simulador en Vivo)
                </span>
                <button
                  type="button"
                  onClick={handleAutoFillOtp}
                  className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 underline flex items-center gap-1"
                >
                  {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copiado' : 'Auto-completar'}</span>
                </button>
              </div>
              <p className="text-[11px] text-emerald-800">
                Código de verificación enviado a <strong>{pendingTarget.email}</strong>:
              </p>
              <div className="bg-white py-1.5 px-3 rounded-xl border border-emerald-300 font-mono text-center text-xl font-bold tracking-widest text-emerald-900">
                {generatedOtp}
              </div>
            </div>

            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#523A46] mb-1 text-center">
                  Digita el código de 6 dígitos:
                </label>
                <input
                  type="text"
                  maxLength={6}
                  required
                  value={otpCode}
                  onChange={(e) => {
                    setOtpCode(e.target.value.replace(/\D/g, ''));
                    setOtpError('');
                  }}
                  placeholder="••••••"
                  className="w-full py-3 px-4 text-center tracking-[0.4em] font-mono text-xl bg-[#FCFAF9] border border-[#E2CFD4] rounded-2xl outline-none focus:border-[#DE8287] focus:ring-2 focus:ring-[#DE8287]/20 text-[#523A46]"
                />
              </div>

              {otpError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                  <p>{otpError}</p>
                </div>
              )}

              {resendSuccess && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Se ha enviado un nuevo código de verificación a tu correo.</span>
                </div>
              )}

              <div className="flex items-center justify-between text-xs text-[#876E7B]">
                <button
                  type="button"
                  onClick={handleResendOtp}
                  className="text-[#DE8287] hover:underline font-semibold"
                >
                  Reenviar código
                </button>
                <button
                  type="button"
                  onClick={() => setAuthStep('credentials')}
                  className="text-[#876E7B] hover:text-[#523A46]"
                >
                  Cambiar correo
                </button>
              </div>

              <button
                type="submit"
                disabled={otpCode.length !== 6 || isVerifying}
                className="w-full py-3 bg-[#DE8287] hover:bg-[#C4676D] disabled:opacity-50 text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                {isVerifying ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Verificando identidad...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirmar Código y Entrar</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {/* 3. PATIENT CREDENTIALS FORM: INPUT EXPLICITO DE CORREO Y CÉDULA PARA SOLICITAR VERIFICACIÓN */}
        {activeMode === 'patient' && authStep === 'credentials' && (
          <div className="max-w-md mx-auto bg-white p-6 sm:p-8 rounded-3xl border border-[#EEDDE1] shadow-lg animate-in fade-in duration-200">
            <button
              onClick={() => setActiveMode('selection')}
              className="text-xs text-[#876E7B] hover:text-[#523A46] mb-4 flex items-center gap-1"
            >
              ← Volver a selección
            </button>
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-[#DE8287]/15 text-[#DE8287] flex items-center justify-center mx-auto mb-2">
                <User className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-xl text-[#523A46] font-brand-title">
                Portal del Paciente
              </h3>
              <p className="text-xs text-[#876E7B] mt-1">
                Ingresa tu correo electrónico y cédula para solicitar el código de verificación por correo.
              </p>
            </div>

            <form onSubmit={handlePatientSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#573946] mb-1">
                  Correo Electrónico para Solicitar Verificación *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#8C7480] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={patientEmailInput}
                    onChange={(e) => {
                      setPatientEmailInput(e.target.value);
                      setPatientError('');
                    }}
                    placeholder="ej. mariana.gomez@example.com"
                    className="w-full pl-10 pr-4 py-3 text-xs bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287] focus:ring-2 focus:ring-[#DE8287]/20 font-mono text-[#523A46]"
                  />
                </div>
                <p className="text-[10px] text-[#8C7480] mt-1">
                  Aquí te enviaremos el código de seguridad de 6 dígitos.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#573946] mb-1">
                  Número de Cédula / Documento de Identidad *
                </label>
                <input
                  type="text"
                  required
                  value={patientDocInput}
                  onChange={(e) => {
                    setPatientDocInput(e.target.value);
                    setPatientError('');
                  }}
                  placeholder="ej. 1020485912"
                  className="w-full px-4 py-3 text-sm bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287] focus:ring-2 focus:ring-[#DE8287]/20 font-mono"
                />
              </div>

              {patientError && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <p>{patientError}</p>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Solicitar Código de Verificación al Correo</span>
              </button>
            </form>
          </div>
        )}

        {/* 4. DOCTOR CREDENTIALS FORM: INPUT DE CORREO + PIN PARA SOLICITAR CÓDIGO */}
        {activeMode === 'nutritionist' && authStep === 'credentials' && (
          <div className="max-w-md mx-auto bg-white p-6 sm:p-8 rounded-3xl border border-[#EEDDE1] shadow-lg animate-in fade-in duration-200">
            <button
              onClick={() => setActiveMode('selection')}
              className="text-xs text-[#876E7B] hover:text-[#523A46] mb-4 flex items-center gap-1"
            >
              ← Volver a selección
            </button>
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-[#B7A6CF]/20 text-[#8C74B0] flex items-center justify-center mx-auto mb-2">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-xl text-[#523A46] font-brand-title">
                Acceso Profesional · Dra. Karol Suárez
              </h3>
              <p className="text-xs text-[#876E7B] mt-1">
                Ingresa tu correo profesional y PIN para solicitar el código de verificación de 6 dígitos.
              </p>
            </div>
            <form onSubmit={handleNutritionistSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#573946] mb-1">
                  Correo Electrónico Profesional *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-[#8C74B0] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={nutritionistEmail}
                    onChange={(e) => {
                      setNutritionistEmail(e.target.value);
                      setNutritionistError('');
                    }}
                    placeholder="dra.karol.suarez@consultorio.com"
                    className="w-full pl-10 pr-4 py-3 text-xs bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#B7A6CF] focus:ring-2 focus:ring-[#B7A6CF]/20 font-mono text-[#523A46]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#573946] mb-1">
                  PIN de Acceso Profesional *
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-[#8C74B0] absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={nutritionistPin}
                    onChange={(e) => {
                      setNutritionistPin(e.target.value);
                      setNutritionistError('');
                    }}
                    placeholder="PIN predeterminado: 1234"
                    className="w-full pl-10 pr-4 py-3 text-sm bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#B7A6CF] focus:ring-2 focus:ring-[#B7A6CF]/20 font-mono"
                  />
                </div>
                <p className="text-[11px] text-[#9A818E] mt-1">
                  (PIN predeterminado: <span className="font-mono font-bold">1234</span>)
                </p>
              </div>

              {nutritionistError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <p>{nutritionistError}</p>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 bg-[#B7A6CF] hover:bg-[#9E8BBF] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Solicitar Código de Verificación al Correo</span>
              </button>
            </form>
          </div>
        )}

        {/* 5. ASSISTANT CREDENTIALS FORM: INPUT DE CORREO + PIN PARA SOLICITAR CÓDIGO */}
        {activeMode === 'assistant' && authStep === 'credentials' && (
          <div className="max-w-md mx-auto bg-white p-6 sm:p-8 rounded-3xl border border-[#EEDDE1] shadow-lg animate-in fade-in duration-200">
            <button
              onClick={() => setActiveMode('selection')}
              className="text-xs text-[#876E7B] hover:text-[#523A46] mb-4 flex items-center gap-1"
            >
              ← Volver a selección
            </button>
            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-xl text-[#523A46] font-brand-title">
                Acceso Asistente & Recepción
              </h3>
              <p className="text-xs text-[#876E7B] mt-1">
                Ingresa tu correo y PIN para solicitar el código de verificación por correo.
              </p>
            </div>
            <form onSubmit={handleAssistantSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#573946] mb-1">
                  Correo Electrónico de Asistencia *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-sky-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={assistantEmail}
                    onChange={(e) => {
                      setAssistantEmail(e.target.value);
                      setAssistantError('');
                    }}
                    placeholder="recepcion.asistencia@consultorio.com"
                    className="w-full pl-10 pr-4 py-3 text-xs bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-sky-400 focus:ring-2 focus:ring-sky-200 font-mono text-[#523A46]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#573946] mb-1">
                  PIN de Asistente *
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-sky-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={assistantPin}
                    onChange={(e) => {
                      setAssistantPin(e.target.value);
                      setAssistantError('');
                    }}
                    placeholder="PIN predeterminado: 2026"
                    className="w-full pl-10 pr-4 py-3 text-sm bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-sky-400 focus:ring-2 focus:ring-sky-200 font-mono"
                  />
                </div>
                <p className="text-[11px] text-[#9A818E] mt-1">
                  (PIN predeterminado: <span className="font-mono font-bold">2026</span>)
                </p>
              </div>

              {assistantError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <p>{assistantError}</p>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Solicitar Código de Verificación al Correo</span>
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="text-center text-[11px] text-[#9A818E] py-2">
        Dra. Karol Suárez · Nutricionista Dietista · Pamplona & Cúcuta · Teléfono: 302 4708368
      </div>
    </div>
  );
};

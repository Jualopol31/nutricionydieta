import React, { useState } from 'react';
import { MessageCircle, Phone, X, Send, Clock } from 'lucide-react';

interface FloatingWhatsAppProps {
  patientName?: string;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({ patientName }) => {
  const [isOpen, setIsOpen] = useState(false);
  const phoneNumber = '3024708368';
  const formattedPhone = '+57 302 4708368';
  const defaultGreeting = patientName
    ? `Hola Karol, soy ${patientName}. Te escribo desde mi plataforma de nutrición para consultarte:`
    : 'Hola Karol, te escribo desde tu plataforma de nutrición para consultarte:';

  const presets = [
    {
      title: '📅 Agendar o confirmar cita',
      text: `${defaultGreeting} Quisiera confirmar o agendar mi próxima cita de control nutricional.`,
    },
    {
      title: '🥗 Duda sobre mi menú de hoy',
      text: `${defaultGreeting} Tengo una consulta sobre los ingredientes y equivalencias de mi plan de alimentación de hoy.`,
    },
    {
      title: '💳 Consulta sobre pasarela de pagos',
      text: `${defaultGreeting} Quisiera información sobre el abono de mi consulta o comprobante de pago.`,
    },
    {
      title: '👩‍⚕️ Hablar directamente con Karol',
      text: `${defaultGreeting} Quisiera hablar contigo para resolver una inquietud sobre mi tratamiento.`,
    },
  ];

  const handleOpenWhatsApp = (customText?: string) => {
    const textToSend = encodeURIComponent(customText || defaultGreeting);
    const url = `https://wa.me/57${phoneNumber}?text=${textToSend}`;
    window.open(url, '_blank', 'noopener,noreferrer');
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end">
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 bg-white rounded-3xl shadow-2xl border border-[#EADEE1] overflow-hidden animate-in slide-in-from-bottom-3 duration-200">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#DE8287] to-[#C96F75] p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-white/20 border-2 border-white/50 flex items-center justify-center font-bold text-sm">
                  KS
                </div>
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 border-2 border-[#DE8287] rounded-full"></span>
              </div>
              <div>
                <h4 className="font-semibold text-sm leading-tight">Karol Suárez</h4>
                <p className="text-[11px] text-white/90">Nutricionista Dietista · Atención Directa</p>
                <p className="text-[10px] text-white/80 font-mono mt-0.5">{formattedPhone}</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white p-1 rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 space-y-3 bg-[#FCFAF9] text-xs text-[#5D424E]">
            <div className="p-3 bg-white rounded-xl border border-[#F0DFE3] shadow-2xs space-y-1">
              <p className="text-[11px] text-[#8C7480] flex items-center gap-1">
                <Clock className="w-3 h-3 text-[#DE8287]" />
                Horario de Atención: Lunes a Sábado · 8:00 AM - 6:00 PM
              </p>
              <p className="font-medium text-[#503E48]">
                ¿En qué te podemos colaborar hoy? Selecciona una opción rápida:
              </p>
            </div>

            <div className="space-y-1.5">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleOpenWhatsApp(preset.text)}
                  className="w-full text-left p-2.5 rounded-xl bg-white hover:bg-[#FAF2F4] border border-[#F0E2E5] hover:border-[#E2C3CA] text-[#553E4A] font-medium transition-colors flex items-center justify-between group shadow-2xs"
                >
                  <span>{preset.title}</span>
                  <Send className="w-3 h-3 text-[#DE8287] opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))}
            </div>

            <div className="pt-2 flex items-center justify-between border-t border-[#EEDEE2]">
              <a
                href={`tel:+57${phoneNumber}`}
                className="inline-flex items-center gap-1.5 text-xs text-[#7A5B69] hover:text-[#503542] font-semibold"
              >
                <Phone className="w-3.5 h-3.5 text-[#DE8287]" />
                Llamar: {phoneNumber}
              </a>
              <button
                onClick={() => handleOpenWhatsApp()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#25D366] hover:bg-[#20BD5A] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                Abrir WhatsApp
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group flex items-center gap-2.5 px-4 py-3 bg-[#DE8287] hover:bg-[#C96F75] text-white rounded-full shadow-lg shadow-[#DE8287]/30 hover:shadow-xl hover:shadow-[#DE8287]/40 transition-all duration-300 transform hover:scale-105 active:scale-95"
        title="Atención directa Karol Suárez"
      >
        <div className="relative">
          <MessageCircle className="w-6 h-6" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#25D366] rounded-full border-2 border-white animate-pulse"></span>
        </div>
        <div className="text-left hidden sm:block">
          <p className="text-[10px] uppercase font-bold tracking-wider leading-none text-white/90">
            Atención Directa
          </p>
          <p className="text-xs font-semibold leading-tight font-mono">302 4708368</p>
        </div>
      </button>
    </div>
  );
};

import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Calendar,
  Clock,
  Plus,
  CheckCircle2,
  XCircle,
  CreditCard,
  MapPin,
  Video,
  PhoneCall,
  Building2,
  Lock,
  Unlock,
  Users,
  Zap,
  CalendarDays,
  RotateCcw,
  X,
  AlertCircle,
  Receipt,
  FileCheck,
} from 'lucide-react';
import { Appointment, AvailableSlot, Patient, UserRole, AppointmentModality } from '../types';

interface SharedCalendarViewProps {
  role: 'nutritionist' | 'assistant';
  appointments: Appointment[];
  patients: Patient[];
  slots: AvailableSlot[];
  onAddSlot: (newSlot: AvailableSlot) => void;
  onToggleSlot: (slotId: string) => void;
  onBookAppointment: (newApp: Appointment) => void;
  onRescheduleAppointment: (appId: string, newDate: string, newTime: string) => void;
  onConfirmAppointment: (appId: string) => void;
  onCancelAppointment: (appId: string, reason?: string) => void;
  onOpenPaymentModal: (app: Appointment) => void;
}

export const SharedCalendarView: React.FC<SharedCalendarViewProps> = ({
  role,
  appointments,
  patients,
  slots,
  onAddSlot,
  onToggleSlot,
  onBookAppointment,
  onRescheduleAppointment,
  onConfirmAppointment,
  onCancelAppointment,
  onOpenPaymentModal,
}) => {
  const [currentYear, setCurrentYear] = useState(2026);
  const [currentMonth, setCurrentMonth] = useState(9); // October
  // Default to Friday Oct 16
  const [selectedDateStr, setSelectedDateStr] = useState('2026-10-16');
  const [newSlotTime, setNewSlotTime] = useState('10:00 AM');

  // Modals inside Shared Calendar
  const [showDirectBookModal, setShowDirectBookModal] = useState(false);
  const [reschedulingApp, setReschedulingApp] = useState<Appointment | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState('2026-10-19');
  const [rescheduleTime, setRescheduleTime] = useState('10:00 AM');

  // Direct booking form state
  const [selectedPatientId, setSelectedPatientId] = useState(patients[0]?.id || '');
  const [directDate, setDirectDate] = useState(selectedDateStr);
  const [directTime, setDirectTime] = useState('09:30 AM');
  const [directModality, setDirectModality] = useState<AppointmentModality>('presencial_pamplona');
  const [directReason, setDirectReason] = useState('Control nutricional y antropometría');

  const monthNames = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre',
  ];

  const daysOfWeek = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const startingDayIndex = (firstDayOfMonth.getDay() + 6) % 7;
  const totalCells = Math.ceil((startingDayIndex + daysInMonth) / 7) * 7;

  const formatDayString = (day: number) => {
    const mm = String(currentMonth + 1).padStart(2, '0');
    const dd = String(day).padStart(2, '0');
    return `${currentYear}-${mm}-${dd}`;
  };

  // Check if a date string is a Sunday
  const isSunday = (dateStr: string) => {
    const d = new Date(dateStr + 'T12:00:00');
    return d.getDay() === 0;
  };

  const selectedIsSunday = isSunday(selectedDateStr);

  const appointmentsOnSelectedDay = appointments.filter(
    (app) => app.date === selectedDateStr
  );

  const slotsOnSelectedDay = slots.filter((s) => s.date === selectedDateStr && !isSunday(s.date));

  const handleAddNewSlot = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedIsSunday) {
      alert('Los domingos no se pueden habilitar cupos por política de descanso del consultorio.');
      return;
    }
    const newSlot: AvailableSlot = {
      id: `slot-${Date.now()}`,
      date: selectedDateStr,
      time: newSlotTime,
      isAvailable: true,
    };
    onAddSlot(newSlot);
  };

  const handleCreateDirectBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSunday(directDate)) {
      alert('Los domingos no hay agenda disponible.');
      return;
    }
    const pat = patients.find((p) => p.id === selectedPatientId) || patients[0];
    const price =
      directModality === 'presencial_pamplona' || directModality === 'presencial_cucuta'
        ? 160000
        : directModality === 'virtual_meet'
        ? 140000
        : 120000;

    const newApp: Appointment = {
      id: `app-${Date.now()}`,
      patientId: pat.id,
      patientName: pat.name,
      patientEmail: pat.email,
      patientPhone: pat.phone,
      date: directDate,
      time: directTime,
      type: directModality,
      status: 'confirmada', // Direct bookings by staff are confirmed
      paymentStatus: 'pendiente',
      priceCOP: price,
      reason: directReason,
      notes: `Agendado por ${role === 'nutritionist' ? 'Dra. Karol Suárez' : 'Asistente'}`,
      emailVerified: true,
      createdByRole: role,
      createdAt: new Date().toISOString(),
      confirmedAt: new Date().toISOString(),
    };

    onBookAppointment(newApp);
    setShowDirectBookModal(false);
  };

  const handleRescheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reschedulingApp) return;
    if (isSunday(rescheduleDate)) {
      alert('Los domingos no hay agenda disponible para reagendar.');
      return;
    }
    onRescheduleAppointment(reschedulingApp.id, rescheduleDate, rescheduleTime);
    setReschedulingApp(null);
  };

  // Soonest available slots (ZERO SUNDAYS!)
  const soonestSlots = slots.filter((s) => s.isAvailable && !isSunday(s.date)).slice(0, 4);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-3xl border border-[#EEDDE1] shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-lg sm:text-xl text-[#523A46] font-brand-title">
              Agenda Compartida & Horarios Disponibles
            </h3>
            <span className="text-[10px] font-semibold bg-[#FAF0F3] text-[#DE8287] px-2.5 py-0.5 rounded-full border border-[#F2D7DF]">
              {role === 'nutritionist' ? 'Dra. Karol Suárez' : 'Recepción & Asistencia'}
            </span>
          </div>
          <p className="text-xs text-[#876E7B] mt-0.5">
            Sedes Pamplona & Cúcuta · Lunes a Sábado (<strong>Domingos sin agenda disponible</strong>).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => {
              setDirectDate(selectedIsSunday ? '2026-10-19' : selectedDateStr);
              setShowDirectBookModal(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-2xl shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Agendar Cita Directa</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Monthly Calendar on Left, Selected Day Agenda on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Monthly Calendar */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#DE8287]" />
              <h4 className="font-bold text-base sm:text-lg text-[#523A46] font-brand-title">
                {monthNames[currentMonth]} {currentYear}
              </h4>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={prevMonth}
                className="p-1.5 rounded-xl border border-[#E2CFD4] hover:bg-[#FAF4F6] text-[#7A636F] transition-colors"
                title="Mes anterior"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={nextMonth}
                className="p-1.5 rounded-xl border border-[#E2CFD4] hover:bg-[#FAF4F6] text-[#7A636F] transition-colors"
                title="Mes siguiente"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Days of Week Row */}
          <div className="grid grid-cols-7 gap-1 text-center font-bold text-[11px] uppercase tracking-wider text-[#8A727E] py-1 border-b border-[#F0E0E4]">
            {daysOfWeek.map((day, idx) => (
              <div key={day} className={`py-1 ${idx === 6 ? 'text-red-400 font-normal' : ''}`}>
                {day}
              </div>
            ))}
          </div>

          {/* Grid of Day Cells */}
          <div className="grid grid-cols-7 gap-1.5">
            {Array.from({ length: totalCells }).map((_, idx) => {
              const dayNum = idx - startingDayIndex + 1;
              const isCurrentMonthDay = dayNum > 0 && dayNum <= daysInMonth;

              if (!isCurrentMonthDay) {
                return (
                  <div
                    key={idx}
                    className="min-h-[64px] sm:min-h-[72px] p-1.5 rounded-xl bg-[#FAF9F9]/50 opacity-20 border border-transparent"
                  />
                );
              }

              const dateStr = formatDayString(dayNum);
              const isSelected = selectedDateStr === dateStr;
              const isSun = isSunday(dateStr);

              const dayApps = appointments.filter((a) => a.date === dateStr);
              const dayConfirmed = dayApps.filter((a) => a.status === 'confirmada').length;
              const dayPending = dayApps.filter((a) => a.status === 'pendiente').length;

              const daySlots = slots.filter((s) => s.date === dateStr && s.isAvailable && !isSun).length;

              return (
                <div
                  key={idx}
                  onClick={() => setSelectedDateStr(dateStr)}
                  className={`min-h-[64px] sm:min-h-[72px] p-1.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isSun
                      ? 'bg-gray-50/80 border-gray-200 opacity-60'
                      : isSelected
                      ? 'bg-[#FDF3F5] border-[#DE8287] shadow-xs ring-1 ring-[#DE8287]/40'
                      : 'bg-white border-[#EFE2E5] hover:border-[#DE8287]/50 hover:bg-[#FAF7F8]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-semibold ${
                        isSun
                          ? 'text-gray-400'
                          : isSelected
                          ? 'text-[#DE8287] font-bold'
                          : 'text-[#523A46]'
                      }`}
                    >
                      {dayNum}
                    </span>
                    {isSun ? (
                      <span className="text-[9px] text-red-500 font-bold">Dom</span>
                    ) : daySlots > 0 ? (
                      <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1 rounded">
                        +{daySlots}
                      </span>
                    ) : null}
                  </div>

                  {isSun ? (
                    <span className="text-[9px] text-gray-400 italic">Cerrado</span>
                  ) : (
                    <div className="space-y-0.5 mt-1">
                      {dayConfirmed > 0 && (
                        <div className="w-full h-1.5 bg-emerald-500 rounded-full" title={`${dayConfirmed} confirmadas`} />
                      )}
                      {dayPending > 0 && (
                        <div className="w-full h-1.5 bg-amber-400 rounded-full" title={`${dayPending} pendientes`} />
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center gap-4 text-[11px] text-[#7A636F] pt-3 border-t border-[#F2E5E8]">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
              Cita Confirmada
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block"></span>
              Pendiente Aprobación
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-[10px] bg-gray-200 text-gray-600 font-bold px-1 rounded">Dom</span>
              Domingo Sin Agenda
            </span>
          </div>
        </div>

        {/* Right Column: Day Detail & Slot Management */}
        <div className="lg:col-span-5 bg-white rounded-3xl border border-[#EEDDE1] p-5 sm:p-6 shadow-2xs space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            {/* Day Header */}
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#DE8287]">
                  Día Seleccionado
                </span>
                <h4 className="font-bold text-base text-[#523A46] font-brand-title">
                  {selectedDateStr} {selectedIsSunday ? '(Domingo - Cerrado)' : ''}
                </h4>
              </div>
              <span className="text-xs text-[#876E7B]">
                {appointmentsOnSelectedDay.length} citas agendadas
              </span>
            </div>

            {selectedIsSunday ? (
              <div className="p-5 bg-gray-50 rounded-2xl border border-gray-200 text-center space-y-2 text-xs text-gray-600">
                <AlertCircle className="w-8 h-8 text-gray-400 mx-auto" />
                <p className="font-bold text-sm">Domingo: Sin Agenda Médica</p>
                <p className="text-[11px]">
                  El consultorio de la Dra. Karol Suárez atiende de Lunes a Sábado en Pamplona, Cúcuta y modalidad virtual.
                </p>
              </div>
            ) : (
              <>
                {/* Appointments list */}
                <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                  {appointmentsOnSelectedDay.length === 0 ? (
                    <div className="p-4 rounded-2xl border border-dashed border-[#EEDDE1] text-center text-xs text-[#8A727E]">
                      No hay citas programadas para este día.
                    </div>
                  ) : (
                    appointmentsOnSelectedDay.map((app) => (
                      <div
                        key={app.id}
                        className="p-3.5 rounded-2xl border border-[#EFE2E5] bg-[#FAF8F9] space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-sm text-[#523A46]">{app.patientName}</span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              app.status === 'confirmada'
                                ? 'bg-emerald-100 text-emerald-800'
                                : app.status === 'pendiente'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {app.status}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-[#7A636F]">
                          <span className="font-mono font-semibold text-[#DE8287] flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {app.time}
                          </span>
                          <span className="text-[11px]">
                            {app.type === 'presencial_pamplona' ? '📍 Pamplona' :
                             app.type === 'presencial_cucuta' ? '🏢 Cúcuta' :
                             app.type === 'virtual_meet' ? '💻 Meet' : '📞 Llamada'}
                          </span>
                          <span className={`font-semibold ${
                            app.paymentStatus === 'pagado' ? 'text-emerald-700' :
                            app.paymentStatus === 'comprobante_subido' ? 'text-sky-700' : 'text-amber-700'
                          }`}>
                            {app.paymentStatus === 'pagado' ? '✓ Pagado' :
                             app.paymentStatus === 'comprobante_subido' ? 'Comprobante Subido' : 'Pendiente Pago'}
                          </span>
                        </div>

                        {/* Actions: Reagendar, Cancelar, Confirmar, Cobrar */}
                        <div className="pt-2 border-t border-[#EEDDE1] flex flex-wrap items-center justify-between gap-1.5">
                          <div className="flex items-center gap-1">
                            {app.status === 'pendiente' && (
                              <button
                                onClick={() => onConfirmAppointment(app.id)}
                                className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-semibold"
                              >
                                Confirmar
                              </button>
                            )}
                            <button
                              onClick={() => {
                                setReschedulingApp(app);
                                setRescheduleDate(app.date);
                                setRescheduleTime(app.time);
                              }}
                              className="px-2 py-1 bg-white hover:bg-[#FAF4F6] text-[#523A46] border border-[#E2CFD4] rounded-lg text-[11px] font-semibold flex items-center gap-1"
                              title="Reagendar cita a otra fecha/hora"
                            >
                              <RotateCcw className="w-3 h-3 text-[#DE8287]" />
                              <span>Reagendar</span>
                            </button>
                            {app.status !== 'cancelada' && (
                              <button
                                onClick={() => onCancelAppointment(app.id)}
                                className="px-2 py-1 text-red-600 hover:bg-red-50 rounded-lg text-[11px]"
                              >
                                Cancelar
                              </button>
                            )}
                          </div>

                          <button
                            onClick={() => onOpenPaymentModal(app)}
                            className="px-2 py-1 bg-[#FAF0F3] hover:bg-[#FCE6EB] text-[#DE8287] border border-[#F2D7DF] rounded-lg text-[11px] font-semibold flex items-center gap-1"
                          >
                            <CreditCard className="w-3 h-3" />
                            <span>{app.paymentStatus === 'pagado' ? 'Recibo' : 'Ver Comprobante'}</span>
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Slots section */}
                <div className="space-y-2 pt-2 border-t border-[#F0DFE3]">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-[#523A46]">
                      Cupos Libres para este Día:
                    </span>
                    <span className="text-[11px] text-[#876E7B]">
                      {slotsOnSelectedDay.length} configurados
                    </span>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {slotsOnSelectedDay.map((s) => (
                      <button
                        key={s.id}
                        onClick={() => onToggleSlot(s.id)}
                        className={`px-2.5 py-1 rounded-xl text-xs font-mono font-medium border transition-colors flex items-center gap-1 ${
                          s.isAvailable
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                            : 'bg-gray-100 text-gray-500 border-gray-200 line-through'
                        }`}
                        title={s.isAvailable ? 'Bloquear cupo' : 'Habilitar cupo'}
                      >
                        <span>{s.time}</span>
                        {s.isAvailable ? <Unlock className="w-2.5 h-2.5" /> : <Lock className="w-2.5 h-2.5" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Add slot */}
                <form onSubmit={handleAddNewSlot} className="pt-2 border-t border-[#F0DFE3] flex items-center gap-2">
                  <input
                    type="text"
                    required
                    value={newSlotTime}
                    onChange={(e) => setNewSlotTime(e.target.value)}
                    placeholder="ej. 11:30 AM"
                    className="px-3 py-2 text-xs bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287] flex-1 font-mono"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors flex items-center gap-1 shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Abrir Cupo</span>
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Direct Booking Modal (For Doctor and Assistant) */}
      {showDirectBookModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] w-full max-w-lg p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
              <h3 className="font-bold text-lg text-[#523A46] font-brand-title">
                Agendar Cita Directa ({role === 'nutritionist' ? 'Dra. Karol' : 'Asistente'})
              </h3>
              <button onClick={() => setShowDirectBookModal(false)} className="text-[#967C87]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateDirectBooking} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1">Seleccionar Paciente *</label>
                <select
                  value={selectedPatientId}
                  onChange={(e) => setSelectedPatientId(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} - {p.documentId}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Fecha (Sin domingos) *</label>
                  <input
                    type="date"
                    required
                    value={directDate}
                    onChange={(e) => setDirectDate(e.target.value)}
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Hora *</label>
                  <input
                    type="text"
                    required
                    value={directTime}
                    onChange={(e) => setDirectTime(e.target.value)}
                    placeholder="ej. 10:30 AM"
                    className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287] font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Sede / Modalidad *</label>
                <select
                  value={directModality}
                  onChange={(e) => setDirectModality(e.target.value as any)}
                  className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                >
                  <option value="presencial_pamplona">Presencial Pamplona ($160,000 COP)</option>
                  <option value="presencial_cucuta">Presencial Cúcuta ($160,000 COP)</option>
                  <option value="virtual_meet">Virtual Google Meet ($140,000 COP)</option>
                  <option value="llamada_telefonica">Llamada Telefónica Normal ($120,000 COP)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Motivo de Consulta</label>
                <input
                  type="text"
                  required
                  value={directReason}
                  onChange={(e) => setDirectReason(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowDirectBookModal(false)}
                  className="px-4 py-2 text-[#7A636F] hover:bg-[#FAF4F6] rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white font-semibold rounded-xl shadow-xs"
                >
                  Confirmar y Agendar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reschedule Modal */}
      {reschedulingApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl shadow-2xl border border-[#EEDDE1] w-full max-w-md p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#F0DFE3] pb-3">
              <h3 className="font-bold text-lg text-[#523A46] font-brand-title flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-[#DE8287]" />
                Reagendar Cita de {reschedulingApp.patientName}
              </h3>
              <button onClick={() => setReschedulingApp(null)} className="text-[#967C87]">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRescheduleSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1">Nueva Fecha (Lunes a Sábado) *</label>
                <input
                  type="date"
                  required
                  value={rescheduleDate}
                  onChange={(e) => setRescheduleDate(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287]"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Nueva Hora *</label>
                <input
                  type="text"
                  required
                  value={rescheduleTime}
                  onChange={(e) => setRescheduleTime(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FCFAF9] border border-[#E2CFD4] rounded-xl outline-none focus:border-[#DE8287] font-mono"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReschedulingApp(null)}
                  className="px-4 py-2 text-[#7A636F] hover:bg-[#FAF4F6] rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#DE8287] hover:bg-[#C4676D] text-white font-semibold rounded-xl"
                >
                  Guardar Reagendamiento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
